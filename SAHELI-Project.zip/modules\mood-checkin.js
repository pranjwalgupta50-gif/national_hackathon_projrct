﻿// SAHELI Mood Check-In Module
function renderMoodCheckin() {
  const container = document.getElementById('moduleContainer');
  const recent = STATE.get('moods') || [];
  const today = STATE.todaysMood();

  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">☀️ Daily Check-In</div>
        <h1>How are you feeling today?</h1>
        <p>There's no right or wrong answer. Take a moment to pause and notice what's present for you.</p>
      </div>
      <div class="module-content">
        ${today ? `
        <div class="alert alert-success mt-16">
          ✅ You've already checked in today — mood: <strong>${today.mood}</strong>. You can update it below if your mood has changed.
        </div>` : ''}

        <!-- Mood Selector -->
        <div class="card mt-24">
          <div class="card-label">Right now, I feel…</div>
          <div class="mood-grid mt-16" id="moodGrid">
            ${[
              ['😊','Happy','joy, lightness, contentment'],
              ['😌','Calm','peaceful, relaxed, steady'],
              ['🙂','Okay','neutral, managing, alright'],
              ['😰','Anxious','worried, tense, on edge'],
              ['😔','Low','sad, down, heavy'],
              ['😵','Overwhelmed','too much, drowning, stuck'],
              ['😡','Frustrated','irritated, angry, fed up'],
              ['😴','Exhausted','tired, drained, empty']
            ].map(([emoji, mood, desc]) => `
              <button class="mood-btn ${today?.mood === mood ? 'selected' : ''}" data-mood="${mood}" title="${desc}">
                <span class="mood-emoji">${emoji}</span>
                <span>${mood}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Intensity Slider -->
        <div class="card mt-16" id="intensityCard" style="${today ? '' : 'opacity:0.5;pointer-events:none'}">
          <div class="card-label">Intensity</div>
          <div class="form-group mt-12">
            <label class="form-label" for="moodIntensity">How strong is this feeling? <span id="intensityVal" style="color:var(--purple-700);font-weight:700">${today?.intensity || 5}/10</span></label>
            <input type="range" id="moodIntensity" min="1" max="10" value="${today?.intensity || 5}" class="mt-8" />
            <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-400);margin-top:4px">
              <span>Barely noticeable</span><span>Very intense</span>
            </div>
          </div>
        </div>

        <!-- Note -->
        <div class="card mt-16">
          <div class="card-label">Optional Note (private)</div>
          <textarea class="form-textarea mt-12" id="moodNote" placeholder="What's contributing to how you feel? Any thoughts you want to capture…" rows="3" maxlength="500">${today?.note || ''}</textarea>
          <div style="display:flex;align-items:center;gap:10px;margin-top:8px">
            <button class="btn btn-outline btn-sm" id="voiceMoodBtn" title="Voice input">🎤 Speak</button>
            <span style="font-size:11px;color:var(--text-400)">Your note stays private and is never shared.</span>
          </div>
        </div>

        <!-- Save Button -->
        <button class="btn btn-primary btn-full mt-16" id="saveMoodBtn">Save My Check-In →</button>
        <p style="font-size:11px;color:var(--text-400);text-align:center;margin-top:8px">This is a personal reflection tool. Not a medical assessment or diagnosis.</p>

        <!-- Recent Moods -->
        ${recent.length > 0 ? renderMoodHistory(recent.slice(0, 14)) : ''}

      </div>
    </div>
  `;

  let selectedMood = today?.mood || '';
  const intensitySlider = document.getElementById('moodIntensity');
  const intensityVal = document.getElementById('intensityVal');
  const intensityCard = document.getElementById('intensityCard');
  const noteEl = document.getElementById('moodNote');

  // Mood selection
  document.getElementById('moodGrid').addEventListener('click', (e) => {
    const btn = e.target.closest('.mood-btn');
    if (!btn) return;
    selectedMood = btn.dataset.mood;
    document.querySelectorAll('.mood-btn').forEach(b => b.classList.toggle('selected', b === btn));
    intensityCard.style.opacity = '1';
    intensityCard.style.pointerEvents = 'auto';
  });

  // Intensity slider
  intensitySlider.addEventListener('input', () => {
    intensityVal.textContent = intensitySlider.value + '/10';
  });

  // Voice input for note
  const voiceMoodBtn = document.getElementById('voiceMoodBtn');
  voiceMoodBtn.addEventListener('click', () => {
    if (VOICE.isRecording) {
      VOICE.stopRecording();
      voiceMoodBtn.textContent = '🎤 Speak';
      return;
    }
    VOICE.onResult = (text, isFinal) => {
      noteEl.value = text;
      if (isFinal) voiceMoodBtn.textContent = '🎤 Speak';
    };
    VOICE.onStart = () => { voiceMoodBtn.textContent = '⏹ Stop'; };
    VOICE.onEnd = () => { voiceMoodBtn.textContent = '🎤 Speak'; };
    VOICE.onError = () => { voiceMoodBtn.textContent = '🎤 Speak'; showToast('Voice input not available', 'warning'); };
    VOICE.startRecording();
    voiceMoodBtn.textContent = '⏹ Stop';
  });

  // Save
  document.getElementById('saveMoodBtn').addEventListener('click', () => {
    if (!selectedMood) {
      showToast('Please select how you\'re feeling first', 'warning');
      return;
    }
    const entry = STATE.recordMood(selectedMood, parseInt(intensitySlider.value), noteEl.value);
    
    // Update sidebar
    const sidebarVal = document.getElementById('sidebarMoodValue');
    if (sidebarVal) sidebarVal.textContent = selectedMood;
    
    showToast(`Check-in saved — ${selectedMood} (${intensitySlider.value}/10) 💜`, 'success');
    
    // Speak confirmation
    if (VOICE.isSpeechSupported()) {
      VOICE.speak(`Check in saved. You\'re feeling ${selectedMood} today.`);
    }
    
    // Trigger safety check for very intense low/overwhelmed moods
    if ((selectedMood === 'Low' || selectedMood === 'Overwhelmed') && parseInt(intensitySlider.value) >= 8) {
      setTimeout(() => {
        showToast('💙 It sounds like today is really hard. SAHELI AI is here to talk — or call 14416 for free support.', 'warning', 7000);
      }, 1500);
    }
    
    // Re-render to show updated history
    setTimeout(() => renderMoodCheckin(), 500);
  });
}

function renderMoodHistory(moods) {
  const moodEmojis = { Happy:'😊', Calm:'😌', Okay:'🙂', Anxious:'😰', Low:'😔', Overwhelmed:'😵', Frustrated:'😡', Exhausted:'😴' };
  return `
    <div class="card mt-24">
      <div class="card-label">Recent Mood History</div>
      <div style="margin-top:16px">
        ${moods.map(m => `
          <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-light)">
            <span style="font-size:22px">${moodEmojis[m.mood] || '😐'}</span>
            <div style="flex:1">
              <span style="font-size:13px;font-weight:600;color:var(--text-800)">${m.mood}</span>
              ${m.intensity ? `<span style="font-size:11px;color:var(--text-400);margin-left:6px">Intensity: ${m.intensity}/10</span>` : ''}
              ${m.note ? `<div style="font-size:12px;color:var(--text-500);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:300px">${m.note}</div>` : ''}
            </div>
            <span style="font-size:11px;color:var(--text-300)">${new Date(m.date).toLocaleDateString('en-IN', {day:'numeric',month:'short'})}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

window.MOOD_MODULE = { render: renderMoodCheckin };
