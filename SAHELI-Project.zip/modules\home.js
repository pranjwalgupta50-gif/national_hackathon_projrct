﻿// SAHELI Home Dashboard Module
function renderHome() {
  const container = document.getElementById('moduleContainer');
  const todayMood = STATE.todaysMood();
  const recoveryPlan = STATE.get('recoveryPlan');
  const journalEntries = STATE.get('journalEntries') || [];
  const sleepData = STATE.get('sleepData') || [];
  const moods = STATE.get('moods') || [];
  const greeting = getGreeting();
  const userName = STATE.get('userName') || '';

  const lastSleep = sleepData[0];
  const moodStreak = getMoodStreak(moods);
  const recoveryProgress = getRecoveryProgress();

  container.innerHTML = `
    <div class="module-view">
      <!-- Welcome Banner -->
      <div class="module-header">
        <div class="module-header-badge">🌸 Your Wellness Space</div>
        <h1>${greeting}${userName ? ', ' + userName : ''} 💜</h1>
        <p>This is your safe, private space to check in, reflect, and find support. Everything here is just for you.</p>
      </div>

      <div class="module-content-wide">

        <!-- Quick Stats Row -->
        <div class="card-grid-4 mb-24 mt-24">
          <div class="card card-purple" style="text-align:center;padding:20px 16px">
            <div style="font-size:32px;margin-bottom:8px">${todayMood ? getMoodEmoji(todayMood.mood) : '☁️'}</div>
            <div class="card-label">Today's Mood</div>
            <div style="font-size:16px;font-weight:700;color:var(--purple-700)">${todayMood ? todayMood.mood : 'Not recorded'}</div>
            ${!todayMood ? `<button class="btn btn-primary btn-sm mt-8" onclick="navigateTo('mood-checkin')">Check In</button>` : ''}
          </div>
          <div class="card card-coral" style="text-align:center;padding:20px 16px">
            <div style="font-size:32px;margin-bottom:8px">🌙</div>
            <div class="card-label">Last Sleep</div>
            <div style="font-size:16px;font-weight:700;color:var(--coral-500)">${lastSleep ? lastSleep.duration + ' hrs' : 'Not recorded'}</div>
            ${!lastSleep ? `<button class="btn btn-coral btn-sm mt-8" onclick="navigateTo('sleep')">Log Sleep</button>` : ''}
          </div>
          <div class="card card-sage" style="text-align:center;padding:20px 16px">
            <div style="font-size:32px;margin-bottom:8px">📅</div>
            <div class="card-label">Mood Streak</div>
            <div style="font-size:16px;font-weight:700;color:var(--sage-500)">${moodStreak} day${moodStreak !== 1 ? 's' : ''}</div>
          </div>
          <div class="card card-lavender" style="text-align:center;padding:20px 16px">
            <div style="font-size:32px;margin-bottom:8px">🌱</div>
            <div class="card-label">Recovery</div>
            <div style="font-size:16px;font-weight:700;color:var(--lavender-500)">${recoveryPlan?.concern ? recoveryProgress + '%' : 'Not started'}</div>
            ${!recoveryPlan?.concern ? `<button class="btn btn-secondary btn-sm mt-8" onclick="navigateTo('concerns')">Begin</button>` : ''}
          </div>
        </div>

        <!-- Mood Trend (if we have data) -->
        ${moods.length > 1 ? renderMoodTrend(moods.slice(0,7)) : ''}

        <!-- Main Feature Grid -->
        <div class="section-header mb-16">
          <div>
            <div class="section-title">Your SAHELI Tools</div>
            <div class="section-subtitle">Choose what feels right today — every small step counts</div>
          </div>
        </div>

        <div class="card-grid-3 mb-24">
          ${renderHomeCard('💬', 'Talk to SAHELI AI', 'Get personalized support, ask questions, or just talk through what\'s on your mind.', 'ai-chat', 'purple', 'AI')}
          ${renderHomeCard('🔍', 'Explore Your Concerns', 'Select a concern for a personalized assessment and recovery plan.', 'concerns', 'coral')}
          ${renderHomeCard('☀️', 'Daily Mood Check-In', 'A quick daily check-in to track how you\'re feeling over time.', 'mood-checkin', 'lavender')}
          ${renderHomeCard('🌱', 'My Recovery Journey', 'Follow your personalized day-by-day recovery pathway.', 'recovery', 'sage')}
          ${renderHomeCard('📚', 'Body & Mind Library', 'Browse healing activities: grounding, breathing, movement, creativity, and more.', 'healing-library', 'purple')}
          ${renderHomeCard('📔', 'My Private Journal', 'Write or dictate your daily reflections. Private, encrypted locally.', 'journal', 'coral')}
          ${renderHomeCard('🌙', 'Sleep & Energy', 'Assess your sleep quality and get tailored improvement suggestions.', 'sleep', 'lavender')}
          ${renderHomeCard('🌺', 'Period Tracker', 'Optional private tracker for your cycle and related wellness.', 'period-tracker', 'sage')}
          ${renderHomeCard('🛡️', 'Trauma & Safety', 'Access personalized safety support, resources, and recovery pathways.', 'trauma-safety', 'purple', 'Safe')}
          ${renderHomeCard('💞', 'Relationships & Family', 'Explore concerns about relationships, boundaries, and family dynamics.', 'relationships', 'coral')}
          ${renderHomeCard('👶', 'Postpartum Support', 'Emotional support and guidance for new mothers and those postpartum.', 'postpartum', 'lavender')}
          ${renderHomeCard('🌸', 'Menopause Care', 'Symptom tracking, sleep support, and general health information.', 'menopause', 'sage')}
          ${renderHomeCard('💰', 'Financial Well-Being', 'Income allocation calculator, financial safety checklist, and guidance.', 'financial', 'purple')}
          ${renderHomeCard('👩‍⚕️', 'Find Professionals', 'Locate psychologists, counsellors, psychiatrists, and helplines near you.', 'professionals', 'coral')}
          ${renderHomeCard('🔒', 'Privacy & Data', 'Control your data, manage journal entries, and adjust privacy settings.', 'privacy', 'lavender')}
        </div>

        <!-- Emergency Section -->
        <div class="card" style="background:linear-gradient(135deg,#FFF0F0,#FFE5E5);border-color:#FFCDD2;margin-bottom:32px">
          <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap">
            <div style="font-size:40px">🆘</div>
            <div style="flex:1">
              <div class="card-label" style="color:#C0392B">IMMEDIATE SUPPORT</div>
              <div class="card-title" style="color:#922B21">Emergency Helplines</div>
              <div class="card-desc">Available 24/7. Free. Confidential. You deserve support.</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:8px">
              <a href="tel:112" class="emergency-btn emergency-btn-primary" style="text-decoration:none;border-radius:8px">📞 112 — Emergency</a>
              <a href="tel:14416" class="emergency-btn emergency-btn-secondary" style="text-decoration:none;border-radius:8px">💙 14416 — Tele-MANAS</a>
              <a href="tel:181" class="emergency-btn emergency-btn-secondary" style="text-decoration:none;border-radius:8px">🌸 181 — Women Helpline</a>
            </div>
          </div>
        </div>

        <!-- Wellness Disclaimer -->
        <div class="alert alert-info" style="margin-bottom:24px">
          <strong>ℹ️ About SAHELI:</strong> ${t('wellnessDisclaimer')} ${t('emergencyNote')}
        </div>

      </div>
    </div>
  `;

  // Attach card click handlers
  container.querySelectorAll('[data-navigate]').forEach(el => {
    el.addEventListener('click', () => navigateTo(el.dataset.navigate));
  });
}

function renderHomeCard(icon, title, desc, module_, variant, badge) {
  return `
    <div class="card card-${variant} card-clickable" data-navigate="${module_}">
      <div style="font-size:32px;margin-bottom:12px">${icon}</div>
      <div class="card-label">${badge || module_.replace('-', ' ').toUpperCase()}</div>
      <div class="card-title">${title}</div>
      <div class="card-desc">${desc}</div>
      <div class="card-footer">
        <span class="btn btn-outline btn-sm">Open →</span>
      </div>
    </div>
  `;
}

function renderMoodTrend(moods) {
  const emojiMap = { Calm:'😌', Okay:'🙂', Anxious:'😰', Low:'😔', Overwhelmed:'😵', Happy:'😊' };
  const items = moods.slice().reverse().map(m => {
    const date = new Date(m.date);
    const label = `${date.getDate()}/${date.getMonth()+1}`;
    return `<div style="text-align:center;font-size:11px;color:var(--text-500)">
      <div style="font-size:20px">${emojiMap[m.mood] || '😐'}</div>
      <div style="margin-top:4px">${m.mood}</div>
      <div style="color:var(--text-300)">${label}</div>
    </div>`;
  }).join('');

  return `
    <div class="card mb-24">
      <div class="card-label">Mood History (Last 7 days)</div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:12px">${items}</div>
    </div>
  `;
}

function getMoodEmoji(mood) {
  const map = { Calm:'😌', Okay:'🙂', Anxious:'😰', Low:'😔', Overwhelmed:'😵', Happy:'😊' };
  return map[mood] || '😐';
}

function getMoodStreak(moods) {
  if (!moods || moods.length === 0) return 0;
  let streak = 0;
  let checkDate = new Date();
  checkDate.setHours(0,0,0,0);
  for (let i = 0; i < 30; i++) {
    const found = moods.find(m => new Date(m.date).toDateString() === checkDate.toDateString());
    if (found) { streak++; checkDate.setDate(checkDate.getDate() - 1); }
    else break;
  }
  return streak;
}

function getRecoveryProgress() {
  const plan = STATE.get('recoveryPlan');
  if (!plan || !plan.startDate) return 0;
  const days = Math.floor((Date.now() - new Date(plan.startDate)) / 86400000) + 1;
  const activities = plan.activities ? Object.values(plan.activities).filter(a => a.status === 'done').length : 0;
  return Math.min(Math.round((activities / Math.max(days * 2, 1)) * 100), 100);
}

window.HOME_MODULE = { render: renderHome };
