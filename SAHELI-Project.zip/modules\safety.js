﻿// SAHELI Safety Classification Module
const RISK_PATTERNS = {
  immediate: [
    /\b(kill|end|take|hurt)\s+(my|myself|my life|it all)\b/i,
    /\b(want to die|wish i was dead|wish i were dead)\b/i,
    /\b(can'?t keep (my)?self safe|cannot keep (my)?self safe)\b/i,
    /\b(going to (hurt|harm|kill) myself)\b/i,
    /\b(have a plan|have the means|have pills|have a weapon)\b/i,
    /\b(suicide|suicidal)\b/i,
    /\b(mar jaana chahti|marna chahti|jeena nahi chahti)\b/i,
    /\b(koi matlab nahi mere jeene ka)\b/i,
    /\b(khatam kar lena)\b/i,
    /\b(someone is (hurting|abusing|beating|harming) me)\b/i,
    /\b(scared to go home|afraid to go home)\b/i,
    /\b(he (hit|beats|hurts|harms) me)\b/i,
    /\b(mujhe koi maar raha|dar lagta hai ghar jaane se)\b/i
  ],
  significant: [
    /\b(completely worthless|completely useless|no reason to live)\b/i,
    /\b(nobody cares|no one cares about me|no one would miss me)\b/i,
    /\b(burden to everyone|everyone would be better without me)\b/i,
    /\b(hopeless|helpless|trapped|no way out)\b/i,
    /\b(self.harm|cut myself|hurting myself)\b/i,
    /\b(mujhe koi nahi chahiye|sab theek ho jayega mere bina)\b/i
  ],
  monitor: [
    /\b(not okay|not fine|struggling|falling apart)\b/i,
    /\b(can'?t cope|can'?t handle|can'?t go on)\b/i,
    /\b(depressed|very sad|very low|extremely tired)\b/i
  ]
};

function classifyRisk(text) {
  if (!text || typeof text !== 'string') return 'none';
  const lower = text.toLowerCase();
  for (const pattern of RISK_PATTERNS.immediate) {
    if (pattern.test(lower)) return 'immediate';
  }
  for (const pattern of RISK_PATTERNS.significant) {
    if (pattern.test(lower)) return 'significant';
  }
  for (const pattern of RISK_PATTERNS.monitor) {
    if (pattern.test(lower)) return 'monitor';
  }
  return 'none';
}

function triggerSafetyAlert(riskLevel, customMessage) {
  if (riskLevel === 'immediate') {
    showImmediateAlert(customMessage);
  } else if (riskLevel === 'significant') {
    showSignificantAlert();
  }
}

function showImmediateAlert(message) {
  const overlay = document.getElementById('emergencyOverlay');
  const msgEl = document.getElementById('emergencyMessage');
  if (!overlay) return;
  if (msgEl && message) msgEl.textContent = message;
  overlay.classList.remove('hidden');
  playEmergencyAlarm();
  STATE.set('safetyState', 'immediate');
  // Keep body scroll locked while alert is visible
  document.body.style.overflow = 'hidden';
}

function hideImmediateAlert() {
  const overlay = document.getElementById('emergencyOverlay');
  if (overlay) overlay.classList.add('hidden');
  stopEmergencyAlarm();
  document.body.style.overflow = '';
  STATE.set('safetyState', 'safe');
}

function showSignificantAlert() {
  showToast('SAHELI has noticed you may be having a hard time. Please reach out for support. 💙 Call 14416 for free mental health support.', 'warning', 8000);
}

let alarmAudio = null;
let alarmInterval = null;

function playEmergencyAlarm() {
  try {
    // Use Web Audio API for a simple alarm tone
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    function beep() {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    }
    beep();
    alarmInterval = setInterval(beep, 800);
    window._alarmCtx = ctx;
  } catch(e) { console.warn('Could not play alarm:', e); }
}

function stopEmergencyAlarm() {
  if (alarmInterval) { clearInterval(alarmInterval); alarmInterval = null; }
  if (window._alarmCtx) { try { window._alarmCtx.close(); } catch(e) {} window._alarmCtx = null; }
}

// Safety resource card HTML
function getSafetyResourceHtml() {
  return `
    <div class="alert alert-danger">
      <strong>Need help right now?</strong><br>
      📞 <strong>112</strong> — National Emergency<br>
      💙 <strong>14416</strong> — Tele-MANAS (Free mental health support, 24/7)<br>
      🌸 <strong>181</strong> — Women Helpline
    </div>
    <p style="font-size:13px;color:var(--text-500);margin-top:8px;">
      These helplines are available to you. You can also talk to a trusted person or go to the nearest hospital emergency department.
    </p>
  `;
}

window.SAFETY = {
  classify: classifyRisk,
  trigger: triggerSafetyAlert,
  showImmediate: showImmediateAlert,
  hide: hideImmediateAlert,
  getResourceHtml: getSafetyResourceHtml
};

// Wire up emergency overlay buttons
document.addEventListener('DOMContentLoaded', () => {
  const askSafe = document.getElementById('emergencyAskSafe');
  if (askSafe) askSafe.addEventListener('click', hideImmediateAlert);
  const silence = document.getElementById('emergencySilence');
  if (silence) silence.addEventListener('click', stopEmergencyAlarm);
  const emergencyBtn = document.getElementById('emergencyBtn');
  if (emergencyBtn) emergencyBtn.addEventListener('click', () => showImmediateAlert(''));
  const sidebarEmergencyBtn = document.getElementById('sidebarEmergencyBtn');
  if (sidebarEmergencyBtn) sidebarEmergencyBtn.addEventListener('click', () => showImmediateAlert(''));
});
