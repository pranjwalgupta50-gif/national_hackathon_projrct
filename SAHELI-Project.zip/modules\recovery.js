﻿// SAHELI Recovery Journey Module
function renderRecovery() {
  const container = document.getElementById('moduleContainer');
  const plan = STATE.get('recoveryPlan');

  if (!plan || !plan.concern) {
    container.innerHTML = `
      <div class="module-view">
        <div class="module-header">
          <div class="module-header-badge">🌱 Recovery Journey</div>
          <h1>My Recovery Journey</h1>
          <p>A personalized, step-by-step path designed around your needs — at your own pace.</p>
        </div>
        <div class="module-content">
          <div class="empty-state mt-24">
            <div class="empty-state-icon">🌱</div>
            <div class="empty-state-title">Your journey starts with one step</div>
            <div class="empty-state-desc">Begin by exploring your concerns. SAHELI will create a personalized recovery plan just for you.</div>
            <button class="btn btn-primary" onclick="navigateTo('concerns')">Explore My Concerns →</button>
          </div>
        </div>
      </div>`;
    return;
  }

  const concernMap = {
    loneliness: { icon: '💔', name: 'Loneliness & Isolation' },
    depression: { icon: '🌧️', name: 'Low Mood & Depression' },
    anxiety: { icon: '🌀', name: 'Anxiety & Stress' },
    sleep: { icon: '😴', name: 'Sleep Problems' },
    trauma: { icon: '🛡️', name: 'Trauma & Past Hurt' },
    relationships: { icon: '💞', name: 'Relationships' },
    general: { icon: '🌿', name: 'General Wellness' }
  };

  const concern = concernMap[plan.concern] || { icon: '🌿', name: plan.concern };
  const startDate = plan.startDate ? new Date(plan.startDate) : new Date();
  const daysSinceStart = Math.floor((Date.now() - startDate) / 86400000) + 1;
  const currentDay = Math.min(daysSinceStart, 14);
  const activities = plan.activities || {};

  // Recovery plan days
  const recoveryDays = buildRecoveryDays(plan.concern, currentDay, activities);
  const completedActivities = Object.values(activities).filter(a => a.status === 'done').length;
  const totalActivities = recoveryDays.reduce((sum, d) => sum + d.activities.length, 0);
  const progressPct = totalActivities > 0 ? Math.round((completedActivities / totalActivities) * 100) : 0;

  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">🌱 Day ${currentDay} of Your Journey</div>
        <h1>${concern.icon} ${concern.name} Recovery</h1>
        <p>You started ${currentDay} day${currentDay !== 1 ? 's' : ''} ago. Every step forward, however small, is progress.</p>
      </div>
      <div class="module-content">

        <!-- Progress Overview -->
        <div class="card card-purple mt-24">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
            <div>
              <div class="card-label">Overall Progress</div>
              <div style="font-size:32px;font-weight:700;color:var(--purple-700);margin:4px 0">${progressPct}%</div>
              <div style="font-size:13px;color:var(--text-500)">${completedActivities} of ${totalActivities} activities completed</div>
            </div>
            <div style="display:flex;gap:16px;flex-wrap:wrap">
              <div class="stat-chip">📅 Day ${currentDay}</div>
              <div class="stat-chip">✅ ${completedActivities} done</div>
              <div class="stat-chip">🌱 ${totalActivities - completedActivities} remaining</div>
            </div>
          </div>
          <div class="progress-bar mt-16">
            <div class="progress-fill" style="width:${progressPct}%"></div>
          </div>
          <p style="font-size:11px;color:var(--text-400);margin-top:8px">Progress reflects activities you've completed. Recovery is personal and non-linear — be patient with yourself.</p>
        </div>

        <!-- Today's Focus -->
        ${renderTodayFocus(recoveryDays, currentDay, activities)}

        <!-- Day-by-Day Plan -->
        <div class="section-header mt-24 mb-16">
          <div class="section-title">Your Recovery Timeline</div>
          <button class="btn btn-outline btn-sm" onclick="navigateTo('concerns')">Adjust Plan</button>
        </div>

        ${recoveryDays.map(day => renderRecoveryDayCard(day, activities)).join('')}

        <!-- Professional Support Reminder -->
        <div class="card card-coral mt-24">
          <div class="card-label">Remember</div>
          <p style="font-size:13px;color:var(--text-600);margin-top:8px;line-height:1.7">
            This recovery journey supports you with wellness strategies. It is not a replacement for professional mental health care. 
            If your symptoms are worsening or you're struggling significantly, please reach out to a qualified professional or call 14416 (free, 24/7).
          </p>
          <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
            <button class="btn btn-primary btn-sm" onclick="navigateTo('professionals')">Find a Professional</button>
            <a href="tel:14416" class="btn btn-secondary btn-sm">💙 Call 14416</a>
          </div>
        </div>

      </div>
    </div>
  `;

  // Wire activity buttons
  container.querySelectorAll('.complete-activity-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const actId = btn.dataset.activity;
      STATE.markActivity(actId, 'done');
      btn.textContent = '✅ Completed!';
      btn.className = 'btn btn-success btn-sm';
      btn.disabled = true;
      showToast('Activity completed! Great work 💜', 'success');
      // Update progress
      setTimeout(() => renderRecovery(), 500);
    });
  });
}

function buildRecoveryDays(concernId, currentDay, completedActivities) {
  const dayTemplates = {
    anxiety: [
      { day: 1, title: 'Grounding & Assessment', focus: 'Understand your anxiety patterns today', activities: [
        { id: 'anx_d1_1', icon: '🖐️', title: '5-4-3-2-1 Grounding Exercise', desc: 'Right now: name 5 things you can see, 4 you can feel, 3 you can hear, 2 you can smell, 1 you can taste.', duration: '5 min' },
        { id: 'anx_d1_2', icon: '📓', title: 'Anxiety Trigger Log', desc: 'Write down what triggered your anxiety today, how strong it was (1-10), and what helped or didn\'t help.', duration: '10 min' }
      ]},
      { day: 2, title: 'Breathing & Coping Tools', focus: 'Practice two calming techniques', activities: [
        { id: 'anx_d2_1', icon: '🌬️', title: '4-2-6 Breathing', desc: 'Inhale 4, hold 2, exhale 6. Repeat 10 times. The longer exhale activates your parasympathetic nervous system.', duration: '5 min' },
        { id: 'anx_d2_2', icon: '🧘', title: 'Progressive Muscle Relaxation', desc: 'Tense and release each muscle group from feet to forehead. Notice the contrast between tension and relaxation.', duration: '15 min' }
      ]},
      { day: 3, title: 'Thought Challenging', focus: 'Gently question anxious thoughts', activities: [
        { id: 'anx_d3_1', icon: '💭', title: 'Thought Record', desc: 'Write an anxious thought, then ask: Is it definitely true? What\'s the evidence for and against? What would I tell a friend?', duration: '15 min' },
        { id: 'anx_d3_2', icon: '🚶', title: 'Anxiety-Reducing Walk', desc: 'Walk for 20 minutes. Focus on your feet hitting the ground, the air on your skin, and sounds around you.', duration: '20 min' }
      ]},
      { day: 4, title: 'Social Connection & Support', focus: 'Connect and communicate about anxiety', activities: [
        { id: 'anx_d4_1', icon: '📞', title: 'Tell One Person', desc: 'Share with one trusted person that you\'ve been feeling anxious. You don\'t need to say everything — just a little.', duration: '10-15 min' },
        { id: 'anx_d4_2', icon: '📋', title: 'Daily Structure Plan', desc: 'Create a simple schedule for tomorrow with rest built in. Uncertainty fuels anxiety — structure reduces it.', duration: '10 min' }
      ]}
    ],
    depression: [
      { day: 1, title: 'Safety & Gentle Start', focus: 'Check in with yourself and take one small step', activities: [
        { id: 'dep_d1_1', icon: '🌅', title: 'Morning Window Light', desc: 'Sit near a window or step outside for 10 minutes in the morning. Natural light helps regulate mood.', duration: '10 min' },
        { id: 'dep_d1_2', icon: '📝', title: 'How I Am Today', desc: 'Write honestly about how you\'re feeling — no judgment. What are you finding hardest right now?', duration: '10 min' }
      ]},
      { day: 2, title: 'Routine & Small Wins', focus: 'Create a manageable daily structure', activities: [
        { id: 'dep_d2_1', icon: '📋', title: 'Tiny Task List', desc: 'Write 3 very small tasks for today — things you can do in under 10 minutes each. Completing even small things builds momentum.', duration: '5 min' },
        { id: 'dep_d2_2', icon: '🚿', title: 'Basic Self-Care', desc: 'Shower, dress, eat something. On low mood days, these basics are genuine achievements.', duration: '30 min' }
      ]},
      { day: 3, title: 'Connection & Assessment', focus: 'Reach out and review progress', activities: [
        { id: 'dep_d3_1', icon: '📞', title: 'One Connection', desc: 'Text or call one person you trust — it doesn\'t need to be a big conversation.', duration: '5-15 min' },
        { id: 'dep_d3_2', icon: '👩‍⚕️', title: 'Consider Professional Support', desc: 'If low mood has persisted for 2+ weeks, consider booking an appointment with your doctor or a counsellor today.', duration: 'As needed' }
      ]},
      { day: 4, title: 'Gentle Activity & Joy', focus: 'Do one thing you used to enjoy', activities: [
        { id: 'dep_d4_1', icon: '🎵', title: 'Music Mood Lift', desc: 'Listen to music you used to enjoy or that feels comforting. Even 15 minutes can shift mood slightly.', duration: '15-30 min' },
        { id: 'dep_d4_2', icon: '🌿', title: 'Nature or Movement', desc: 'A brief walk outside, even for 10 minutes. Daylight and movement are natural mood supporters.', duration: '10-20 min' }
      ]}
    ]
  };

  // Build days
  const specificDays = dayTemplates[concernId] || [];
  const result = [];

  for (let d = 1; d <= Math.max(currentDay + 1, 4); d++) {
    const template = specificDays.find(t => t.day === d);
    if (template) {
      result.push({ ...template, isToday: d === currentDay, isPast: d < currentDay, isFuture: d > currentDay });
    } else {
      // Generic day
      result.push({
        day: d, isToday: d === currentDay, isPast: d < currentDay, isFuture: d > currentDay,
        title: d <= 2 ? 'Initial Support' : d <= 4 ? 'Building Momentum' : d <= 7 ? 'Deepening Practice' : 'Ongoing Growth',
        focus: 'Continue your wellness journey',
        activities: [
          { id: `gen_d${d}_1`, icon: '🌬️', title: 'Calming Practice', desc: 'A 5-minute breathing or grounding exercise to centre yourself.', duration: '5 min' },
          { id: `gen_d${d}_2`, icon: '📝', title: 'Reflection', desc: 'Write briefly about how you\'re doing today and one thing you\'re grateful for.', duration: '10 min' }
        ]
      });
    }
  }

  return result;
}

function renderTodayFocus(days, currentDay, activities) {
  const today = days.find(d => d.isToday) || days[0];
  if (!today) return '';
  return `
    <div class="card card-coral mt-24">
      <div class="card-label">Today's Focus — Day ${today.day}</div>
      <div class="card-title mt-8">${today.title}</div>
      <div class="card-desc mt-4">${today.focus}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px">
        ${today.activities.map(act => `
          <div class="activity-card ${activities[act.id]?.status === 'done' ? 'completed' : ''}">
            <div class="activity-card-header">
              <span class="activity-icon">${act.icon}</span>
              <div>
                <div class="activity-title">${act.title}</div>
                <div class="activity-duration">${act.duration}</div>
              </div>
            </div>
            <div class="activity-desc">${act.desc}</div>
            ${activities[act.id]?.status === 'done'
              ? '<div class="activity-status">✅ Completed</div>'
              : `<button class="btn btn-primary btn-sm mt-8 complete-activity-btn" data-activity="${act.id}">Mark as Done</button>`
            }
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderRecoveryDayCard(day, activities) {
  const isOpen = day.isToday;
  return `
    <div class="recovery-day-card">
      <div class="recovery-day-header" onclick="this.nextElementSibling.classList.toggle('open')">
        <div>
          <div class="recovery-day-num">Day ${day.day} ${day.isPast ? '✅' : day.isToday ? '← Today' : day.isFuture ? '🔒' : ''}</div>
          <div class="recovery-day-title">${day.title}</div>
        </div>
        <span style="color:var(--text-400);font-size:12px">${day.activities.length} activities ▾</span>
      </div>
      <div class="recovery-day-body ${isOpen ? 'open' : ''}">
        <p style="font-size:13px;color:var(--text-500);margin-bottom:12px">${day.focus}</p>
        <div style="display:flex;flex-direction:column;gap:10px">
          ${day.activities.map(act => `
            <div class="activity-card ${activities[act.id]?.status === 'done' ? 'completed' : ''}">
              <div class="activity-card-header">
                <span class="activity-icon">${act.icon}</span>
                <div>
                  <div class="activity-title">${act.title}</div>
                  <div class="activity-duration">${act.duration}</div>
                </div>
                ${activities[act.id]?.status === 'done' ? '<span class="tag tag-success">✅ Done</span>' : ''}
              </div>
              <div class="activity-desc">${act.desc}</div>
              ${!activities[act.id] || activities[act.id].status !== 'done'
                ? `<button class="btn btn-primary btn-sm mt-8 complete-activity-btn" data-activity="${act.id}">Mark as Done</button>`
                : ''
              }
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

window.RECOVERY_MODULE = { render: renderRecovery };
