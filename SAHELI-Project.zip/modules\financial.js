﻿// SAHELI Financial Well-Being Module
function renderFinancial() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">💰 Financial Wellness</div>
        <h1>Financial Well-Being</h1>
        <p>Financial stress significantly affects mental health. Let SAHELI help you understand your financial picture and find pathways to security.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-info mt-16">ℹ️ SAHELI provides general financial wellness guidance, not professional financial or legal advice. All data is stored privately on your device.</div>

        <!-- Income Allocation Calculator -->
        <div class="card mt-24">
          <div class="card-label">Monthly Income Allocation Calculator</div>
          <div class="card-title mt-8">Understand where your money goes</div>
          <div class="form-group mt-16">
            <label class="form-label">Monthly take-home income (₹)</label>
            <input type="number" class="form-input" id="monthlyIncome" placeholder="e.g., 30000" min="0" />
          </div>
          <div id="allocationSliders" class="mt-16" style="display:none">
            <div class="card-label mb-12">How do you currently allocate your income?</div>
            ${[
              ['Essential expenses', 'alloc_essential', 50, '(rent, food, utilities, transport, medical)'],
              ['Personal & discretionary', 'alloc_personal', 20, '(clothing, personal care, social, entertainment)'],
              ['Savings & emergency fund', 'alloc_savings', 20, '(savings account, emergency fund)'],
              ['Debt repayment', 'alloc_debt', 5, '(loans, EMIs, credit cards)'],
              ['Family support', 'alloc_family', 5, '(sending money home, children\'s expenses)']
            ].map(([label, id, val, hint]) => `
              <div class="calc-category">
                <div style="width:160px;font-size:13px;color:var(--text-700)">${label}</div>
                <div class="calc-bar">
                  <input type="range" min="0" max="100" value="${val}" id="${id}" class="alloc-slider" data-label="${label}" />
                </div>
                <div style="width:48px;text-align:right;font-size:13px;font-weight:700;color:var(--purple-700)" id="${id}_val">${val}%</div>
              </div>
              <div style="font-size:11px;color:var(--text-400);margin-bottom:12px;margin-left:172px">${hint}</div>
            `).join('')}
            <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--purple-50);border-radius:var(--radius-md)">
              <span style="font-size:13px;font-weight:600;color:var(--text-700)">Total allocated:</span>
              <span id="totalAlloc" style="font-size:18px;font-weight:700;color:var(--purple-700)">100%</span>
            </div>
            <div id="allocationResult" class="mt-16"></div>
          </div>
          <button class="btn btn-primary mt-16" id="calcIncomeBtn">Calculate →</button>
        </div>

        <!-- Financial Safety Checklist -->
        <div class="card mt-24">
          <div class="card-label">Financial Safety Checklist</div>
          <div class="card-title mt-8">Building your financial foundation</div>
          <div class="checklist mt-16" id="financialChecklist">
            ${[
              ['fin_1', 'I have my own bank account in my name'],
              ['fin_2', 'I know the household\'s monthly income and expenses'],
              ['fin_3', 'I have access to some emergency money (even a small amount)'],
              ['fin_4', 'My important documents (ID, bank details, property papers) are safely accessible to me'],
              ['fin_5', 'I have at least some financial independence or income of my own'],
              ['fin_6', 'I have a basic understanding of any loans or debts in my name'],
              ['fin_7', 'I know where to access financial support in an emergency (family, NGO, government scheme)'],
              ['fin_8', 'I have considered saving a small emergency fund, even ₹500-1000 per month']
            ].map(([id, text]) => {
              const checked = STATE.getChecklistState('financial')[id] === true;
              return `
                <div class="checklist-item ${checked ? 'checked' : ''}" onclick="toggleFinCheckbox('${id}',this)">
                  <div class="checklist-checkbox">${checked ? '✓' : ''}</div>
                  <div class="checklist-text">${text}</div>
                </div>`;
            }).join('')}
          </div>
          <div id="finChecklistSummary" class="mt-12"></div>
        </div>

        <!-- Government Schemes -->
        <div class="card mt-24">
          <div class="card-label">Government Financial Support for Women (India)</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:12px">
            ${[
              ['Pradhan Mantri Jan Dhan Yojana', 'Zero-balance bank account with RuPay debit card and insurance cover', 'pmjdy.gov.in'],
              ['PM SVANidhi Scheme', 'Micro-credit loans for street vendors (up to ₹50,000)', 'pmsvanidhi.mohua.gov.in'],
              ['Mahila E-Haat', 'Online platform for women entrepreneurs to sell products', 'mahilaehaat.gov.in'],
              ['Sukanya Samriddhi Yojana', 'Savings scheme for girl children — tax benefits and good interest rate', 'Through any post office or bank'],
              ['MUDRA Loans for Women', 'Business loans up to ₹10 lakh for women entrepreneurs', 'mudra.org.in'],
              ['Self Help Groups (SHGs)', 'Women\'s savings groups with access to credit — available through NABARD and state governments', 'Check your district office']
            ].map(([name, desc, source]) => `
              <div style="padding:12px;border:1px solid var(--border-light);border-radius:var(--radius-md)">
                <div style="font-size:13px;font-weight:700;color:var(--purple-700)">${name}</div>
                <div style="font-size:12px;color:var(--text-600);margin:4px 0">${desc}</div>
                <div style="font-size:11px;color:var(--text-400)">${source}</div>
              </div>
            `).join('')}
          </div>
          <div class="alert alert-warning mt-12">⚠️ Eligibility conditions and scheme availability vary. Please verify current details with the relevant government department or bank.</div>
        </div>

        <!-- Emergency Financial Safety -->
        <div class="card card-coral mt-24">
          <div class="card-label">If Financial Safety is Urgent</div>
          <p style="font-size:13px;color:var(--text-600);margin-top:8px;line-height:1.75">
            If financial control or abuse is part of a difficult situation at home, please know:
          </p>
          <ul style="padding-left:20px;margin-top:8px;font-size:13px;color:var(--text-700);line-height:2">
            <li>You have the right to open a bank account in your own name at any bank</li>
            <li>Many NGOs and shelters provide emergency financial support for women in crisis</li>
            <li>181 (Women Helpline) can connect you with local support organizations</li>
          </ul>
          <button class="btn btn-danger btn-sm mt-12" onclick="navigateTo('trauma-safety')">Safety Support →</button>
        </div>

      </div>
    </div>
  `;

  // Calculator
  document.getElementById('calcIncomeBtn').addEventListener('click', () => {
    const income = parseFloat(document.getElementById('monthlyIncome').value);
    if (!income || income <= 0) { showToast('Please enter your monthly income', 'warning'); return; }
    document.getElementById('allocationSliders').style.display = 'block';
    updateAllocationResult(income);
  });

  // Sliders
  document.querySelectorAll('.alloc-slider').forEach(slider => {
    slider.addEventListener('input', () => {
      document.getElementById(slider.id + '_val').textContent = slider.value + '%';
      updateTotalAlloc();
      const income = parseFloat(document.getElementById('monthlyIncome').value);
      if (income) updateAllocationResult(income);
    });
  });

  updateFinChecklistSummary();
}

function updateTotalAlloc() {
  const total = Array.from(document.querySelectorAll('.alloc-slider')).reduce((sum, s) => sum + parseInt(s.value), 0);
  const totalEl = document.getElementById('totalAlloc');
  if (totalEl) {
    totalEl.textContent = total + '%';
    totalEl.style.color = total === 100 ? 'var(--success)' : total > 100 ? 'var(--danger)' : 'var(--warning)';
  }
}

function updateAllocationResult(income) {
  const sliders = document.querySelectorAll('.alloc-slider');
  const area = document.getElementById('allocationResult');
  if (!area) return;
  let html = '<div class="card-label mb-12">Your Monthly Budget Breakdown</div><div style="display:flex;flex-direction:column;gap:8px">';
  sliders.forEach(s => {
    const pct = parseInt(s.value);
    const amount = Math.round((pct / 100) * income);
    html += `
      <div style="display:flex;align-items:center;gap:12px">
        <div style="width:160px;font-size:12px;color:var(--text-600)">${s.dataset.label}</div>
        <div style="flex:1"><div class="progress-bar" style="height:6px;margin:0"><div class="progress-fill" style="width:${pct}%"></div></div></div>
        <div style="width:80px;text-align:right;font-size:12px;font-weight:700;color:var(--purple-700)">₹${amount.toLocaleString('en-IN')}</div>
      </div>`;
  });
  html += `</div>`;
  const savingsPct = parseInt(document.getElementById('alloc_savings').value);
  if (savingsPct < 10) {
    html += `<div class="alert alert-warning mt-12">💡 Financial wellness experts generally suggest saving at least 10-20% of income. Even ₹${Math.round(income*0.1).toLocaleString('en-IN')}/month builds a meaningful emergency fund over time.</div>`;
  } else {
    html += `<div class="alert alert-success mt-12">✅ You're allocating ${savingsPct}% (₹${Math.round((savingsPct/100)*income).toLocaleString('en-IN')}) to savings — a healthy financial habit!</div>`;
  }
  area.innerHTML = html;
}

function toggleFinCheckbox(id, el) {
  const isChecked = el.classList.contains('checked');
  el.classList.toggle('checked', !isChecked);
  const box = el.querySelector('.checklist-checkbox');
  box.textContent = isChecked ? '' : '✓';
  STATE.toggleChecklistItem('financial', id, !isChecked);
  updateFinChecklistSummary();
}

function updateFinChecklistSummary() {
  const state = STATE.getChecklistState('financial');
  const total = 8;
  const checked = Object.values(state).filter(v => v).length;
  const summary = document.getElementById('finChecklistSummary');
  if (!summary) return;
  const pct = Math.round((checked / total) * 100);
  summary.innerHTML = `
    <div class="checklist-summary">${checked} of ${total} completed (${pct}%)</div>
    ${checked < 3 ? '<div class="alert alert-warning mt-8">Building financial foundations takes time. Start with one step — even opening a bank account in your own name is meaningful progress.</div>' : ''}
    ${checked >= 6 ? '<div class="alert alert-success mt-8">You have a strong financial foundation. Keep building and maintaining your safety net.</div>' : ''}`;
}

window.FINANCIAL_MODULE = { render: renderFinancial };
window.toggleFinCheckbox = toggleFinCheckbox;
