﻿// SAHELI Menopause Module
function renderMenopause() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">🌸 Menopause Care</div>
        <h1>Menopause & Midlife Wellness</h1>
        <p>An informed, compassionate space to understand menopause, track symptoms, and support your wellbeing through this transition.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-info mt-16">ℹ️ SAHELI provides general information and self-care guidance. For medical advice, treatment decisions, and symptom assessment, please consult your gynaecologist or doctor.</div>

        <!-- Symptoms Tracker -->
        <div class="card mt-24">
          <div class="card-label">Symptom Tracker (Today)</div>
          <div class="card-title mt-8">How is menopause affecting you today?</div>
          <div class="card-grid-3 mt-16" id="menopauseSymptomGrid">
            ${[
              ['🔥','Hot flashes','Sudden waves of heat, sweating, flushing','hot_flash'],
              ['🌙','Sleep disturbance','Night sweats, insomnia, or poor sleep quality','sleep'],
              ['😔','Mood changes','Anxiety, depression, irritability, or mood swings','mood'],
              ['🧠','Brain fog','Memory lapses, difficulty concentrating','brain'],
              ['💔','Vaginal discomfort','Dryness, discomfort, or changes in libido','vaginal'],
              ['🦴','Joint & muscle pain','Aches, stiffness, or new joint pain','joint'],
              ['💓','Heart palpitations','Racing or irregular heartbeat','palpitations'],
              ['⚡','Fatigue','Unusual or persistent tiredness','fatigue'],
              ['🌊','Irregular periods','Changes in cycle frequency, duration, or flow','irregular']
            ].map(([icon, title, desc, id]) => `
              <div class="concern-card" id="menSym_${id}" onclick="toggleMenopauseSymptom('${id}',this)">
                <div class="concern-icon">${icon}</div>
                <div class="concern-title">${title}</div>
                <div class="concern-desc">${desc}</div>
              </div>
            `).join('')}
          </div>
          <div style="display:flex;align-items:center;gap:12px;margin-top:20px;flex-wrap:wrap">
            <button class="btn btn-primary" id="saveMenSymBtn">Save Today's Symptoms</button>
            <button class="btn btn-secondary" onclick="document.getElementById('menopauseDetail').innerHTML=generateMenopauseGuidance(getSelectedMenSymptoms())">Get Guidance →</button>
          </div>
        </div>

        <div id="menopauseDetail" class="mt-16"></div>

        <!-- Phases -->
        <div class="card mt-24">
          <div class="card-label">Understanding the Menopause Transition</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:12px">
            ${[
              ['Perimenopause', 'Typically begins in mid-40s', 'Irregular periods, increasing symptoms. Hormones are fluctuating. Can last 4-10 years.','purple'],
              ['Menopause', 'Average age ~51 in India', '12 consecutive months without a period. Estrogen is at a low stable level.','coral'],
              ['Postmenopause', 'After the 12-month mark', 'Symptoms often improve. Long-term health focus shifts to bone density, heart health, and overall wellbeing.','sage']
            ].map(([phase, timing, desc, color]) => `
              <div style="padding:14px;background:var(--${color}-50);border:1px solid var(--${color}-200);border-radius:var(--radius-md)">
                <div style="font-size:14px;font-weight:700;color:var(--text-800)">${phase}</div>
                <div style="font-size:11px;color:var(--${color}-500);font-weight:600;margin:3px 0">${timing}</div>
                <div style="font-size:12px;color:var(--text-600)">${desc}</div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Emotional Wellness -->
        <div class="card card-lavender mt-24">
          <div class="card-label">Emotional Wellness During Menopause</div>
          <p style="font-size:13px;color:var(--text-600);margin-top:8px;line-height:1.75">Hormonal changes directly affect mood, energy, and mental health. Many women experience anxiety, low mood, or irritability during perimenopause. This is a physiological reality — not a mental health weakness.</p>
          <ul style="padding-left:20px;margin-top:12px;font-size:13px;color:var(--text-700);line-height:2">
            <li>Estrogen has a significant effect on serotonin and mood regulation</li>
            <li>Poor sleep (from night sweats) compounds mood difficulties</li>
            <li>Life stressors (career, family, ageing parents, relationships) often peak at the same time</li>
            <li>Menopause can trigger grief around fertility and identity shifts</li>
          </ul>
          <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
            <button class="btn btn-primary btn-sm" onclick="navigateTo('ai-chat')">Talk to SAHELI AI</button>
            <button class="btn btn-secondary btn-sm" onclick="navigateTo('professionals')">Find Support</button>
          </div>
        </div>

        <div class="alert alert-warning mt-24">⚠️ If you experience very heavy bleeding, periods returning after 12+ months of absence, or symptoms that are severely affecting your quality of life, please consult your gynaecologist. These may require medical evaluation.</div>
      </div>
    </div>
  `;

  document.getElementById('saveMenSymBtn').addEventListener('click', () => {
    const symptoms = getSelectedMenSymptoms();
    if (symptoms.length === 0) { showToast('Select at least one symptom', 'warning'); return; }
    showToast(`Symptoms saved: ${symptoms.join(', ')}`, 'success');
  });
}

let selectedMenSymptoms = [];
function toggleMenopauseSymptom(id, el) {
  if (selectedMenSymptoms.includes(id)) {
    selectedMenSymptoms = selectedMenSymptoms.filter(s => s !== id);
    el.classList.remove('selected');
  } else {
    selectedMenSymptoms.push(id);
    el.classList.add('selected');
  }
}
function getSelectedMenSymptoms() { return selectedMenSymptoms; }

function generateMenopauseGuidance(symptoms) {
  if (symptoms.length === 0) return '<div class="alert alert-info">Select your symptoms above to receive personalized guidance.</div>';
  const tips = {
    hot_flash: '<strong>Hot Flashes:</strong> Dress in layers, keep bedroom cool, avoid triggers (spicy food, caffeine, alcohol, hot beverages). A cooling towel or fan can help. Some find relief with paced breathing.',
    sleep: '<strong>Sleep Disturbance:</strong> Keep your bedroom cool and well-ventilated. Natural fabrics may help. A consistent bedtime routine and limiting screens before bed is important. Speak with your doctor if sleep is severely disrupted.',
    mood: '<strong>Mood Changes:</strong> Regular gentle exercise, social connection, stress management, and good sleep all support mood. A counsellor or therapist familiar with menopause can be very helpful. If symptoms are significant, your doctor may discuss additional options.',
    brain: '<strong>Brain Fog:</strong> Often related to sleep disruption. Lists, reminders, and routine help. Aerobic exercise supports cognitive function. Reassure yourself — this typically improves post-menopause.',
    vaginal: '<strong>Vaginal Discomfort:</strong> Over-the-counter water-based lubricants can help with dryness. Please speak with your gynaecologist — effective treatments (including local estrogen) are available.',
    joint: '<strong>Joint & Muscle Pain:</strong> Gentle movement (yoga, walking, swimming) helps. Anti-inflammatory foods may support. If severe, physiotherapy or medical evaluation is recommended.',
    fatigue: '<strong>Fatigue:</strong> Prioritise sleep, manage stress, and stay active. Check with your doctor to rule out thyroid issues or anaemia, which can also cause fatigue.'
  };
  const relevant = symptoms.filter(s => tips[s]);
  if (relevant.length === 0) return '<div class="alert alert-info">Talk to your doctor about your specific symptoms for personalized guidance.</div>';
  return `<div class="card card-sage"><div class="card-label">Guidance for Your Symptoms</div><div style="margin-top:12px;display:flex;flex-direction:column;gap:12px">${relevant.map(s => `<div style="font-size:13px;color:var(--text-700);padding:10px 0;border-bottom:1px solid var(--sage-300)">${tips[s]}</div>`).join('')}</div><div class="alert alert-warning mt-12">These are general wellness suggestions, not medical treatment. Always consult your gynaecologist for medical assessment and treatment options.</div></div>`;
}

window.MENOPAUSE_MODULE = { render: renderMenopause };
window.toggleMenopauseSymptom = toggleMenopauseSymptom;
window.getSelectedMenSymptoms = getSelectedMenSymptoms;
window.generateMenopauseGuidance = generateMenopauseGuidance;
