﻿// SAHELI Private Journal Module
function renderJournal() {
  const container = document.getElementById('moduleContainer');
  const entries = STATE.get('journalEntries') || [];
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">📔 Your Private Space</div>
        <h1>My Private Journal</h1>
        <p>Write, reflect, and explore your inner world. Everything here is private and stored only on your device.</p>
      </div>
      <div class="module-content-wide" style="display:grid;grid-template-columns:1fr 360px;gap:24px;align-items:start;padding:28px 32px">
        <!-- Writing Area -->
        <div>
          <div class="card" id="journalWritingCard">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
              <div class="card-label">New Entry — ${new Date().toLocaleDateString('en-IN', {weekday:'long', day:'numeric', month:'long'})}</div>
              <div style="display:flex;gap:8px">
                <button class="btn btn-outline btn-sm" id="journalVoiceBtn" title="Voice input">🎤 Voice</button>
                <button class="btn btn-outline btn-sm" id="aiSummarizeBtn">✨ AI Summary</button>
              </div>
            </div>

            <!-- Mood for entry -->
            <div class="form-group">
              <label class="form-label">How are you feeling right now?</label>
              <div style="display:flex;gap:8px;flex-wrap:wrap" id="journalMoodRow">
                ${[['😊','Happy'],['😌','Calm'],['🙂','Okay'],['😰','Anxious'],['😔','Low'],['😵','Overwhelmed'],['😡','Frustrated'],['😴','Tired']].map(([e,m]) =>
                  `<button class="mood-btn" data-mood="${m}" style="min-width:60px;padding:8px 6px;font-size:10px"><span class="mood-emoji" style="font-size:20px">${e}</span><span>${m}</span></button>`
                ).join('')}
              </div>
            </div>

            <!-- Title -->
            <div class="form-group">
              <input type="text" class="form-input" id="journalTitle" placeholder="Entry title (optional)" maxlength="100" />
            </div>

            <!-- Main Text -->
            <div class="form-group">
              <textarea class="form-textarea" id="journalText" placeholder="What's on your mind today? Write freely — there are no rules here. This is your space." rows="10" style="min-height:200px"></textarea>
            </div>

            <!-- Voice Transcript Area -->
            <div id="journalVoiceArea" style="display:none;padding:12px;background:var(--purple-50);border-radius:var(--radius-md);margin-bottom:16px;font-size:13px;color:var(--text-600);font-style:italic" id="voiceTranscriptDisplay">
              Listening...
            </div>

            <!-- Tags -->
            <div class="form-group">
              <label class="form-label">Tags (optional)</label>
              <div style="display:flex;gap:8px;flex-wrap:wrap" id="journalTagRow">
                ${['Grateful','Struggling','Hopeful','Tired','Processing','Milestone'].map(tag =>
                  `<button class="tag tag-purple journal-tag-btn" data-tag="${tag}" style="cursor:pointer">${tag}</button>`
                ).join('')}
              </div>
              <input type="text" class="form-input mt-8" id="journalTagInput" placeholder="Add custom tag..." style="font-size:12px" />
            </div>

            <!-- Link to Recovery -->
            <div class="form-group">
              <label class="toggle-row">
                <span>Link to my recovery journey</span>
                <label class="toggle-switch"><input type="checkbox" id="journalLinkRecovery" /><span class="toggle-slider"></span></label>
              </label>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap">
              <button class="btn btn-primary" id="saveJournalBtn">Save Entry 💜</button>
              <button class="btn btn-outline" id="clearJournalBtn">Clear</button>
            </div>

            <!-- AI Summary Area -->
            <div id="aiSummaryArea" style="display:none;margin-top:16px"></div>
          </div>
        </div>

        <!-- Entries List -->
        <div>
          <div class="section-header">
            <div class="section-title" style="font-size:16px">Your Entries (${entries.length})</div>
          </div>
          ${entries.length === 0 ? `
            <div class="empty-state" style="padding:24px">
              <div class="empty-state-icon">📔</div>
              <div class="empty-state-title" style="font-size:14px">No entries yet</div>
              <div class="empty-state-desc" style="font-size:12px">Your journal is waiting for your first thought.</div>
            </div>
          ` : `
            <div id="entriesList">
              ${entries.slice(0, 20).map(entry => renderJournalEntry(entry)).join('')}
            </div>
            ${entries.length > 20 ? `<button class="btn btn-outline btn-full mt-12" onclick="loadMoreEntries()">Load More</button>` : ''}
          `}
        </div>
      </div>
    </div>
  `;

  setupJournalHandlers();
}

function renderJournalEntry(entry) {
  const moodEmojis = { Happy:'😊', Calm:'😌', Okay:'🙂', Anxious:'😰', Low:'😔', Overwhelmed:'😵', Frustrated:'😡', Tired:'😴' };
  const date = new Date(entry.date).toLocaleDateString('en-IN', {day:'numeric', month:'short', year:'numeric'});
  return `
    <div class="journal-entry" data-entry-id="${entry.id}">
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div class="journal-entry-date">${date} ${entry.mood ? moodEmojis[entry.mood] || '' : ''}</div>
        <button class="btn btn-danger btn-sm" style="padding:3px 8px;font-size:10px" onclick="deleteEntry(${entry.id});event.stopPropagation()">Delete</button>
      </div>
      ${entry.title ? `<div style="font-size:13px;font-weight:600;color:var(--text-800);margin:4px 0">${entry.title}</div>` : ''}
      <div class="journal-entry-preview">${entry.text || '(No text)'}</div>
      ${entry.tags?.length ? `<div style="margin-top:4px;display:flex;gap:4px;flex-wrap:wrap">${entry.tags.map(t => `<span class="tag tag-purple" style="font-size:10px">${t}</span>`).join('')}</div>` : ''}
    </div>
  `;
}

function setupJournalHandlers() {
  let selectedMood = '';
  let selectedTags = [];

  // Mood selection
  document.getElementById('journalMoodRow').addEventListener('click', (e) => {
    const btn = e.target.closest('.mood-btn');
    if (!btn) return;
    selectedMood = btn.dataset.mood;
    document.querySelectorAll('#journalMoodRow .mood-btn').forEach(b => b.classList.toggle('selected', b === btn));
  });

  // Tag selection
  document.getElementById('journalTagRow').addEventListener('click', (e) => {
    const btn = e.target.closest('.journal-tag-btn');
    if (!btn) return;
    const tag = btn.dataset.tag;
    if (selectedTags.includes(tag)) {
      selectedTags = selectedTags.filter(t => t !== tag);
      btn.classList.remove('tag-coral');
      btn.classList.add('tag-purple');
    } else {
      selectedTags.push(tag);
      btn.classList.remove('tag-purple');
      btn.classList.add('tag-coral');
    }
  });

  // Voice input
  const voiceBtn = document.getElementById('journalVoiceBtn');
  const journalText = document.getElementById('journalText');
  const voiceArea = document.getElementById('journalVoiceArea');

  voiceBtn.addEventListener('click', () => {
    if (VOICE.isRecording) {
      VOICE.stopRecording();
      voiceBtn.textContent = '🎤 Voice';
      return;
    }
    voiceArea.style.display = 'block';
    voiceArea.textContent = 'Listening...';
    VOICE.onResult = (text, isFinal) => {
      voiceArea.textContent = text;
      if (isFinal) {
        journalText.value = (journalText.value ? journalText.value + '\n' : '') + text;
        voiceBtn.textContent = '🎤 Voice';
      }
    };
    VOICE.onStart = () => { voiceBtn.textContent = '⏹ Stop'; };
    VOICE.onEnd = () => { voiceBtn.textContent = '🎤 Voice'; setTimeout(() => { voiceArea.style.display = 'none'; }, 2000); };
    VOICE.onError = () => { voiceBtn.textContent = '🎤 Voice'; voiceArea.style.display = 'none'; showToast('Voice not available', 'warning'); };
    VOICE.startRecording();
    voiceBtn.textContent = '⏹ Stop';
  });

  // AI Summary
  document.getElementById('aiSummarizeBtn').addEventListener('click', async () => {
    const text = journalText.value.trim();
    if (!text) { showToast('Write something first, then I can summarize', 'warning'); return; }
    const summaryArea = document.getElementById('aiSummaryArea');
    summaryArea.style.display = 'block';
    summaryArea.innerHTML = '<div class="loading-overlay"><div class="loading-spinner"></div><div class="loading-text">SAHELI is reading your entry...</div></div>';
    const result = await AI.chat(`Please provide a compassionate, brief (3-4 sentence) summary of this journal entry, noting the main feelings and themes. Don't offer unsolicited advice: "${text}"`, { module: 'journal' });
    summaryArea.innerHTML = `
      <div class="alert alert-info">
        <strong>✨ AI Summary (Based on your words):</strong><br>
        <em style="font-size:12px;color:var(--text-400)">This summary was generated by AI and may not perfectly reflect your experience.</em><br><br>
        ${result.text.replace(/\n/g, '<br>')}
      </div>
      <button class="btn btn-outline btn-sm" onclick="document.getElementById('aiSummaryArea').style.display='none'">Close summary</button>
    `;
  });

  // Custom tag
  const tagInput = document.getElementById('journalTagInput');
  tagInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && tagInput.value.trim()) {
      selectedTags.push(tagInput.value.trim());
      tagInput.value = '';
    }
  });

  // Save
  document.getElementById('saveJournalBtn').addEventListener('click', () => {
    const text = journalText.value.trim();
    const title = document.getElementById('journalTitle').value.trim();
    if (!text && !title) { showToast('Please write something first', 'warning'); return; }
    const customTag = document.getElementById('journalTagInput').value.trim();
    if (customTag) selectedTags.push(customTag);
    const entry = STATE.addJournalEntry({ text, title, mood: selectedMood, tags: [...selectedTags] });
    showToast('Journal entry saved 💜', 'success');
    journalText.value = '';
    document.getElementById('journalTitle').value = '';
    document.getElementById('journalTagInput').value = '';
    selectedMood = '';
    selectedTags = [];
    document.querySelectorAll('#journalMoodRow .mood-btn').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll('.journal-tag-btn').forEach(b => { b.classList.remove('tag-coral'); b.classList.add('tag-purple'); });
    // Add to list
    const list = document.getElementById('entriesList');
    if (list) list.insertAdjacentHTML('afterbegin', renderJournalEntry(entry));
  });

  // Clear
  document.getElementById('clearJournalBtn').addEventListener('click', () => {
    if (confirm('Clear what you\'ve written? This cannot be undone.')) {
      journalText.value = '';
      document.getElementById('journalTitle').value = '';
    }
  });

  // Entry click (view full entry)
  document.addEventListener('click', (e) => {
    const entry = e.target.closest('.journal-entry[data-entry-id]');
    if (!entry || e.target.tagName === 'BUTTON') return;
    const id = parseInt(entry.dataset.entryId);
    const stored = (STATE.get('journalEntries') || []).find(e => e.id === id);
    if (stored) viewJournalEntry(stored);
  });
}

function viewJournalEntry(entry) {
  const moodEmojis = { Happy:'😊', Calm:'😌', Okay:'🙂', Anxious:'😰', Low:'😔', Overwhelmed:'😵', Frustrated:'😡', Tired:'😴' };
  const modal = document.createElement('div');
  modal.style.cssText = 'position:fixed;inset:0;z-index:500;background:rgba(15,5,30,0.5);display:flex;align-items:center;justify-content:center';
  modal.innerHTML = `
    <div style="background:white;border-radius:var(--radius-xl);padding:28px;max-width:560px;width:calc(100% - 32px);max-height:80vh;overflow-y:auto;box-shadow:var(--shadow-xl)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <div style="font-size:11px;color:var(--text-400)">${new Date(entry.date).toLocaleDateString('en-IN', {weekday:'long', day:'numeric', month:'long', year:'numeric'})} ${entry.mood ? moodEmojis[entry.mood] || '' : ''}</div>
        <button onclick="this.closest('[style]').remove()" style="background:var(--bg-secondary);border:none;width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:16px">✕</button>
      </div>
      ${entry.title ? `<h3 style="font-size:20px;font-family:var(--font-serif);margin-bottom:12px">${entry.title}</h3>` : ''}
      <div style="font-size:14px;color:var(--text-700);line-height:1.75;white-space:pre-wrap">${entry.text || ''}</div>
      ${entry.tags?.length ? `<div style="margin-top:12px;display:flex;gap:6px;flex-wrap:wrap">${entry.tags.map(t => `<span class="tag tag-purple">${t}</span>`).join('')}</div>` : ''}
      <div style="display:flex;gap:8px;margin-top:20px;flex-wrap:wrap">
        <button class="btn btn-secondary btn-sm" onclick="VOICE.speak(\`${(entry.text||'').replace(/'/g, "'").substring(0,500)}\`)">🔊 Read Aloud</button>
        <button class="btn btn-danger btn-sm" onclick="deleteEntry(${entry.id});this.closest('[style]').remove()">Delete Entry</button>
        <button class="btn btn-outline btn-sm" onclick="this.closest('[style]').remove()">Close</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
}

function deleteEntry(id) {
  if (!confirm('Delete this journal entry? This cannot be undone.')) return;
  STATE.deleteJournalEntry(id);
  const el = document.querySelector(`[data-entry-id="${id}"]`);
  if (el) el.remove();
  showToast('Entry deleted', 'success');
}

window.JOURNAL_MODULE = { render: renderJournal };
window.deleteEntry = deleteEntry;
