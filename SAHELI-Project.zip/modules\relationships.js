﻿// SAHELI Relationships Module
function renderRelationships() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">💞 Relationships</div>
        <h1>Relationships & Family</h1>
        <p>Explore concerns about relationships, boundaries, communication, and family dynamics — with compassion and no judgment.</p>
      </div>
      <div class="module-content">
        <div class="concern-grid mt-24" id="relConcernGrid">
          ${[
            ['💔','Relationship conflict','Arguments, misunderstandings, or ongoing tension with a partner or family member.','conflict'],
            ['🚧','Boundaries','Difficulty setting or maintaining healthy boundaries with others.','boundaries'],
            ['💬','Communication','Struggling to express yourself or be heard in relationships.','communication'],
            ['💑','Partnership concerns','Worries about your relationship with a partner — trust, intimacy, or future.','partnership'],
            ['👨‍👩‍👧','Family pressure','Expectations from family that feel overwhelming or unfair.','family'],
            ['💜','Emotional safety','Feeling unsafe, controlled, or emotionally hurt in a relationship.','safety'],
            ['💔','Separation or divorce','Navigating the end of a relationship or marriage.','separation'],
            ['🌱','Growing together','Wanting to improve your relationship and communication skills.','growth']
          ].map(([icon, title, desc, id]) => `
            <div class="concern-card" onclick="openRelConcern('${id}','${title}')">
              <div class="concern-icon">${icon}</div>
              <div class="concern-title">${title}</div>
              <div class="concern-desc">${desc}</div>
            </div>
          `).join('')}
        </div>
        <div id="relDetailArea" class="mt-24"></div>
        <div class="card card-coral mt-24">
          <div class="card-label">⚠️ If Your Safety is Concerned</div>
          <p style="font-size:13px;color:var(--text-600);margin-top:8px">If a relationship involves physical harm, coercion, threats, or you feel unsafe, please reach out for support:</p>
          <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
            <a href="tel:181" class="btn btn-danger btn-sm">🌸 181 — Women Helpline</a>
            <a href="tel:112" class="btn btn-danger btn-sm">📞 112 — Emergency</a>
            <button class="btn btn-secondary btn-sm" onclick="navigateTo('trauma-safety')">Trauma & Safety Support →</button>
          </div>
        </div>
      </div>
    </div>
  `;
}

const REL_CONTENT = {
  conflict: {
    title: 'Relationship Conflict',
    guidance: [
      { icon: '🎯', title: 'Identify the core issue', desc: 'Beneath most arguments is an unmet need or fear. Ask yourself: What do I really need here? What am I afraid of?' },
      { icon: '👂', title: 'Practice active listening', desc: 'Try to understand before being understood. Repeat back what you heard: "It sounds like you feel..." before responding.' },
      { icon: '🌡️', title: 'Take a cooling-off break', desc: 'If emotions are very high, agree to pause for 20-30 minutes before continuing. This reduces reactivity.' },
      { icon: '💬', title: '"I feel" statements', desc: 'Say "I feel hurt when..." instead of "You always..." I-statements are less likely to trigger defensiveness.' },
      { icon: '🤝', title: 'Seek mutual understanding', desc: 'The goal is understanding, not winning. What can both people agree is true about this situation?' }
    ],
    professional: 'A couples counsellor or therapist can help if conflicts are repetitive, distressing, or feel unresolvable on your own.'
  },
  boundaries: {
    title: 'Setting Boundaries',
    guidance: [
      { icon: '🌱', title: 'Understand what you need', desc: 'Boundaries protect your values and wellbeing. What behaviours or situations are affecting you negatively?' },
      { icon: '💬', title: 'Communicate clearly and kindly', desc: 'State your boundary simply: "I\'m not comfortable with... I need..." You don\'t need to over-explain or apologise.' },
      { icon: '🔄', title: 'Be consistent', desc: 'Boundaries only work if followed through. If a boundary is crossed, restate it calmly and follow through on what you said.' },
      { icon: '💜', title: 'Manage guilt', desc: 'It is normal to feel guilty when setting boundaries, especially if people react with anger or hurt. Guilt doesn\'t mean you did something wrong.' },
      { icon: '🛡️', title: 'Know the difference from control', desc: 'Your boundaries are about your choices and behaviour — not controlling another person\'s actions.' }
    ],
    professional: 'If setting boundaries feels impossible or terrifying, a therapist can help you explore why and build this skill safely.'
  },
  safety: {
    title: 'Emotional Safety in Relationships',
    guidance: [
      { icon: '🚨', title: 'Recognise warning signs', desc: 'Emotional abuse includes: constant criticism, humiliation, isolation from friends/family, controlling behaviour, gaslighting (making you doubt reality), and threats.' },
      { icon: '🤔', title: 'Trust your feelings', desc: 'If you consistently feel afraid, humiliated, confused, or walking on eggshells — these feelings matter. You deserve to feel safe.' },
      { icon: '📞', title: 'Reach out for support', desc: 'Tell someone you trust. Contact 181 (Women\'s Helpline) or 14416 (Tele-MANAS). You don\'t have to manage this alone.' },
      { icon: '🌱', title: 'Safety planning', desc: 'If you feel unsafe, having a plan (trusted contact, safe place, important documents) increases your options.' }
    ],
    professional: 'A trauma-informed counsellor can provide support whether or not you choose to leave the relationship. Your safety and wellbeing come first.',
    urgent: true
  }
};

function openRelConcern(id, title) {
  const area = document.getElementById('relDetailArea');
  const content = REL_CONTENT[id];
  if (!content) {
    // AI-assisted response for unlisted concerns
    area.innerHTML = `
      <div class="card">
        <div class="card-label">${title}</div>
        <div class="card-title mt-8">Let's explore this together</div>
        <p style="font-size:13px;color:var(--text-500);margin-top:8px">SAHELI can offer personalized guidance through AI chat, or you can explore a tailored assessment.</p>
        <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap">
          <button class="btn btn-primary" onclick="navigateTo('ai-chat')">Talk to SAHELI AI →</button>
          <button class="btn btn-secondary" onclick="navigateTo('concerns')">Full Assessment →</button>
          <button class="btn btn-outline" onclick="document.getElementById('relDetailArea').innerHTML=''">Close</button>
        </div>
      </div>`;
    return;
  }

  area.innerHTML = `
    <div class="card ${content.urgent ? 'card-coral' : 'card-purple'}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <div class="card-label">${content.title}</div>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('relDetailArea').innerHTML=''">✕ Close</button>
      </div>
      ${content.urgent ? `<div class="alert alert-danger mb-16">⚠️ If you feel unsafe right now, please call 181 or 112 immediately. You don't need to stay in an unsafe situation.</div>` : ''}
      <div style="display:flex;flex-direction:column;gap:12px">
        ${content.guidance.map(g => `
          <div style="display:flex;gap:12px;padding:12px;background:rgba(255,255,255,0.6);border-radius:var(--radius-md)">
            <span style="font-size:22px">${g.icon}</span>
            <div>
              <div style="font-size:13px;font-weight:600;color:var(--text-800)">${g.title}</div>
              <div style="font-size:12px;color:var(--text-600);margin-top:3px;line-height:1.6">${g.desc}</div>
            </div>
          </div>
        `).join('')}
      </div>
      <div class="alert alert-info mt-16"><strong>Professional Support:</strong> ${content.professional}</div>
      <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="navigateTo('ai-chat')">Talk to SAHELI AI</button>
        <button class="btn btn-secondary btn-sm" onclick="navigateTo('professionals')">Find a Counsellor</button>
      </div>
    </div>
  `;
  area.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

window.RELATIONSHIPS_MODULE = { render: renderRelationships };
window.openRelConcern = openRelConcern;
