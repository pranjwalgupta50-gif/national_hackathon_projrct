﻿// SAHELI Voice Module - Speech Recognition & Synthesis
class SAHELIVoice {
  constructor() {
    this.recognition = null;
    this.synthesis = window.speechSynthesis;
    this.voices = [];
    this.preferredVoice = null;
    this.rate = 1.0;
    this.isRecording = false;
    this.onResult = null;
    this.onError = null;
    this.onStart = null;
    this.onEnd = null;
    this.init();
  }

  init() {
    // Load voices
    if (this.synthesis) {
      const loadVoices = () => {
        this.voices = this.synthesis.getVoices();
        this.selectBestVoice();
        this.populateVoiceSelector();
      };
      loadVoices();
      this.synthesis.onvoiceschanged = loadVoices;
    }

    // Init recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.lang = this.getLangCode();

      this.recognition.onresult = (event) => {
        const transcript = Array.from(event.results).map(r => r[0].transcript).join('');
        const isFinal = event.results[event.results.length - 1].isFinal;
        if (this.onResult) this.onResult(transcript, isFinal);
      };

      this.recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        this.isRecording = false;
        if (this.onError) this.onError(event.error);
      };

      this.recognition.onstart = () => {
        this.isRecording = true;
        if (this.onStart) this.onStart();
      };

      this.recognition.onend = () => {
        this.isRecording = false;
        if (this.onEnd) this.onEnd();
      };
    }
  }

  getLangCode() {
    const lang = STATE.get('language') || 'en';
    const map = { en: 'en-IN', hi: 'hi-IN', bn: 'bn-IN', ta: 'ta-IN', te: 'te-IN', mr: 'mr-IN', gu: 'gu-IN', kn: 'kn-IN', ml: 'ml-IN', pa: 'pa-IN', ur: 'ur-PK' };
    return map[lang] || 'en-IN';
  }

  selectBestVoice() {
    const lang = STATE.get('language') || 'en';
    const langCode = this.getLangCode().split('-')[0].toLowerCase();
    const savedIdx = STATE.get('voiceIndex');

    if (savedIdx >= 0 && this.voices[savedIdx]) {
      this.preferredVoice = this.voices[savedIdx];
      return;
    }

    // Prefer female Indian English or language-specific voice
    const preferred = this.voices.filter(v => {
      const name = v.name.toLowerCase();
      const lang_ = v.lang.toLowerCase();
      return lang_.startsWith(langCode) && (name.includes('female') || name.includes('woman') || name.includes('zira') || name.includes('heera') || name.includes('aria') || !name.includes('male'));
    });

    if (preferred.length > 0) { this.preferredVoice = preferred[0]; return; }

    // Fallback: any English female
    const engFemale = this.voices.filter(v => v.lang.startsWith('en') && !v.name.toLowerCase().includes('male'));
    if (engFemale.length > 0) { this.preferredVoice = engFemale[0]; return; }

    // Last resort: first voice
    if (this.voices.length > 0) this.preferredVoice = this.voices[0];
  }

  populateVoiceSelector() {
    const sel = document.getElementById('settingsVoice');
    if (!sel) return;
    sel.innerHTML = '<option value="-1">Auto-select female voice</option>';
    this.voices.forEach((v, i) => {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = `${v.name} (${v.lang})`;
      sel.appendChild(opt);
    });
    const saved = STATE.get('voiceIndex');
    if (saved >= 0) sel.value = saved;
  }

  startRecording() {
    if (!this.recognition) {
      if (this.onError) this.onError('Speech recognition not supported in this browser.');
      return;
    }
    if (this.isRecording) return;
    this.recognition.lang = this.getLangCode();
    try { this.recognition.start(); } catch(e) { console.warn('Recognition start error:', e); }
  }

  stopRecording() {
    if (this.recognition && this.isRecording) {
      try { this.recognition.stop(); } catch(e) {}
    }
  }

  speak(text, onEnd) {
    if (!this.synthesis || !text) return;
    this.synthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    if (this.preferredVoice) utterance.voice = this.preferredVoice;
    utterance.rate = STATE.get('speechRate') || 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    if (onEnd) utterance.onend = onEnd;
    this.synthesis.speak(utterance);
  }

  stopSpeaking() {
    if (this.synthesis) this.synthesis.cancel();
  }

  isSupported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  }

  isSpeechSupported() {
    return !!window.speechSynthesis;
  }

  // Create a reusable voice control bar
  createVoiceBar(onTranscript, placeholder) {
    const bar = document.createElement('div');
    bar.className = 'voice-control-bar';
    bar.innerHTML = `
      <button class="voice-btn voice-btn-mic" id="voiceMicBtn" title="Click to speak" aria-label="Start voice input">🎤</button>
      <div style="flex:1">
        <div class="voice-transcript" id="voiceTranscript">${placeholder || t('voiceReady')}</div>
        <div class="voice-status" id="voiceStatus">${this.isSupported() ? 'Voice input ready' : 'Voice not supported in this browser'}</div>
      </div>
      ${this.isSpeechSupported() ? '<button class="btn btn-outline btn-sm" id="voiceSpeakBtn" title="Read aloud">🔊</button>' : ''}
    `;

    const micBtn = bar.querySelector('#voiceMicBtn');
    const transcript = bar.querySelector('#voiceTranscript');
    const status = bar.querySelector('#voiceStatus');
    let currentText = '';

    this.onResult = (text, isFinal) => {
      currentText = text;
      transcript.textContent = text;
      if (isFinal && onTranscript) onTranscript(text);
    };
    this.onStart = () => {
      micBtn.classList.add('recording');
      status.textContent = t('recording');
    };
    this.onEnd = () => {
      micBtn.classList.remove('recording');
      status.textContent = 'Tap to speak';
    };
    this.onError = (err) => {
      micBtn.classList.remove('recording');
      if (err === 'not-allowed') {
        status.textContent = 'Microphone permission denied. Please allow microphone access.';
      } else {
        status.textContent = 'Voice input error. Try again.';
      }
    };

    micBtn.addEventListener('click', () => {
      if (this.isRecording) { this.stopRecording(); }
      else { this.startRecording(); }
    });

    const speakBtn = bar.querySelector('#voiceSpeakBtn');
    if (speakBtn) {
      speakBtn.addEventListener('click', () => {
        if (currentText) this.speak(currentText);
      });
    }

    return bar;
  }
}

const VOICE = new SAHELIVoice();
window.VOICE = VOICE;
