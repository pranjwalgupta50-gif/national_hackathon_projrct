﻿// SAHELI Privacy & Data Module
function renderPrivacy() {
  const container = document.getElementById('moduleContainer');
  const entries = STATE.get('journalEntries') || [];
  const moods = STATE.get('moods') || [];
  const sleepData = STATE.get('sleepData') || [];
  const assessments = STATE.get('assessments') || {};
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">🔒 Privacy First</div>
        <h1>Privacy & Data Control</h1>
        <p>Your data belongs to you. SAHELI is built on a privacy-first foundation — everything stays on your device.</p>
      </div>
      <div class="module-content">

        <!-- Privacy Promise -->
        <div class="card card-sage mt-24">
          <div class="card-label">The SAHELI Privacy Promise</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
            ${[
              ['🔒', 'Local storage only', 'All your data — moods, journal entries, sleep logs, period data, assessments — is stored only on this device using browser localStorage.'],
              ['🚫', 'No servers', 'SAHELI has no backend server. Your data is never uploaded or transmitted.'],
              ['🔑', 'API key security', 'If you enter an OpenAI API key, it is stored in localStorage only and used solely to call OpenAI\'s API on your behalf. It is never stored on any SAHELI server (there is none).'],
              ['🗑️', 'Right to delete', 'You can delete any or all of your data at any time using the controls below.'],
              ['👁️', 'No tracking', 'SAHELI does not use analytics, tracking pixels, or cookies for advertising.'],
              ['🌐', 'Browser privacy', 'SAHELI works in private/incognito mode. Clearing your browser data also clears SAHELI data.']
            ].map(([icon, title, desc]) => `
              <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--sage-300)">
                <span style="font-size:20px">${icon}</span>
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${title}</div>
                  <div style="font-size:12px;color:var(--text-600);margin-top:2px">${desc}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Data Summary -->
        <div class="card mt-24">
          <div class="card-label">Your Data Summary</div>
          <div class="card-grid-4 mt-16">
            ${[
              ['📔', entries.length, 'Journal Entries'],
              ['😊', moods.length, 'Mood Check-ins'],
              ['🌙', sleepData.length, 'Sleep Logs'],
              ['📋', Object.keys(assessments).length, 'Assessments']
            ].map(([icon, count, label]) => `
              <div style="text-align:center;padding:16px;background:var(--purple-50);border-radius:var(--radius-md)">
                <div style="font-size:28px">${icon}</div>
                <div style="font-size:24px;font-weight:700;color:var(--purple-700)">${count}</div>
                <div style="font-size:11px;color:var(--text-400)">${label}</div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Data Export -->
        <div class="card mt-24">
          <div class="card-label">Export & Backup</div>
          <p style="font-size:13px;color:var(--text-500);margin-top:8px;margin-bottom:16px">Download your data as a JSON file to keep a local backup or transfer to another device.</p>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <button class="btn btn-primary" id="exportAllDataBtn">⬇️ Export All Data</button>
            <button class="btn btn-secondary" id="exportJournalBtn">📔 Export Journal Only</button>
          </div>
        </div>

        <!-- Selective Delete -->
        <div class="card mt-24">
          <div class="card-label">Selective Data Deletion</div>
          <div style="display:flex;flex-direction:column;gap:12px;margin-top:12px">
            ${[
              ['Journal Entries', 'journalEntries', entries.length + ' entries'],
              ['Mood Check-ins', 'moods', moods.length + ' entries'],
              ['Sleep Logs', 'sleepData', sleepData.length + ' entries'],
              ['Period Data', 'periodData', 'Cycle and symptom data'],
              ['Assessment Results', 'assessments', Object.keys(assessments).length + ' assessments'],
              ['Recovery Plan', 'recoveryPlan', STATE.get('recoveryPlan')?.concern ? 'Active plan: ' + STATE.get('recoveryPlan').concern : 'No active plan'],
              ['Healing Progress', 'healingProgress', 'Activity completion records'],
              ['OpenAI API Key', 'apiKey', STATE.get('openaiKey') ? '1 key stored' : 'No key stored']
            ].map(([label, key, info]) => `
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;border:1px solid var(--border-light);border-radius:var(--radius-md)">
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${label}</div>
                  <div style="font-size:11px;color:var(--text-400)">${info}</div>
                </div>
                <button class="btn btn-outline btn-sm" onclick="deleteDataCategory('${key}','${label}')">Delete</button>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Nuclear Delete -->
        <div class="card settings-danger mt-24" style="border-color:var(--danger)">
          <div class="card-label" style="color:var(--danger)">⚠️ Clear All Data</div>
          <p style="font-size:13px;color:var(--text-600);margin-top:8px">This will permanently delete ALL SAHELI data from this device, including all journal entries, mood logs, recovery plans, and settings. This cannot be undone.</p>
          <button class="btn btn-danger mt-16" id="clearAllDataBtn">🗑️ Clear Everything — I Understand This Cannot Be Undone</button>
        </div>

      </div>
    </div>
  `;

  // Export All
  document.getElementById('exportAllDataBtn').addEventListener('click', () => {
    const allData = {
      exportDate: new Date().toISOString(),
      version: '1.0',
      data: STATE.data
    };
    downloadJson(allData, `saheli-backup-${new Date().toISOString().split('T')[0]}.json`);
    showToast('Data exported successfully', 'success');
  });

  // Export Journal
  document.getElementById('exportJournalBtn').addEventListener('click', () => {
    const entries = STATE.get('journalEntries') || [];
    if (entries.length === 0) { showToast('No journal entries to export', 'warning'); return; }
    let text = 'SAHELI Journal Export\n' + new Date().toLocaleDateString('en-IN') + '\n\n';
    entries.forEach(e => {
      text += '---\n';
      text += `Date: ${new Date(e.date).toLocaleDateString('en-IN')}\n`;
      if (e.title) text += `Title: ${e.title}\n`;
      if (e.mood) text += `Mood: ${e.mood}\n`;
      text += `\n${e.text || ''}\n\n`;
    });
    downloadText(text, `saheli-journal-${new Date().toISOString().split('T')[0]}.txt`);
    showToast('Journal exported', 'success');
  });

  // Clear All
  document.getElementById('clearAllDataBtn').addEventListener('click', () => {
    if (!confirm('Are you absolutely sure? This will delete all your SAHELI data permanently. This cannot be undone.')) return;
    if (!confirm('Last chance — delete ALL SAHELI data from this device?')) return;
    STATE.clearAll();
    showToast('All data cleared. SAHELI has been reset.', 'success');
    setTimeout(() => location.reload(), 1500);
  });
}

function deleteDataCategory(key, label) {
  if (!confirm(`Delete all ${label}? This cannot be undone.`)) return;
  if (key === 'apiKey') {
    localStorage.removeItem('saheli_api_key');
    STATE.data.openaiKey = '';
  } else {
    const defaultVals = { journalEntries: [], moods: [], sleepData: [], periodData: { lastPeriod: null, cycleLength: 28, periodDuration: 5, symptoms: [] }, assessments: {}, recoveryPlan: null, healingProgress: {}, checklist: {} };
    STATE.set(key, defaultVals[key] !== undefined ? defaultVals[key] : null);
  }
  showToast(`${label} deleted`, 'success');
  renderPrivacy();
}

function downloadJson(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function downloadText(text, filename) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

window.PRIVACY_MODULE = { render: renderPrivacy };
window.deleteDataCategory = deleteDataCategory;
