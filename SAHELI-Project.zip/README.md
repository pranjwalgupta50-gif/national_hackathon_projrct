# Saheli | सहेली — Frontend

A responsive, bilingual-friendly landing page for a women's emotional wellbeing and mental health information website.

## Run it

**Option 1 — quickest**
1. Extract the ZIP.
2. Open the `saheli-frontend` folder.
3. Double-click `index.html` or open it in your browser.

**Option 2 — VS Code**
1. Open the folder in VS Code.
2. Install the **Live Server** extension (optional).
3. Right-click `index.html` → **Open with Live Server**.

No Node.js, build step, API key, or package installation is required.

## Included
- Responsive desktop and mobile layout
- Saheli / सहेली brand header and navigation
- Mood check-in interaction (runs in the browser only; does not send or save entries)
- Short grounding exercise dialog
- Mental wellbeing information cards and dialogs
- Basic accessibility features and reduced-motion support

## Important
This is a frontend demo, not a clinical service. It does not diagnose depression, connect to a counsellor, store mood entries, or provide emergency response. The Google Fonts import and Find A Helpline link require an internet connection; the rest of the page runs locally.
