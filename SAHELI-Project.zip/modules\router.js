﻿// SAHELI Main Application Router & Shell
const MODULE_REGISTRY = {
  'home': () => HOME_MODULE.render(),
  'ai-chat': () => AI_CHAT_MODULE.render(),
  'concerns': () => CONCERNS_MODULE.render(),
  'mood-checkin': () => MOOD_MODULE.render(),
  'recovery': () => RECOVERY_MODULE.render(),
  'healing-library': () => HEALING_LIBRARY_MODULE.render(),
  'journal': () => JOURNAL_MODULE.render(),
  'sleep': () => SLEEP_MODULE.render(),
  'period-tracker': () => PERIOD_MODULE.render(),
  'trauma-safety': () => TRAUMA_MODULE.render(),
  'relationships': () => RELATIONSHIPS_MODULE.render(),
  'postpartum': () => POSTPARTUM_MODULE.render(),
  'menopause': () => MENOPAUSE_MODULE.render(),
  'financial': () => FINANCIAL_MODULE.render(),
  'professionals': () => PROFESSIONALS_MODULE.render(),
  'privacy': () => PRIVACY_MODULE.render()
};

class SAHELIRouter {
  constructor() {
    this.currentModule = STATE.get('currentModule') || 'home';
  }

  render(moduleId) {
    const id = moduleId || this.currentModule;
    this.currentModule = id;
    AI.setModule(id);

    const container = document.getElementById('moduleContainer');
    if (!container) return;

    // Scroll to top
    container.scrollTop = 0;
    const mainArea = document.getElementById('appMain');
    if (mainArea) mainArea.scrollTop = 0;

    // Update active nav
    document.querySelectorAll('.nav-item').forEach(n => {
      n.classList.toggle('active', n.dataset.module === id);
    });

    // Render module
    const renderer = MODULE_REGISTRY[id];
    if (renderer) {
      try { renderer(); }
      catch(e) {
        console.error(`Error rendering module "${id}":`, e);
        container.innerHTML = `
          <div class="module-view">
            <div class="module-header"><h1>Something went wrong</h1></div>
            <div class="module-content">
              <div class="alert alert-warning">
                <strong>SAHELI couldn't load this module.</strong> Please try again or go back to the home dashboard.
              </div>
              <button class="btn btn-primary mt-16" onclick="navigateTo('home')">← Back to Home</button>
              <details style="margin-top:12px"><summary style="font-size:11px;color:var(--text-400);cursor:pointer">Technical details</summary>
                <pre style="font-size:10px;color:var(--text-400);white-space:pre-wrap;margin-top:6px">${e.message}</pre>
              </details>
            </div>
          </div>`;
      }
    } else {
      container.innerHTML = `
        <div class="module-view">
          <div class="module-header"><h1>Module Not Found</h1></div>
          <div class="module-content">
            <p>This module (${id}) is not available.</p>
            <button class="btn btn-primary mt-16" onclick="navigateTo('home')">← Back to Home</button>
          </div>
        </div>`;
    }

    // Close sidebar on mobile
    if (window.innerWidth <= 768) {
      document.getElementById('appSidebar')?.classList.remove('mobile-open');
    }
  }
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
  const router = new SAHELIRouter();
  window.SAHELI_ROUTER = router;

  // Set language in header
  const langSel = document.getElementById('languageSelector');
  if (langSel) {
    langSel.value = STATE.get('language') || 'en';
    langSel.addEventListener('change', () => {
      STATE.set('language', langSel.value);
      showToast('Language changed', 'success');
      router.render(router.currentModule);
    });
  }

  // Sidebar toggle
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('appSidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => {
      if (window.innerWidth <= 768) {
        sidebar.classList.toggle('mobile-open');
      } else {
        sidebar.classList.toggle('collapsed');
      }
    });
  }

  // Nav items
  document.querySelectorAll('.nav-item[data-module]').forEach(item => {
    item.addEventListener('click', () => {
      navigateTo(item.dataset.module);
    });
  });

  // Settings button
  const settingsBtn = document.getElementById('settingsBtn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      const panel = document.getElementById('settingsPanel');
      if (panel.classList.contains('hidden')) {
        SETTINGS_MODULE.render();
      } else {
        closeSettings();
      }
    });
  }

  // Notifications button
  const notifBtn = document.getElementById('notifBtn');
  const notifPanel = document.getElementById('notificationsPanel');
  const notifOverlay = document.getElementById('notifOverlay');
  if (notifBtn && notifPanel) {
    notifBtn.addEventListener('click', () => {
      notifPanel.classList.toggle('hidden');
      document.getElementById('notifBadge')?.classList.add('hidden');
    });
    if (notifOverlay) notifOverlay.addEventListener('click', () => notifPanel.classList.add('hidden'));
  }

  // Update sidebar profile
  const userName = STATE.get('userName');
  const profileName = document.getElementById('sidebarProfileName');
  if (profileName) profileName.textContent = userName || 'Welcome, Saheli';
  const todayMood = STATE.todaysMood();
  const sidebarMoodValue = document.getElementById('sidebarMoodValue');
  if (sidebarMoodValue) sidebarMoodValue.textContent = todayMood ? todayMood.mood : 'Not checked in yet';

  // Initial render
  router.render(STATE.get('currentModule') || 'home');

  // Schedule mood reminder check
  checkMoodReminder();

  console.log('SAHELI loaded. Modules:', Object.keys(MODULE_REGISTRY).length);
});

function checkMoodReminder() {
  const notifs = STATE.get('notifications') || {};
  if (!notifs.mood) return;
  const todayMood = STATE.todaysMood();
  if (!todayMood) {
    const h = new Date().getHours();
    if (h >= 9 && h <= 21) {
      setTimeout(() => {
        showToast('💜 Your daily mood check-in is waiting — how are you feeling today?', '', 5000);
      }, 3000);
    }
  }
}
