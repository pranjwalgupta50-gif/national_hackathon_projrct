﻿// SAHELI AI Module - OpenAI Integration with Smart Fallback
const SAHELI_SYSTEM_PROMPT = `You are SAHELI (सहेली), a compassionate, knowledgeable women's mental wellness and safety companion for Indian women. Your role is to:

1. Provide empathetic, nonjudgmental emotional support
2. Offer evidence-informed wellness guidance (NOT medical diagnosis or treatment)
3. Answer questions about mental health, relationships, women's wellness, and safety
4. Recognize when someone needs professional help and recommend it clearly
5. Respond in the user's selected language (Hindi, English, or regional languages)
6. NEVER diagnose medical/psychiatric conditions
7. NEVER prescribe medications or recommend stopping treatment
8. NEVER fabricate medical facts
9. ALWAYS prioritize safety — if someone expresses suicidal thoughts or danger, immediately provide crisis resources: 112 (Emergency), 14416 (Tele-MANAS), 181 (Women Helpline)
10. Be warm, culturally sensitive, and trauma-informed

Always clearly distinguish general wellness information from professional medical advice. Remind users that this app is a wellness companion, not a clinical service.

When responding:
- Be specific to the user's question, not generic
- Keep responses concise (3-6 paragraphs) unless more is needed
- Use simple, accessible language
- Include practical next steps when relevant
- Ask thoughtful follow-up questions when helpful`;

const SAHELI_CONTEXT_BY_MODULE = {
  home: 'The user is on the home dashboard.',
  'ai-chat': 'The user is in the AI chat module seeking general support.',
  concerns: 'The user is exploring a specific concern or emotional difficulty.',
  'mood-checkin': 'The user just completed a mood check-in.',
  recovery: 'The user is following a personalized recovery journey.',
  'healing-library': 'The user is accessing healing activities.',
  journal: 'The user is writing in their private journal.',
  sleep: 'The user is assessing their sleep quality.',
  'trauma-safety': 'The user is in the trauma and safety module - handle with extra care and trauma-informed language.',
  relationships: 'The user is exploring relationship or family concerns.',
  postpartum: 'The user may be experiencing postpartum emotions - be especially gentle.',
  menopause: 'The user is exploring menopause-related concerns.',
  financial: 'The user is addressing financial well-being.'
};

class SAHELIAI {
  constructor() {
    this.conversationHistory = [];
    this.currentModule = 'home';
  }

  async chat(userMessage, options = {}) {
    // Safety check first
    const risk = SAFETY.classify(userMessage);
    if (risk === 'immediate') {
      SAFETY.trigger('immediate', userMessage);
      return {
        text: t('youAreNotAlone') + '\n\n' + SAFETY.getResourceHtml(),
        isHtml: true,
        riskLevel: 'immediate'
      };
    }

    const apiKey = STATE.get('openaiKey') || localStorage.getItem('saheli_api_key');

    if (!apiKey) {
      return { text: this.getFallbackResponse(userMessage, options), isHtml: false };
    }

    try {
      const messages = this.buildMessages(userMessage, options);
      const response = await this.callOpenAI(apiKey, messages);
      const text = response.choices?.[0]?.message?.content || 'I am here to support you. Could you tell me more?';
      this.conversationHistory.push({ role: 'user', content: userMessage });
      this.conversationHistory.push({ role: 'assistant', content: text });
      // Keep history manageable
      if (this.conversationHistory.length > 20) {
        this.conversationHistory = this.conversationHistory.slice(-16);
      }
      if (risk === 'significant') showToast('💙 Remember: 14416 (Tele-MANAS) is available free 24/7 if you need to talk to someone.', '', 6000);
      return { text, isHtml: false };
    } catch(e) {
      console.error('AI error:', e);
      if (e.status === 401) {
        return { text: '⚠️ Your API key appears to be invalid. Please check your OpenAI API key in Settings.', isHtml: false };
      }
      if (e.status === 429) {
        return { text: '⚠️ OpenAI rate limit reached. Please try again in a moment. ' + this.getFallbackResponse(userMessage, options), isHtml: false };
      }
      return { text: this.getFallbackResponse(userMessage, options), isHtml: false };
    }
  }

  buildMessages(userMessage, options) {
    const moduleCtx = SAHELI_CONTEXT_BY_MODULE[this.currentModule] || '';
    const lang = STATE.get('language') || 'en';
    const userName = STATE.get('userName') || '';
    const todayMood = STATE.todaysMood();
    const recoveryPlan = STATE.get('recoveryPlan');

    let systemContent = SAHELI_SYSTEM_PROMPT;
    if (lang !== 'en') systemContent += `\n\nRespond primarily in ${lang === 'hi' ? 'Hindi' : 'the user\'s language'}, mixing English where natural (Hinglish is fine for Hindi users).`;
    if (userName) systemContent += `\nThe user's name is ${userName}.`;
    if (moduleCtx) systemContent += `\nContext: ${moduleCtx}`;
    if (todayMood) systemContent += `\nUser's mood today: ${todayMood.mood} (intensity ${todayMood.intensity}/10).`;
    if (recoveryPlan?.concern) systemContent += `\nUser is working on a recovery plan for: ${recoveryPlan.concern}.`;
    if (options.context) systemContent += `\nAdditional context: ${options.context}`;

    const messages = [{ role: 'system', content: systemContent }];
    if (this.conversationHistory.length > 0) messages.push(...this.conversationHistory.slice(-10));
    messages.push({ role: 'user', content: userMessage });
    return messages;
  }

  async callOpenAI(apiKey, messages) {
    const model = STATE.get('aiModel') || 'gpt-4o-mini';
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model, messages, max_tokens: 800, temperature: 0.7 })
    });
    if (!res.ok) {
      const err = new Error(`OpenAI error: ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  getFallbackResponse(message, options = {}) {
    const lower = message.toLowerCase();
    const module_ = options.module || this.currentModule;

    // Context-aware fallback responses
    if (lower.includes('depress') || lower.includes('sad') || lower.includes('low')) {
      return "I hear you — feeling low or sad is a real and valid experience. Low mood can have many causes: life changes, stress, relationship difficulties, sleep problems, hormonal shifts, or physical health. You don't need to identify the exact cause to start taking gentle care of yourself.\n\nSome things that often help: maintaining a simple daily routine, getting outside even briefly, reaching out to a trusted person, and being kind to yourself rather than pushing too hard.\n\nIf low mood persists for more than two weeks or significantly affects your daily life, I'd encourage you to speak with a doctor or mental health professional — you deserve that support. Would you like me to help you find resources?";
    }
    if (lower.includes('anxi') || lower.includes('worry') || lower.includes('stress') || lower.includes('overthink')) {
      return "Anxiety, worry, and overthinking are experiences many people share — and they can feel exhausting. Your nervous system is trying to protect you, even when that feels overwhelming.\n\nA grounding technique that can help right now: Name 5 things you can see, 4 you can feel, 3 you can hear, 2 you can smell, 1 you can taste. This brings attention back to the present moment.\n\nLonger-term, it often helps to identify what triggers your worry, learn to notice anxious thoughts without immediately following them, and build in regular rest and stress management. If anxiety significantly affects your daily life, a counsellor or psychologist can offer personalised support.";
    }
    if (lower.includes('sleep') || lower.includes('tired') || lower.includes('fatigue') || lower.includes('insomnia')) {
      return "Sleep difficulties can really affect everything — mood, concentration, relationships, and physical health. You're not alone in struggling with this.\n\nGeneral sleep hygiene that tends to help: keeping a consistent bedtime and wake time (even on weekends), winding down for 30-60 minutes before bed, keeping your bedroom cool and dark, reducing screen time in the evening, and avoiding caffeine after midday.\n\nIf sleep problems have persisted for weeks or are significantly affecting your day, it's worth speaking with a doctor — there are effective treatments for sleep difficulties.";
    }
    if (lower.includes('lonely') || lower.includes('alone') || lower.includes('isolat')) {
      return "Loneliness is one of the most painful human experiences — and it's far more common than we talk about. Feeling this way doesn't mean something is wrong with you.\n\nSmall steps that can help: reaching out to one person (even a text is enough), exploring community activities that match your interests, volunteering, or joining an online group. Self-compassion is also important — loneliness can bring harsh self-criticism that makes things harder.\n\nIf loneliness is persistent or connected to depression, please consider speaking with a counsellor. You deserve meaningful connection.";
    }
    if (lower.includes('trauma') || lower.includes('abuse') || lower.includes('harass') || lower.includes('hurt me') || lower.includes('violence')) {
      return "Thank you for trusting SAHELI with something so significant. What you've experienced matters, and your feelings are valid.\n\nYour safety is the first priority. If you are currently in danger, please contact 112 (emergency services) or go to the nearest police station or hospital. For ongoing support:\n• 181 — Women Helpline (24/7)\n• 14416 — Tele-MANAS mental health support (free)\n\nRecovery from trauma is possible. It often helps to work with a trauma-informed counsellor or psychologist at your own pace. You don't need to share everything at once or confront anyone before you're ready.";
    }
    if (lower.includes('relationship') || lower.includes('husband') || lower.includes('partner') || lower.includes('family') || lower.includes('marriage')) {
      return "Relationship and family concerns can be incredibly complex and emotionally draining. It's okay to feel confused, hurt, or uncertain.\n\nSome questions that might help you think through things: What feels most difficult right now? What do you need from this relationship? Are there any safety concerns?\n\nFor communication, 'I feel...' statements are often less likely to trigger defensiveness than 'You always/never...' statements. Creating some space for yourself — whether through a trusted friend, a journal, or time alone — can also help you think more clearly.\n\nIf there are concerns about control, abuse, or your safety, please reach out to 181 (Women Helpline) or 14416 (Tele-MANAS).";
    }
    if (lower.includes('postpartum') || lower.includes('baby') || lower.includes('new mom') || lower.includes('after delivery') || lower.includes('delivery')) {
      return "The postpartum period is one of the most significant transitions in a woman's life — and the emotional landscape can be very complex. Many women experience a range of feelings from joy to grief, anxiety, disconnection, or being overwhelmed. All of these are understandable.\n\n'Baby blues' in the first two weeks are very common. If you're experiencing persistent low mood, anxiety, difficulty bonding, or thoughts of harming yourself or your baby beyond two weeks, please speak with your doctor — postpartum depression and anxiety are treatable.\n\nPlease take any extra rest you can, accept help when it's offered, and be gentle with yourself. You are doing something incredibly demanding.";
    }

    // Generic supportive response
    return "I'm here with you. Thank you for sharing what's on your mind.\n\nWhatever you're going through, you don't have to figure it out alone. I'm a wellness companion — I can offer information, support, and guidance, though I always recommend speaking with a qualified professional for medical, psychological, or safety concerns.\n\nCould you tell me a bit more about what you're experiencing? The more you share (only what you're comfortable with), the more specific and helpful my response can be.\n\nRemember: 14416 (Tele-MANAS) is available free, 24/7 for mental health support in India. 💙";
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  setModule(moduleId) {
    this.currentModule = moduleId;
  }
}

const AI = new SAHELIAI();
window.AI = AI;
