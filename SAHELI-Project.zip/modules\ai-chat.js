﻿// SAHELI AI Chat Module
function renderAIChat() {
  AI.setModule('ai-chat');
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view" style="display:flex;flex-direction:column;height:calc(100vh - 64px)">
      <div class="module-header" style="flex-shrink:0">
        <div class="module-header-badge">🤖 AI Powered</div>
        <h1>Talk to SAHELI AI</h1>
        <p>Your safe space to talk, ask questions, and receive personalized guidance. I'm here for you — in Hindi, English, or your preferred language.</p>
      </div>

      <div style="flex:1;display:flex;flex-direction:column;overflow:hidden">
        <!-- API Key Warning if not set -->
        ${!STATE.get('openaiKey') ? `
        <div class="alert alert-warning" style="margin:16px 16px 0;flex-shrink:0">
          ⚙️ <strong>No API key set.</strong> Using smart offline responses. For better AI responses, add your OpenAI API key in <button class="btn btn-outline btn-sm" onclick="document.getElementById('settingsBtn').click()">Settings</button>
        </div>` : ''}

        <!-- Chat Messages -->
        <div class="chat-messages" id="chatMessages">
          ${renderWelcomeMessage()}
        </div>

        <!-- Quick Prompts -->
        <div id="quickPromptsRow" style="padding:0 16px;display:flex;gap:8px;flex-wrap:wrap;flex-shrink:0">
          ${['I\'m feeling anxious', 'I can\'t sleep', 'I feel lonely', 'I need help with stress', 'Tell me about recovery'].map(p =>
            `<button class="btn btn-secondary btn-sm quick-prompt" style="font-size:11px" data-prompt="${p}">${p}</button>`
          ).join('')}
        </div>

        <!-- Voice Control Bar -->
        <div style="padding:8px 16px;flex-shrink:0" id="chatVoiceBarContainer"></div>

        <!-- Input Area -->
        <div class="chat-input-area" style="flex-shrink:0">
          <div class="chat-input-wrap">
            <textarea class="chat-input" id="chatInput" placeholder="${t('typeMessage')}" rows="1" aria-label="Message to SAHELI AI"></textarea>
            <button class="chat-voice-btn" id="chatMicBtn" aria-label="Voice input" title="Voice input">🎤</button>
          </div>
          <button class="chat-send-btn" id="chatSendBtn" aria-label="Send message">
            <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
          </button>
        </div>
      </div>
    </div>
  `;

  setupChatHandlers();
  setupChatVoice();
}

function renderWelcomeMessage() {
  const name = STATE.get('userName') || '';
  return `
    <div class="chat-bubble">
      <div class="chat-avatar ai">🌸</div>
      <div>
        <div class="bubble-content">
          Namaste ${name ? name : ''}! 🙏 I'm SAHELI, your personal wellness companion.<br><br>
          I'm here to listen, support, and guide you — whether you want to talk about how you're feeling, explore a concern, understand something about your wellness, or simply not feel alone for a moment.<br><br>
          <strong>What's on your mind today?</strong>
        </div>
        <div class="bubble-time">SAHELI AI · ${new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>
      </div>
    </div>
  `;
}

function setupChatHandlers() {
  const input = document.getElementById('chatInput');
  const sendBtn = document.getElementById('chatSendBtn');
  const messages = document.getElementById('chatMessages');

  if (!input || !sendBtn) return;

  // Auto-resize textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  });

  // Send on Enter (not Shift+Enter)
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });

  sendBtn.addEventListener('click', sendMessage);

  // Quick prompts
  document.querySelectorAll('.quick-prompt').forEach(btn => {
    btn.addEventListener('click', () => {
      input.value = btn.dataset.prompt;
      sendMessage();
      document.getElementById('quickPromptsRow').style.display = 'none';
    });
  });

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    input.style.height = 'auto';
    document.getElementById('quickPromptsRow').style.display = 'none';

    // Add user bubble
    appendMessage(text, 'user');

    // Show typing indicator
    const typingId = showTyping();

    try {
      const result = await AI.chat(text);
      removeTyping(typingId);
      if (result.riskLevel === 'immediate') return; // Emergency overlay handles it
      appendMessage(result.text, 'ai', result.isHtml);
      // Speak response
      if (VOICE.isSpeechSupported() && result.text && !result.isHtml) {
        VOICE.speak(result.text.substring(0, 500));
      }
    } catch(e) {
      removeTyping(typingId);
      appendMessage('I\'m having trouble connecting right now. Please try again in a moment. If you need immediate support, call 14416 (Tele-MANAS).', 'ai');
    }
  }

  function appendMessage(text, role, isHtml = false) {
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${role}`;
    const time = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
    bubble.innerHTML = `
      <div class="chat-avatar ${role}">${role === 'ai' ? '🌸' : '👤'}</div>
      <div>
        <div class="bubble-content">${isHtml ? text : escapeHtml(text).replace(/\n/g, '<br>')}</div>
        <div class="bubble-time">${role === 'ai' ? 'SAHELI AI' : 'You'} · ${time}</div>
      </div>
    `;
    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
  }

  function showTyping() {
    const id = 'typing_' + Date.now();
    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble';
    bubble.id = id;
    bubble.innerHTML = `
      <div class="chat-avatar ai">🌸</div>
      <div class="bubble-content">
        <div class="typing-indicator">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    `;
    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
    return id;
  }

  function removeTyping(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  }
}

function setupChatVoice() {
  const container = document.getElementById('chatVoiceBarContainer');
  const input = document.getElementById('chatInput');
  const micBtn = document.getElementById('chatMicBtn');
  if (!container || !input) return;

  VOICE.onResult = (text, isFinal) => {
    input.value = text;
    if (isFinal) {
      input.dispatchEvent(new Event('input'));
      micBtn.classList.remove('recording');
    }
  };

  VOICE.onStart = () => { micBtn.classList.add('recording'); };
  VOICE.onEnd = () => { micBtn.classList.remove('recording'); };
  VOICE.onError = (err) => {
    micBtn.classList.remove('recording');
    if (err === 'not-allowed') showToast('Microphone access denied. Please allow microphone in browser settings.', 'warning');
  };

  if (micBtn) {
    micBtn.addEventListener('click', () => {
      if (VOICE.isRecording) { VOICE.stopRecording(); }
      else { VOICE.startRecording(); }
    });
  }
}

function escapeHtml(text) {
  return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

window.AI_CHAT_MODULE = { render: renderAIChat };
