﻿// SAHELI Period Tracker Module
function renderPeriodTracker() {
  const container = document.getElementById('moduleContainer');
  const periodData = STATE.get('periodData') || { lastPeriod: null, cycleLength: 28, periodDuration: 5, symptoms: [] };
  const today = new Date();

  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">🌺 Women's Health</div>
        <h1>Period Tracker</h1>
        <p>Optional, private, and fully under your control. Track your cycle and related symptoms to better understand your body.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-info mt-16">
          ℹ️ Period predictions are estimates based on your reported data. Cycles naturally vary. This is not a medical tool. 
          For irregular, painful, or concerning symptoms, please consult a gynaecologist or doctor.
        </div>

        <!-- Setup Form -->
        <div class="card mt-24">
          <div class="card-label">Your Cycle Information</div>
          <div class="card-grid-2 mt-16">
            <div class="form-group">
              <label class="form-label">Last period start date</label>
              <input type="date" class="form-input" id="lastPeriodDate" value="${periodData.lastPeriod || ''}" max="${today.toISOString().split('T')[0]}" />
            </div>
            <div class="form-group">
              <label class="form-label">Usual cycle length (days): <span id="cycleLenVal" style="color:var(--purple-700);font-weight:700">${periodData.cycleLength}</span></label>
              <input type="range" id="cycleLength" min="21" max="45" value="${periodData.cycleLength}" />
              <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-400);margin-top:4px"><span>21 days</span><span>45 days</span></div>
            </div>
            <div class="form-group">
              <label class="form-label">Typical period duration (days): <span id="periodDurVal" style="color:var(--purple-700);font-weight:700">${periodData.periodDuration}</span></label>
              <input type="range" id="periodDuration" min="2" max="10" value="${periodData.periodDuration}" />
              <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-400);margin-top:4px"><span>2 days</span><span>10 days</span></div>
            </div>
            <div class="form-group">
              <label class="form-label">Common symptoms (select all that apply)</label>
              <div style="display:flex;flex-wrap:wrap;gap:6px" id="symptomGrid">
                ${['Cramps','Bloating','Mood changes','Fatigue','Headache','Breast tenderness','Low back pain','Nausea','Spotting','Heavy flow','Light flow','Irregular'].map(s =>
                  `<button class="tag tag-purple symptom-btn" data-symptom="${s}" style="cursor:pointer;${(periodData.symptoms||[]).includes(s) ? 'background:var(--purple-600);color:white' : ''}">${s}</button>`
                ).join('')}
              </div>
            </div>
          </div>
          <button class="btn btn-primary mt-16" id="savePeriodData">Save & Calculate →</button>
        </div>

        <!-- Predictions -->
        <div id="periodPredictions" class="mt-16"></div>

        <!-- Calendar -->
        <div id="periodCalendar" class="mt-16"></div>

        <!-- Wellness Tips -->
        <div class="card card-coral mt-24">
          <div class="card-label">Cycle Wellness Tips</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
            ${[
              ['🌸', 'Menstrual Phase (Days 1-5)', 'Rest as much as possible. Warmth (heating pad) may help cramps. Stay hydrated. Iron-rich foods can help if bleeding is heavy.'],
              ['🌱', 'Follicular Phase (Days 6-13)', 'Energy often increases. A good time to start new projects, exercise more, and connect socially.'],
              ['⚡', 'Ovulation (around Day 14)', 'Energy peak for many women. You may feel more confident and social. Communication is often easier.'],
              ['🌙', 'Luteal Phase (Days 15-28)', 'Energy may decrease. PMS symptoms may appear in the second half. Gentle movement, reducing sugar and caffeine, and extra rest can help.']
            ].map(([icon, phase, tip]) => `
              <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--coral-200)">
                <span style="font-size:20px">${icon}</span>
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${phase}</div>
                  <div style="font-size:12px;color:var(--text-600);margin-top:2px">${tip}</div>
                </div>
              </div>
            `).join('')}
          </div>
          <div class="alert alert-warning mt-12">⚠️ These are general patterns. Everyone's experience is unique. Severe pain, very heavy bleeding, or irregular cycles warrant medical evaluation.</div>
        </div>

        <!-- Privacy Note -->
        <div class="alert alert-success mt-16">🔒 All period tracking data is stored only on your device and is never shared or uploaded. You can delete this data anytime in Privacy & Data settings.</div>
      </div>
    </div>
  `;

  // Sliders
  document.getElementById('cycleLength').addEventListener('input', function() {
    document.getElementById('cycleLenVal').textContent = this.value;
  });
  document.getElementById('periodDuration').addEventListener('input', function() {
    document.getElementById('periodDurVal').textContent = this.value;
  });

  // Symptom toggles
  let selectedSymptoms = [...(periodData.symptoms || [])];
  document.getElementById('symptomGrid').addEventListener('click', (e) => {
    const btn = e.target.closest('.symptom-btn');
    if (!btn) return;
    const s = btn.dataset.symptom;
    if (selectedSymptoms.includes(s)) {
      selectedSymptoms = selectedSymptoms.filter(x => x !== s);
      btn.style.background = ''; btn.style.color = '';
    } else {
      selectedSymptoms.push(s);
      btn.style.background = 'var(--purple-600)'; btn.style.color = 'white';
    }
  });

  // Save
  document.getElementById('savePeriodData').addEventListener('click', () => {
    const lastPeriod = document.getElementById('lastPeriodDate').value;
    const cycleLength = parseInt(document.getElementById('cycleLength').value);
    const periodDuration = parseInt(document.getElementById('periodDuration').value);
    if (!lastPeriod) { showToast('Please enter your last period start date', 'warning'); return; }
    STATE.set('periodData', { lastPeriod, cycleLength, periodDuration, symptoms: selectedSymptoms });
    showToast('Period data saved 🌺', 'success');
    showPredictions(lastPeriod, cycleLength, periodDuration);
    renderCycleCalendar(lastPeriod, cycleLength, periodDuration);
  });

  // Show predictions if data exists
  if (periodData.lastPeriod) {
    showPredictions(periodData.lastPeriod, periodData.cycleLength, periodData.periodDuration);
    renderCycleCalendar(periodData.lastPeriod, periodData.cycleLength, periodData.periodDuration);
  }
}

function showPredictions(lastPeriod, cycleLength, periodDuration) {
  const area = document.getElementById('periodPredictions');
  const last = new Date(lastPeriod);
  const today = new Date();
  today.setHours(0,0,0,0);

  const nextPeriod = new Date(last);
  nextPeriod.setDate(nextPeriod.getDate() + cycleLength);

  const ovulation = new Date(last);
  ovulation.setDate(ovulation.getDate() + cycleLength - 14);

  const daysUntilNext = Math.ceil((nextPeriod - today) / 86400000);
  const daysUntilOvulation = Math.ceil((ovulation - today) / 86400000);

  const nextPeriodStr = nextPeriod.toLocaleDateString('en-IN', {weekday:'long', day:'numeric', month:'long'});
  const ovulationStr = ovulation.toLocaleDateString('en-IN', {day:'numeric', month:'long'});

  area.innerHTML = `
    <div class="card card-grid-2">
      <div class="card card-purple" style="text-align:center">
        <div style="font-size:32px;margin-bottom:8px">🌺</div>
        <div class="card-label">Next Period (Estimated)</div>
        <div style="font-size:16px;font-weight:700;color:var(--coral-500);margin:6px 0">${nextPeriodStr}</div>
        <div style="font-size:13px;color:var(--text-400)">${daysUntilNext > 0 ? 'in ' + daysUntilNext + ' days' : daysUntilNext === 0 ? 'Expected today' : Math.abs(daysUntilNext) + ' days ago'}</div>
      </div>
      <div class="card card-lavender" style="text-align:center">
        <div style="font-size:32px;margin-bottom:8px">⚡</div>
        <div class="card-label">Estimated Ovulation</div>
        <div style="font-size:16px;font-weight:700;color:var(--purple-600);margin:6px 0">${ovulationStr}</div>
        <div style="font-size:13px;color:var(--text-400)">${daysUntilOvulation > 0 ? 'in ' + daysUntilOvulation + ' days' : 'passed'}</div>
      </div>
    </div>
    <p style="font-size:11px;color:var(--text-400);margin-top:8px;text-align:center">Estimates based on your reported cycle length of ${cycleLength} days. Actual dates may vary.</p>
  `;
}

function renderCycleCalendar(lastPeriod, cycleLength, periodDuration) {
  const area = document.getElementById('periodCalendar');
  const today = new Date();
  today.setHours(0,0,0,0);
  const last = new Date(lastPeriod);
  const year = today.getFullYear();
  const month = today.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startDow = firstDay.getDay();

  const nextPeriodStart = new Date(last);
  nextPeriodStart.setDate(nextPeriodStart.getDate() + cycleLength);
  const nextPeriodEnd = new Date(nextPeriodStart);
  nextPeriodEnd.setDate(nextPeriodEnd.getDate() + periodDuration - 1);
  const ovulation = new Date(last);
  ovulation.setDate(ovulation.getDate() + cycleLength - 14);

  // Current period days
  const currentPeriodEnd = new Date(last);
  currentPeriodEnd.setDate(currentPeriodEnd.getDate() + periodDuration - 1);

  const monthName = today.toLocaleDateString('en-IN', {month:'long', year:'numeric'});
  let calHtml = `<div class="card mt-16"><div class="card-label">${monthName} Calendar</div>`;
  calHtml += `<div class="cycle-calendar mt-12">`;
  ['Su','Mo','Tu','We','Th','Fr','Sa'].forEach(d => {
    calHtml += `<div style="text-align:center;font-size:10px;font-weight:700;color:var(--text-400);padding:4px">${d}</div>`;
  });
  for (let i = 0; i < startDow; i++) calHtml += '<div></div>';
  for (let d = 1; d <= lastDay.getDate(); d++) {
    const date = new Date(year, month, d);
    let cls = 'cycle-day';
    if (date.toDateString() === today.toDateString()) cls += ' today';
    if (date >= last && date <= currentPeriodEnd) cls += ' period';
    else if (date >= nextPeriodStart && date <= nextPeriodEnd) cls += ' predicted';
    if (date.toDateString() === ovulation.toDateString()) cls += ' ovulation';
    calHtml += `<div class="${cls}" title="${date.toLocaleDateString('en-IN',{day:'numeric',month:'short'})}">${d}</div>`;
  }
  calHtml += `</div>`;
  calHtml += `<div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:12px;font-size:11px">
    <div style="display:flex;align-items:center;gap:4px"><div style="width:12px;height:12px;border-radius:3px;background:var(--coral-300)"></div> Period</div>
    <div style="display:flex;align-items:center;gap:4px"><div style="width:12px;height:12px;border-radius:3px;background:var(--coral-100);border:1px solid var(--coral-300)"></div> Predicted</div>
    <div style="display:flex;align-items:center;gap:4px"><div style="width:12px;height:12px;border-radius:3px;background:var(--purple-200)"></div> Ovulation est.</div>
    <div style="display:flex;align-items:center;gap:4px"><div style="width:12px;height:12px;border-radius:3px;border:2px solid var(--purple-500)"></div> Today</div>
  </div></div>`;
  area.innerHTML = calHtml;
}

window.PERIOD_MODULE = { render: renderPeriodTracker };
