﻿// SAHELI Healing Library Module
const HEALING_ACTIVITIES = [
  {
    category: 'Grounding',
    color: 'purple',
    items: [
      { id: 'ground_54321', icon: '🖐️', title: '5-4-3-2-1 Grounding', duration: '5 min', level: 'All levels',
        desc: 'A powerful technique to anchor you in the present moment. Helps with anxiety, dissociation, and overwhelm.',
        steps: ['Find a comfortable sitting or standing position.','Notice 5 things you can SEE. Look around — name them.','Notice 4 things you can physically FEEL (feet on floor, clothes on skin, air on face).','Notice 3 things you can HEAR. Listen carefully to background sounds.','Notice 2 things you can SMELL. Breathe gently and notice any scents.','Notice 1 thing you can TASTE, or focus on one complete slow breath.','Take a final slow breath and notice how you feel now.'],
        benefit: 'Reduces acute anxiety and brings attention back to the present moment.' },
      { id: 'ground_safe_place', icon: '🏡', title: 'Safe Place Visualization', duration: '10 min', level: 'All levels',
        desc: 'Create a mental sanctuary you can return to whenever you need calm.',
        steps: ['Close your eyes and take three slow breaths.','Imagine a place where you feel completely safe — real or imagined.','Notice what you see there. What colours, shapes, light?','Notice what you hear. What sounds exist in this place?','Notice how your body feels in this safe place. Warmth, relaxation?','Spend 5 minutes simply being in this place.','When ready, take a breath and return to the room, knowing you can come back.'],
        benefit: 'Builds an internal resource for self-regulation and calm.' }
    ]
  },
  {
    category: 'Breathing',
    color: 'lavender',
    items: [
      { id: 'breath_426', icon: '🌬️', title: '4-2-6 Calming Breath', duration: '5 min', level: 'Beginner',
        desc: 'The extended exhale activates your parasympathetic nervous system — your body\'s natural calming response.',
        steps: ['Sit comfortably with your back supported.','Breathe in slowly through your nose for 4 counts.','Hold gently for 2 counts.','Breathe out slowly through your mouth for 6 counts.','Repeat 8-10 times.','If 4-2-6 is too much, try 3-1-5 to start.'],
        benefit: 'Reduces heart rate and activates relaxation response within minutes.' },
      { id: 'breath_478', icon: '🫁', title: '4-7-8 Sleep Breath', duration: '5 min', level: 'All levels',
        desc: 'A breathing pattern often used to prepare for sleep or manage acute anxiety.',
        steps: ['Place the tip of your tongue behind your upper front teeth.','Exhale completely through your mouth.','Close your mouth and inhale through your nose for 4 counts.','Hold your breath for 7 counts.','Exhale completely through your mouth for 8 counts.','This is one breath cycle. Repeat 3-4 times.'],
        benefit: 'Deeply calming — can help with sleep onset and acute anxiety.' }
    ]
  },
  {
    category: 'Movement & Stretch',
    color: 'sage',
    items: [
      { id: 'move_stretch', icon: '🧘', title: 'Gentle Stress-Release Stretch', duration: '10 min', level: 'All levels',
        desc: 'Gentle stretches that release tension held in common stress areas: neck, shoulders, and hips.',
        steps: ['Slowly drop your chin to your chest. Hold 5 seconds. Lift.','Roll your right ear to your right shoulder. Hold 5 sec. Repeat left.','Shrug your shoulders to your ears, hold, then release completely.','Roll your shoulders forward 5 times, then backward 5 times.','Clasp your hands behind your back and gently open your chest.','Take three final deep breaths and notice what has released.'],
        benefit: 'Releases muscular tension caused by stress and helps the nervous system settle.' },
      { id: 'move_walk', icon: '🚶', title: 'Mindful 10-Minute Walk', duration: '10-15 min', level: 'All levels',
        desc: 'Walking with intention — noticing your environment — is both physically and mentally beneficial.',
        steps: ['Step outside or find a safe space to walk.','As you walk, notice the sensation of your feet meeting the ground.','Look around — what colours do you see? What is moving?','Notice sounds: birds, traffic, wind, voices?','Let thoughts arise without following them — return to your senses.','After 10-15 minutes, pause and take three slow breaths.'],
        benefit: 'Movement + mindfulness + fresh air — a powerful combination for mood.' }
    ]
  },
  {
    category: 'Journaling',
    color: 'coral',
    items: [
      { id: 'journal_gratitude', icon: '✨', title: 'Gratitude Practice', duration: '10 min', level: 'All levels',
        desc: 'Writing down what you\'re grateful for can gradually shift attention toward what is working in your life.',
        steps: ['Open your journal or a blank page.','Set a timer for 10 minutes.','Write down at least 3 things you\'re grateful for today — however small.','For each one, write why you\'re grateful for it (not just what).','If today is hard, try: something in your body that works, something beautiful you noticed, someone who cares about you.','Read back what you\'ve written.'],
        benefit: 'Shifts attention from threat to positive — builds psychological resilience over time.' },
      { id: 'journal_letter', icon: '💌', title: 'Self-Compassion Letter', duration: '15 min', level: 'All levels',
        desc: 'Write a letter to yourself as if you were writing to a dear friend going through the same difficulty.',
        steps: ['Think of something that is causing you distress or self-criticism.','Imagine a close friend told you they were going through this exact thing.','Write them a letter — what would you say? How would you comfort them?','Read your letter and notice: could you offer yourself the same kindness?','You can also write a letter from your future healed self to yourself now.'],
        benefit: 'Activates self-compassion and reduces harsh self-criticism.' }
    ]
  },
  {
    category: 'Relaxation',
    color: 'purple',
    items: [
      { id: 'relax_pmr', icon: '💆', title: 'Progressive Muscle Relaxation', duration: '15-20 min', level: 'All levels',
        desc: 'Systematically tense and release muscle groups to achieve deep physical and mental relaxation.',
        steps: ['Lie down or sit comfortably. Close your eyes.','Start with your feet: tense all muscles tightly for 5 seconds, then release completely.','Move to your lower legs, then thighs, then abdomen.','Tense and release your hands, forearms, upper arms.','Tense and release your shoulders, neck, face.','Lie still for a moment and notice the feeling of relaxation throughout your body.','Take five slow breaths before opening your eyes.'],
        benefit: 'Reduces physical tension, lowers cortisol, and can help with sleep.' },
      { id: 'relax_body_scan', icon: '🌊', title: 'Body Scan Meditation', duration: '10-20 min', level: 'All levels',
        desc: 'A gentle attention practice that reconnects you with your body and releases held tension.',
        steps: ['Lie down comfortably. Allow your body to be heavy.','Take three slow, deep breaths.','Bring your attention to the top of your head. Notice any sensations — no need to change them.','Slowly move your attention down: face, throat, shoulders, chest, abdomen.','Continue down: hips, thighs, knees, calves, feet.','If you notice tightness anywhere, breathe into that area gently.','End with three breaths and slowly open your eyes.'],
        benefit: 'Reduces disconnection, promotes embodiment, and deeply relaxes the nervous system.' }
    ]
  },
  {
    category: 'Self-Compassion',
    color: 'coral',
    items: [
      { id: 'compassion_hand', icon: '❤️', title: 'Self-Compassion Hand Practice', duration: '5 min', level: 'Beginner',
        desc: 'A simple, powerful way to activate self-compassion in moments of distress.',
        steps: ['Find a quiet moment.','Place one or both hands over your heart.','Take a few slow breaths and feel the warmth of your own hands.','Say quietly or in your mind: "This is a moment of difficulty. Difficulty is part of life. May I be kind to myself right now."','Breathe into the warmth of your hands.','Stay as long as you need.'],
        benefit: 'Activates oxytocin and the soothing system — reduces self-criticism in real time.' },
      { id: 'compassion_mantra', icon: '🌸', title: 'Loving-Kindness Practice', duration: '10 min', level: 'All levels',
        desc: 'A traditional meditation for cultivating kindness toward yourself and others.',
        steps: ['Sit comfortably. Take three slow breaths.','Begin with yourself. Say or think: "May I be happy. May I be healthy. May I be safe. May I live with ease."','Repeat this 3-4 times, feeling the words as much as possible.','Extend to someone you love: "May you be happy. May you be healthy…"','Extend to someone neutral, then to all beings.','Return to yourself and the phrases.','Notice any warmth or softening in your chest.'],
        benefit: 'Builds kindness toward self and others — reduces negative self-talk over time.' }
    ]
  }
];

let activeActivity = null;
let activityTimer = null;
let activitySeconds = 0;

function renderHealingLibrary() {
  const container = document.getElementById('moduleContainer');
  const progress = STATE.get('healingProgress') || {};

  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">📚 Healing Activities</div>
        <h1>Body & Mind Healing Library</h1>
        <p>A collection of evidence-informed practices for emotional regulation, relaxation, grounding, and self-compassion. Each activity has step-by-step guidance.</p>
      </div>
      <div class="module-content-wide" style="padding-bottom:32px">
        <div class="alert alert-info mt-24">
          ℹ️ These activities support wellbeing. If any exercise causes discomfort, stop and choose something else. They do not replace professional mental health care.
        </div>

        <!-- Activity Detail Modal Area -->
        <div id="activityDetail" class="mt-24"></div>

        <!-- Filter Row -->
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:16px 0" id="categoryFilter">
          <button class="btn btn-primary btn-sm cat-filter-btn active" data-cat="all">All</button>
          ${HEALING_ACTIVITIES.map(c => `<button class="btn btn-secondary btn-sm cat-filter-btn" data-cat="${c.category}">${c.category}</button>`).join('')}
        </div>

        <!-- Activities Grid -->
        ${HEALING_ACTIVITIES.map(cat => `
          <div class="category-section mb-24" data-category="${cat.category}">
            <div class="section-header mb-12">
              <div class="section-title">${cat.category}</div>
            </div>
            <div class="card-grid-2">
              ${cat.items.map(item => `
                <div class="activity-card card-clickable ${progress[item.id] ? 'completed' : ''}" data-activity-id="${item.id}">
                  <div class="activity-card-header">
                    <span class="activity-icon">${item.icon}</span>
                    <div>
                      <div class="activity-title">${item.title}</div>
                      <div class="activity-duration">${item.duration} · ${item.level}</div>
                    </div>
                    ${progress[item.id] ? '<span class="tag tag-success">✅ Done</span>' : ''}
                  </div>
                  <div class="activity-desc">${item.desc}</div>
                  <div class="card-footer">
                    <span class="text-purple" style="font-size:12px;font-weight:600">📖 View & Start →</span>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  // Category filter
  document.querySelectorAll('.cat-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cat-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.cat;
      document.querySelectorAll('.category-section').forEach(sec => {
        sec.style.display = (cat === 'all' || sec.dataset.category === cat) ? '' : 'none';
      });
    });
  });

  // Activity card clicks
  document.querySelectorAll('[data-activity-id]').forEach(card => {
    card.addEventListener('click', () => {
      const actId = card.dataset.activityId;
      const act = findActivity(actId);
      if (act) openActivity(act);
    });
  });
}

function findActivity(id) {
  for (const cat of HEALING_ACTIVITIES) {
    const found = cat.items.find(i => i.id === id);
    if (found) return found;
  }
  return null;
}

function openActivity(activity) {
  const detail = document.getElementById('activityDetail');
  if (!detail) return;

  detail.innerHTML = `
    <div class="card card-purple mb-16" style="border:2px solid var(--purple-400)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <div style="display:flex;align-items:center;gap:12px">
          <span style="font-size:36px">${activity.icon}</span>
          <div>
            <div style="font-size:18px;font-weight:700;color:var(--text-800)">${activity.title}</div>
            <div style="font-size:12px;color:var(--text-400)">${activity.duration} · ${activity.level}</div>
          </div>
        </div>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('activityDetail').innerHTML='';clearInterval(window._actTimer)">✕ Close</button>
      </div>

      <p style="font-size:13px;color:var(--text-600);margin-bottom:16px">${activity.desc}</p>

      <div class="card-label mb-8">Step-by-Step Guide</div>
      <ol style="padding-left:20px;display:flex;flex-direction:column;gap:10px">
        ${activity.steps.map(step => `<li style="font-size:13px;color:var(--text-700);line-height:1.6">${step}</li>`).join('')}
      </ol>

      ${activity.benefit ? `<div class="alert alert-success mt-16"><strong>Why this helps:</strong> ${activity.benefit}</div>` : ''}

      <!-- Timer -->
      <div style="display:flex;align-items:center;gap:12px;margin-top:20px;flex-wrap:wrap">
        <div style="font-size:28px;font-weight:700;color:var(--purple-700);font-variant-numeric:tabular-nums" id="activityTimerDisplay">00:00</div>
        <button class="btn btn-primary" id="startActivityBtn">▶ Start Activity</button>
        <button class="btn btn-outline" id="stopActivityBtn" disabled>⏹ Stop</button>
        <button class="btn btn-success" id="markDoneBtn">✅ Mark as Complete</button>
      </div>

      <!-- Voice Guide -->
      <div style="margin-top:12px">
        <button class="btn btn-secondary btn-sm" id="speakStepsBtn">🔊 Read steps aloud</button>
        <button class="btn btn-outline btn-sm" id="stopSpeakBtn">⏹ Stop reading</button>
      </div>
    </div>
  `;

  detail.scrollIntoView({ behavior: 'smooth', block: 'start' });

  // Timer
  let seconds = 0;
  const timerDisplay = document.getElementById('activityTimerDisplay');
  let timerInterval = null;

  document.getElementById('startActivityBtn').addEventListener('click', () => {
    document.getElementById('startActivityBtn').disabled = true;
    document.getElementById('stopActivityBtn').disabled = false;
    timerInterval = setInterval(() => {
      seconds++;
      const m = Math.floor(seconds / 60).toString().padStart(2,'0');
      const s = (seconds % 60).toString().padStart(2,'0');
      timerDisplay.textContent = `${m}:${s}`;
    }, 1000);
    window._actTimer = timerInterval;
  });

  document.getElementById('stopActivityBtn').addEventListener('click', () => {
    clearInterval(timerInterval);
    document.getElementById('startActivityBtn').disabled = false;
    document.getElementById('stopActivityBtn').disabled = true;
  });

  document.getElementById('markDoneBtn').addEventListener('click', () => {
    clearInterval(timerInterval);
    STATE.update('healingProgress', (prev = {}) => ({ ...prev, [activity.id]: { date: new Date().toISOString(), duration: seconds } }));
    STATE.markActivity(activity.id, 'done');
    showToast(`"${activity.title}" completed! Well done 💜`, 'success');
    if (VOICE.isSpeechSupported()) {
      VOICE.speak(`Activity complete. Well done for taking this time for yourself.`);
    }
    document.getElementById('markDoneBtn').textContent = '✅ Completed!';
    document.getElementById('markDoneBtn').className = 'btn btn-success';
    // Re-render to update card state
    setTimeout(() => {
      const cards = document.querySelectorAll(`[data-activity-id="${activity.id}"]`);
      cards.forEach(c => c.classList.add('completed'));
    }, 100);
  });

  // Voice reading
  document.getElementById('speakStepsBtn').addEventListener('click', () => {
    const stepsText = activity.steps.join('. ');
    VOICE.speak(`${activity.title}. ${activity.desc}. Step by step guide: ${stepsText}`);
  });
  document.getElementById('stopSpeakBtn').addEventListener('click', () => VOICE.stopSpeaking());
}

window.HEALING_LIBRARY_MODULE = { render: renderHealingLibrary };
