﻿// SAHELI Postpartum Support Module
function renderPostpartum() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">👶 Postpartum Support</div>
        <h1>Postpartum Support</h1>
        <p>The postpartum period is one of the most significant transitions in a woman's life. You deserve compassionate support — and you are not alone.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-danger mt-16">
          🚨 <strong>Seek immediate help</strong> if you are having thoughts of harming yourself or your baby, or if you feel you are not in control of your actions. 
          Call 112 or go to the nearest emergency department immediately.
        </div>
        <div class="alert alert-info mt-8">
          ℹ️ SAHELI provides emotional support and information. It does not replace your obstetrician, midwife, or mental health professional.
        </div>

        <!-- How are you feeling? -->
        <div class="card mt-24">
          <div class="card-label">How are you feeling right now?</div>
          <div class="concern-grid mt-16" id="ppGrid">
            ${[
              ['😢','Baby Blues','Tearfulness, mood swings, feeling overwhelmed — very common in first 2 weeks.','blues'],
              ['😰','Anxiety','Constant worry about baby, health, or the future.','anxiety'],
              ['😔','Low Mood','Persistent sadness, loss of interest, feeling disconnected.','low_mood'],
              ['😵','Exhaustion','Complete physical and emotional depletion.','exhaustion'],
              ['💔','Disconnection','Difficulty bonding with baby or feeling emotionally numb.','disconnection'],
              ['🤯','Intrusive thoughts','Unwanted, distressing thoughts that feel unlike you.','intrusive'],
              ['😡','Anger or irritability','Unusual irritability or rage that feels out of proportion.','anger'],
              ['✨','Seeking information','I\'m doing okay — just want to learn more.','info']
            ].map(([icon, title, desc, id]) => `
              <div class="concern-card" onclick="openPPSection('${id}')">
                <div class="concern-icon">${icon}</div>
                <div class="concern-title">${title}</div>
                <div class="concern-desc">${desc}</div>
              </div>
            `).join('')}
          </div>
          <div id="ppDetail" class="mt-16"></div>
        </div>

        <!-- Urgent Warning Signs -->
        <div class="card card-coral mt-24">
          <div class="card-label" style="color:var(--danger)">Urgent Warning Signs — Seek Medical Help Immediately</div>
          <ul style="padding-left:20px;margin-top:12px;display:flex;flex-direction:column;gap:8px;font-size:13px;color:var(--text-700)">
            ${['Thoughts of harming yourself or your baby',
               'Feeling like you are not in control of your actions',
               'Seeing or hearing things others cannot (hallucinations)',
               'Extreme confusion or disorientation',
               'Feeling like your baby is not real',
               'Not sleeping at all even when baby sleeps',
               'Extreme agitation or feeling like you cannot slow down'].map(sign =>
                `<li style="padding:6px 0;border-bottom:1px solid var(--coral-200)">${sign}</li>`).join('')}
          </ul>
          <a href="tel:112" class="btn btn-danger mt-16 btn-full">📞 Call 112 — Emergency</a>
        </div>

        <!-- Self-Care -->
        <div class="card card-sage mt-24">
          <div class="card-label">Gentle Self-Care for the Postpartum Period</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
            ${[
              ['💤', 'Sleep when baby sleeps', 'Even short rest periods help. Ask for support so you can sleep.'],
              ['🍽️', 'Eat regularly', 'Nutrition supports recovery. Accept help with meals.'],
              ['🤱', 'Reach out for help', 'You don\'t have to do this alone. Ask a partner, family, or friend for specific help.'],
              ['💬', 'Talk to someone', 'Share how you\'re feeling with your doctor, midwife, or a trusted person.'],
              ['🚶', 'Gentle movement', 'A brief walk outside — when you\'re medically cleared — can lift mood.'],
              ['💜', 'Be patient with yourself', 'Recovery and adjustment take time. There is no "should be feeling" timeline.']
            ].map(([icon, title, desc]) => `
              <div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid var(--sage-300)">
                <span style="font-size:18px">${icon}</span>
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${title}</div>
                  <div style="font-size:12px;color:var(--text-600);margin-top:2px">${desc}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

const PP_CONTENT = {
  blues: { title: 'Baby Blues', content: `<p>Baby blues affect up to 80% of new mothers. They typically appear in the first few days after delivery and improve within 1-2 weeks. Symptoms include tearfulness, mood swings, irritability, and feeling overwhelmed.</p><p style="margin-top:10px"><strong>What helps:</strong> Rest as much as possible, accept help, talk about your feelings, and be gentle with yourself. Baby blues usually resolve on their own.</p><p style="margin-top:10px"><strong>When to seek help:</strong> If symptoms persist beyond 2 weeks, worsen, or significantly affect your functioning, please speak with your doctor — this may be postpartum depression, which is very treatable.</p>` },
  low_mood: { title: 'Postpartum Depression', content: `<p>Persistent low mood lasting beyond 2 weeks, loss of interest, difficulty bonding with baby, hopelessness, or significant changes in sleep/appetite may indicate postpartum depression (PPD).</p><p style="margin-top:10px">PPD is a medical condition — not a character flaw or failure as a mother. It affects approximately 1 in 5 new mothers.</p><p style="margin-top:10px"><strong>Please speak with your doctor or midwife.</strong> Effective treatments include therapy, support groups, and when indicated, medication that is safe while breastfeeding. The sooner you seek help, the sooner you will feel better.</p>`, urgent: true },
  intrusive: { title: 'Intrusive Thoughts', content: `<p>Unwanted, distressing thoughts — often about something happening to your baby — are actually common in the postpartum period and are a feature of anxiety, not intent. Most new parents experience them.</p><p style="margin-top:10px">The fact that these thoughts disturb you means they are not a reflection of your true wishes or character. However, they can be very frightening.</p><p style="margin-top:10px"><strong>Important:</strong> If thoughts feel like urges rather than unwanted intrusions, or if you feel you might act on them, seek immediate medical help. Otherwise, please tell your doctor — effective treatment (often therapy) is available.</p>`, urgent: true }
};

function openPPSection(id) {
  const area = document.getElementById('ppDetail');
  const content = PP_CONTENT[id];
  if (!content) {
    area.innerHTML = `
      <div class="alert alert-info">
        SAHELI AI can provide personalized support for what you're experiencing. Or speak with your doctor or midwife about how you're feeling — they are your best resource during this time.
        <br><br>
        <button class="btn btn-primary btn-sm" onclick="navigateTo('ai-chat')">Talk to SAHELI AI →</button>
        <button class="btn btn-secondary btn-sm" onclick="navigateTo('professionals')">Find Support →</button>
      </div>`;
    return;
  }
  area.innerHTML = `
    <div class="card ${content.urgent ? 'card-coral' : 'card-lavender'}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <div class="card-label">${content.title}</div>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('ppDetail').innerHTML=''">✕</button>
      </div>
      ${content.urgent ? '<div class="alert alert-warning mb-12">⚠️ Please discuss these symptoms with your doctor or midwife.</div>' : ''}
      <div style="font-size:13px;color:var(--text-700);line-height:1.75">${content.content}</div>
      <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="navigateTo('professionals')">Find Professional Help</button>
        <a href="tel:14416" class="btn btn-secondary btn-sm">💙 14416 Tele-MANAS</a>
      </div>
    </div>`;
  area.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

window.POSTPARTUM_MODULE = { render: renderPostpartum };
window.openPPSection = openPPSection;
