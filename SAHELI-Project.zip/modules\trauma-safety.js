﻿// SAHELI Trauma & Safety Module
function renderTraumaSafety() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header" style="background:linear-gradient(135deg,#2C3E50,#4A235A)">
        <div class="module-header-badge">🛡️ Safety First</div>
        <h1>Trauma & Safety Support</h1>
        <p>This is a trauma-informed, judgment-free space. You are in control. Share only what you feel comfortable with.</p>
      </div>
      <div class="module-content">

        <!-- Immediate Safety Check -->
        <div class="card" style="border:2px solid var(--danger);margin-top:24px">
          <div style="display:flex;align-items:center;gap:12px">
            <span style="font-size:32px">🚨</span>
            <div>
              <div class="card-label" style="color:var(--danger)">IMMEDIATE SAFETY CHECK</div>
              <div style="font-size:14px;font-weight:600;color:var(--text-800)">Are you currently in a safe place?</div>
            </div>
          </div>
          <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap">
            <button class="btn btn-success" id="safetyYesBtn">✅ Yes, I am safe right now</button>
            <button class="btn btn-danger" id="safetyNoBtn">🆘 No, I need help now</button>
            <button class="btn btn-outline" id="safetyUnsureBtn">❓ I'm not sure</button>
          </div>
        </div>

        <!-- Safety Response Area -->
        <div id="safetyResponseArea" class="mt-16"></div>

        <!-- Quick Exit -->
        <div style="text-align:right;margin-top:8px">
          <a href="https://google.com" class="btn btn-outline btn-sm" style="font-size:11px">🚪 Quick Exit (leaves this page)</a>
        </div>

        <!-- Harassment Recovery Blueprint -->
        <div class="card mt-24">
          <div class="card-label">Open Harassment Recovery Blueprint</div>
          <div class="card-title mt-8">Your Personalized Support Pathway</div>
          <div class="card-desc mt-4">Step-by-step guidance for navigating harassment, abuse, or trauma — at your own pace, with full control.</div>
          <div id="blueprintArea" class="mt-16">
            <div class="card-grid-2">
              ${[
                ['🛡️', 'Understand My Rights', 'Learn about legal protections, reporting options, and what support services can offer.', 'rights'],
                ['📋', 'Document Safely', 'Guidance on how to safely record incidents without putting yourself at risk.', 'document'],
                ['💙', 'Find Support', 'Connect with counsellors, support groups, and helplines tailored to your situation.', 'support'],
                ['🌱', 'Healing Journey', 'Trauma-informed activities and recovery steps at your own pace.', 'healing'],
                ['🏠', 'Safety Planning', 'Create a personal safety plan with trusted contacts and escape options.', 'safety-plan'],
                ['⚖️', 'Reporting Options', 'Information about reporting to police, workplace HR, or authorities — if and when you choose.', 'reporting']
              ].map(([icon, title, desc, id]) => `
                <div class="activity-card card-clickable" onclick="openBlueprintSection('${id}')">
                  <div style="font-size:28px;margin-bottom:8px">${icon}</div>
                  <div class="activity-title">${title}</div>
                  <div class="activity-desc mt-4">${desc}</div>
                  <div style="color:var(--purple-600);font-size:12px;font-weight:600;margin-top:8px">Open →</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div id="blueprintDetail" class="mt-16"></div>
        </div>

        <!-- Grounding for Trauma -->
        <div class="card card-sage mt-24">
          <div class="card-label">Grounding When Overwhelmed</div>
          <div class="card-title mt-8">When trauma feels overwhelming right now</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:12px">
            ${[
              ['🖐️', 'Touch something solid', 'Put your hands on a table, wall, or floor. Feel the texture and temperature. You are here, you are safe right now.'],
              ['👁️', 'Look around slowly', 'Name 5 things you can see. Say them aloud or in your mind. Come back to this room, this moment.'],
              ['🌬️', 'Slow your breathing', 'Breathe in for 4 counts, out for 6. Repeat 5 times. Your nervous system will begin to settle.'],
              ['🧊', 'Temperature reset', 'Hold ice cubes, splash cold water on your face, or hold a cold glass. Physical sensations can interrupt trauma responses.'],
              ['💬', 'Say your name and location', '"My name is ___. I am in ___. Today is ___. I am safe right now." Repeat slowly.']
            ].map(([icon, title, desc]) => `
              <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--sage-300)">
                <span style="font-size:20px">${icon}</span>
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${title}</div>
                  <div style="font-size:12px;color:var(--text-600);margin-top:2px">${desc}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Helplines -->
        <div class="card mt-24" style="border-color:var(--coral-300)">
          <div class="card-label">Verified Support Helplines (India)</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
            ${[
              ['112', '📞', 'National Emergency', 'Police, ambulance, fire — 24/7 emergency response', 'tel:112'],
              ['14416', '💙', 'Tele-MANAS', 'Free mental health support — 24/7, multilingual', 'tel:14416'],
              ['181', '🌸', 'Women Helpline', 'Support for women in distress — 24/7', 'tel:181'],
              ['1091', '🚨', 'Women Helpline (Distress)', 'For women facing violence or harassment', 'tel:1091'],
              ['7827170170', '💜', 'iCall Psychosocial Helpline', 'TISS mental health support — Mon-Sat 8am-10pm', 'tel:7827170170']
            ].map(([num, icon, name, desc, href]) => `
              <div style="display:flex;align-items:center;gap:12px;padding:10px;border:1px solid var(--border-light);border-radius:var(--radius-md)">
                <span style="font-size:20px">${icon}</span>
                <div style="flex:1">
                  <div style="font-size:13px;font-weight:700;color:var(--text-800)">${name} — <span style="color:var(--purple-700)">${num}</span></div>
                  <div style="font-size:11px;color:var(--text-400)">${desc}</div>
                </div>
                <a href="${href}" class="btn btn-primary btn-sm">Call</a>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Professional Support -->
        <div class="alert alert-info mt-16">
          <strong>💙 Remember:</strong> Healing from trauma takes time and professional support makes a significant difference. 
          A trauma-informed counsellor or psychologist can help you process experiences safely, at your own pace. 
          <button class="btn btn-primary btn-sm mt-8" onclick="navigateTo('professionals')">Find a Trauma Counsellor →</button>
        </div>

      </div>
    </div>
  `;

  // Safety check buttons
  document.getElementById('safetyYesBtn').addEventListener('click', () => {
    document.getElementById('safetyResponseArea').innerHTML = `
      <div class="alert alert-success">
        ✅ I'm glad you're safe right now. SAHELI is here to support you. Take your time exploring the resources below — there's no pressure.
      </div>`;
  });

  document.getElementById('safetyNoBtn').addEventListener('click', () => {
    SAFETY.showImmediate('You said you are not safe right now. Please call for help immediately.');
  });

  document.getElementById('safetyUnsureBtn').addEventListener('click', () => {
    document.getElementById('safetyResponseArea').innerHTML = `
      <div class="alert alert-warning">
        <strong>⚠️ It's okay to be unsure.</strong> If at any point you feel you might be in danger, please call 112 (emergency) or 181 (women's helpline).<br><br>
        Tell me more: <button class="btn btn-primary btn-sm" onclick="navigateTo('ai-chat')">Talk to SAHELI AI →</button>
      </div>`;
  });
}

function openBlueprintSection(sectionId) {
  const area = document.getElementById('blueprintDetail');
  const sections = {
    rights: {
      title: 'Understanding Your Rights',
      content: `<p>In India, you have legal protections against many forms of harassment and abuse:</p>
        <ul style="padding-left:20px;line-height:2;font-size:13px;color:var(--text-700)">
          <li><strong>Sexual Harassment at Workplace (POSH Act, 2013):</strong> Every workplace with 10+ employees must have an Internal Complaints Committee. You have the right to file a complaint.</li>
          <li><strong>Domestic Violence (Protection of Women from DV Act, 2005):</strong> Covers physical, sexual, emotional, verbal, and economic abuse. You can approach a Protection Officer.</li>
          <li><strong>Section 498A IPC:</strong> Protects married women from cruelty by husband or in-laws.</li>
          <li><strong>Sexual offences (IPC Sections 354, 375-376):</strong> Cover molestation, stalking, rape. You can file an FIR at any police station.</li>
          <li><strong>Right to a zero FIR:</strong> You can file at any police station, regardless of jurisdiction.</li>
        </ul>
        <div class="alert alert-info mt-12">You do not need to report to access support services. Reporting is your choice, made at the time that feels right for you.</div>`
    },
    document: {
      title: 'Documenting Safely',
      content: `<p style="font-size:13px;color:var(--text-600);margin-bottom:12px">If you choose to document incidents, here is guidance to do so safely:</p>
        <ul style="padding-left:20px;line-height:2;font-size:13px;color:var(--text-700)">
          <li>Keep a private, dated record of incidents — what happened, when, where, and witnesses if any.</li>
          <li>Save evidence (screenshots, messages, emails) to a private cloud account the other person cannot access.</li>
          <li>Write down physical or emotional effects you experience.</li>
          <li>Only document what is safe for you to document. Your safety comes first.</li>
          <li>Consider a separate email or device for evidence storage if home safety is a concern.</li>
        </ul>
        <div class="alert alert-warning mt-12">⚠️ Do not document in a way that puts you at risk of retaliation. Your safety is the priority.</div>`
    },
    support: {
      title: 'Finding Support',
      content: `<p style="font-size:13px;color:var(--text-600);margin-bottom:12px">Support is available at every step:</p>
        <ul style="padding-left:20px;line-height:2;font-size:13px;color:var(--text-700)">
          <li><strong>Trusted person:</strong> A friend, family member, colleague, or teacher who can listen and support you.</li>
          <li><strong>Counsellor or therapist:</strong> Especially one trained in trauma. Conversations are confidential.</li>
          <li><strong>NGOs:</strong> Many organisations provide free support, legal aid, and shelter. Examples include iCall, SNEHI, Vandrevala Foundation, Majlis Manch, Sakhi.</li>
          <li><strong>Workplace HR:</strong> For workplace harassment, HR or the Internal Complaints Committee can help.</li>
          <li><strong>Women's helplines:</strong> 181, 1091 — free, 24/7.</li>
        </ul>`
    },
    healing: {
      title: 'Healing Journey',
      content: `<p style="font-size:13px;color:var(--text-600);margin-bottom:12px">Healing from trauma is possible. It is not linear, and it takes time:</p>
        <ul style="padding-left:20px;line-height:2;font-size:13px;color:var(--text-700)">
          <li>Trauma responses (flashbacks, numbness, hypervigilance, nightmares) are normal nervous system responses — not weakness.</li>
          <li>Working with a trauma-informed therapist is the most effective path for many people.</li>
          <li>Grounding exercises (see above) can help when you feel overwhelmed.</li>
          <li>Gentle movement, creative expression, and journaling can support processing.</li>
          <li>Connection with safe, trusted people helps recovery.</li>
          <li>Rest and physical self-care are healing, not indulgence.</li>
        </ul>
        <button class="btn btn-primary btn-sm mt-12" onclick="navigateTo('healing-library')">Open Healing Library →</button>`
    },
    'safety-plan': {
      title: 'Personal Safety Plan',
      content: `<p style="font-size:13px;color:var(--text-600);margin-bottom:12px">A personal safety plan helps you prepare for difficult moments:</p>
        <ol style="padding-left:20px;line-height:2;font-size:13px;color:var(--text-700)">
          <li><strong>Identify warning signs:</strong> What signals that a situation may become unsafe?</li>
          <li><strong>Safe people:</strong> List 2-3 people you can call or go to.</li>
          <li><strong>Safe places:</strong> Where can you go if you need to leave quickly?</li>
          <li><strong>Important documents:</strong> Keep copies of ID, medical records, and financial documents in a safe place.</li>
          <li><strong>Emergency bag:</strong> If leaving home is a concern, have essentials ready.</li>
          <li><strong>Emergency contacts:</strong> Save 112, 181, and trusted contacts in your phone.</li>
        </ol>
        <div class="alert alert-info mt-12">Safety plans are personal. Only include what is realistic and safe in your situation.</div>`
    },
    reporting: {
      title: 'Reporting Options',
      content: `<p style="font-size:13px;color:var(--text-600);margin-bottom:12px">Reporting is your choice, made at the time that feels right:</p>
        <ul style="padding-left:20px;line-height:2;font-size:13px;color:var(--text-700)">
          <li><strong>Police FIR:</strong> You can file at any police station (zero FIR for any location). Ask for a woman officer if preferred.</li>
          <li><strong>Workplace complaint:</strong> Through Internal Complaints Committee or HR.</li>
          <li><strong>Online cyber crimes:</strong> cybercrime.gov.in for online harassment, stalking, non-consensual images.</li>
          <li><strong>NCW (National Commission for Women):</strong> ncwapps.nic.in for filing complaints online.</li>
        </ul>
        <div class="alert alert-warning mt-12">⚠️ You are never obligated to report. Support is available whether or not you choose to report. If you do report, you have the right to be treated with dignity and respect.</div>`
    }
  };

  const section = sections[sectionId];
  if (!section) return;
  area.innerHTML = `
    <div class="card" style="border:1px solid var(--purple-300);background:var(--purple-50)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <div class="card-label">${section.title}</div>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('blueprintDetail').innerHTML=''">✕ Close</button>
      </div>
      <div style="font-size:13px;color:var(--text-600);line-height:1.75">${section.content}</div>
      <div style="margin-top:16px">
        <button class="btn btn-secondary btn-sm" onclick="VOICE.speak(document.getElementById('blueprintDetail').innerText.substring(0,600))">🔊 Read Aloud</button>
      </div>
    </div>
  `;
  area.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

window.TRAUMA_MODULE = { render: renderTraumaSafety };
window.openBlueprintSection = openBlueprintSection;
