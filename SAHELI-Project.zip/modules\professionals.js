﻿// SAHELI Find Professionals Module
function renderProfessionals() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">👩‍⚕️ Professional Support</div>
        <h1>Find Professional Support</h1>
        <p>Finding the right professional is an important step. Here you'll find verified helplines, guidance on types of support, and tools to find providers near you.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-info mt-16">ℹ️ SAHELI provides information about types of professionals and verified helplines. For a list of professionals near you, please use the search tools below or contact a helpline who can help connect you.</div>

        <!-- Helplines First -->
        <div class="section-header mt-24 mb-12">
          <div class="section-title">Verified Helplines</div>
          <span class="tag tag-success">Always available</span>
        </div>

        <div style="display:flex;flex-direction:column;gap:10px" id="helplinesList">
          ${[
            { num:'112', name:'National Emergency', type:'Emergency', hours:'24/7', desc:'Police, ambulance, fire. If you are in immediate danger.', color:'danger' },
            { num:'14416', name:'Tele-MANAS', type:'Mental Health', hours:'24/7, Free', desc:'Government mental health helpline. Free. Multilingual. Counselling and referrals.', color:'purple' },
            { num:'181', name:'Women Helpline', type:'Women\'s Support', hours:'24/7', desc:'Support for women in distress. Can provide referrals and assistance.', color:'coral' },
            { num:'1091', name:'Women Helpline Distress', type:'Violence/Harassment', hours:'24/7', desc:'For women facing violence, harassment, or abuse.', color:'danger' },
            { num:'7827170170', name:'iCall — TISS', type:'Counselling', hours:'Mon-Sat 8am-10pm', desc:'Psychosocial support from trained professionals. Short-term counselling available.', color:'purple' },
            { num:'1800-599-0019', name:'Vandrevala Foundation', type:'Mental Health', hours:'24/7, Toll-free', desc:'Free, anonymous mental health support. Available in multiple languages.', color:'sage' },
            { num:'044-24640050', name:'SNEHI', type:'Emotional Support', hours:'Mon-Sat 8am-10pm', desc:'Confidential emotional support and referrals.', color:'lavender' },
            { num:'9152987821', name:'iCall SMS/WhatsApp', type:'Chat Support', hours:'Mon-Sat 8am-10pm', desc:'Message-based support for those who prefer not to call.', color:'purple' }
          ].map(h => `
            <div class="card" style="border-left:4px solid var(--${h.color}-500,var(--purple-500));padding:16px 20px">
              <div style="display:flex;align-items:flex-start;gap:12px">
                <div style="flex:1">
                  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                    <div style="font-size:14px;font-weight:700;color:var(--text-800)">${h.name}</div>
                    <span class="tag tag-purple" style="font-size:9px">${h.type}</span>
                    <span class="tag tag-sage" style="font-size:9px">${h.hours}</span>
                  </div>
                  <div style="font-size:12px;color:var(--text-500);margin:4px 0">${h.desc}</div>
                  <div style="font-size:13px;font-weight:700;color:var(--purple-600)">${h.num}</div>
                </div>
                <div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0">
                  <a href="tel:${h.num.replace(/-/g,'')}" class="btn btn-primary btn-sm">📞 Call</a>
                </div>
              </div>
            </div>
          `).join('')}
        </div>

        <!-- Types of Professionals -->
        <div class="section-header mt-32 mb-12">
          <div class="section-title">Understanding Types of Support</div>
        </div>

        <div class="card-grid-2">
          ${[
            ['🧠', 'Psychologist', 'Trained in assessment and psychological therapies (CBT, trauma therapy, etc.). Cannot prescribe medication. Good for: anxiety, depression, trauma, relationships, assessment.'],
            ['💊', 'Psychiatrist', 'Medical doctor specializing in mental health. Can prescribe medication. Good for: severe depression, bipolar disorder, psychosis, medication management.'],
            ['💬', 'Counsellor', 'Provides supportive listening and guidance. May specialize in areas like grief, relationships, trauma. Good for: emotional support, life transitions, milder concerns.'],
            ['👩‍⚕️', 'Gynaecologist', 'For menopause, PCOS, postpartum concerns, reproductive health, and hormonal issues affecting mental health.'],
            ['🏥', 'Government Mental Health Centres', 'Free or subsidized mental health care through NIMHANS, District Mental Health Programme (DMHP), and government hospitals.'],
            ['🤝', 'Support Groups', 'Peer-led groups for specific experiences (grief, addiction recovery, domestic violence survivors). Often free and available in person or online.']
          ].map(([icon, title, desc]) => `
            <div class="card">
              <div style="font-size:28px;margin-bottom:10px">${icon}</div>
              <div class="card-label">${title}</div>
              <div style="font-size:12px;color:var(--text-600);margin-top:6px;line-height:1.65">${desc}</div>
            </div>
          `).join('')}
        </div>

        <!-- Find Online -->
        <div class="card card-purple mt-24">
          <div class="card-label">Search for Professionals Online</div>
          <div class="card-title mt-8">Verified Directories</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
            ${[
              ['Vandrevala Foundation Therapist Search', 'Find verified therapists in your city', 'https://www.vandrevalafoundation.com'],
              ['iCall Referral', 'Call 9152987821 — they can refer you to therapists', 'tel:9152987821'],
              ['The Minds Foundation', 'Mental health support across multiple Indian cities', 'https://www.theminds.in'],
              ['NIMHANS, Bangalore', 'National institute offering mental health services', 'https://www.nimhans.ac.in'],
              ['1mg Doctor Search', 'Find psychologists and psychiatrists on 1mg', 'https://www.1mg.com/doctors/psychiatrist'],
              ['Practo Professional Search', 'Search for mental health professionals in your city', 'https://www.practo.com/psychiatrist']
            ].map(([name, desc, url]) => `
              <div style="display:flex;align-items:center;gap:12px;padding:10px;border:1px solid var(--purple-200);border-radius:var(--radius-md);background:rgba(255,255,255,0.6)">
                <div style="flex:1">
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${name}</div>
                  <div style="font-size:11px;color:var(--text-400)">${desc}</div>
                </div>
                <a href="${url}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm">Visit →</a>
              </div>
            `).join('')}
          </div>
          <div class="alert alert-warning mt-12">⚠️ SAHELI does not endorse or verify individual practitioners. Please do your own research and, if possible, seek recommendations from trusted sources.</div>
        </div>

        <!-- What to Look For -->
        <div class="card mt-24">
          <div class="card-label">How to Choose the Right Professional</div>
          <ul style="padding-left:20px;margin-top:12px;font-size:13px;color:var(--text-700);line-height:2">
            <li><strong>Qualifications:</strong> Look for recognized credentials (M.Phil Psychology, MBBS + MD Psychiatry, certified counsellor)</li>
            <li><strong>Specialization:</strong> Find someone with experience in your specific concern (trauma, women's health, anxiety, etc.)</li>
            <li><strong>Language:</strong> You should be able to speak in your preferred language</li>
            <li><strong>Trust and safety:</strong> It's okay to switch if you don't feel comfortable — the therapeutic relationship matters</li>
            <li><strong>Fees:</strong> Discuss fees upfront. Many practitioners offer sliding scale fees. Government centres are free or very low cost.</li>
          </ul>
        </div>

      </div>
    </div>
  `;
}

window.PROFESSIONALS_MODULE = { render: renderProfessionals };
