const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

const moodButtons = [...document.querySelectorAll(".mood-option")];
const moodFeedback = document.getElementById("moodFeedback");
let selectedMood = "";

moodButtons.forEach((button) => {
  button.addEventListener("click", () => {
    selectedMood = button.dataset.mood;
    moodButtons.forEach((item) => {
      item.setAttribute("aria-pressed", String(item === button));
    });
    moodFeedback.textContent = "";
  });
});

document.getElementById("saveMood").addEventListener("click", () => {
  if (!selectedMood) {
    moodFeedback.style.color = "#a34065";
    moodFeedback.textContent = "Choose the feeling closest to yours, or leave this check-in for another time.";
    return;
  }
  const messages = {
    Calm: "Notice what is helping you feel calm, and give yourself permission to enjoy this moment.",
    Okay: "Okay is enough for right now. You don't have to force yourself to feel any other way.",
    Anxious: "Try placing both feet on the floor and naming three things you can see around you.",
    Low: "You deserve care on low days, too. Consider reaching out to someone you trust.",
    Overwhelmed: "You don't need to solve everything at once. Pick one small next step, or take a pause."
  };
  moodFeedback.style.color = "#6e815f";
  moodFeedback.textContent = messages[selectedMood];
});

const modal = document.getElementById("contentModal");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");

const articles = {
  stress: {
    title: "When everything feels like too much",
    body: `<p>Stress can show up in your thoughts, body, sleep, or patience. You do not need to fix everything in one sitting.</p>
      <ul><li>Choose one task that matters now; let the rest wait if it can.</li><li>Take a short break from notifications or noise.</li><li>Tell someone you trust what feels difficult, even if you cannot explain it perfectly.</li></ul>
      <p>If stress is persistent or interfering with everyday life, a qualified professional can help you work out what support may be useful.</p>`
  },
  mood: {
    title: "Understanding persistent sadness",
    body: `<p>Feeling sad sometimes is part of life. Depression is different: symptoms can persist and affect sleep, energy, concentration, relationships, or daily activities.</p>
      <p>Only a qualified health professional can assess whether symptoms meet the criteria for depression. You do not have to wait until things feel unbearable to ask for help.</p>
      <p>If low mood lasts around two weeks or more, or is affecting daily life, consider talking with a doctor or mental health professional.</p>`
  },
  help: {
    title: "You can reach out before it gets worse",
    body: `<p>Asking for support does not mean you have failed. You could start with a trusted friend, family member, teacher, doctor, counsellor, or qualified mental health professional.</p>
      <ul><li>You can say: “I've been finding things difficult lately. Could you listen for a little while?”</li><li>If the first person is not helpful, try someone else who can take you seriously.</li><li>If you are in immediate danger, contact local emergency services or go to the nearest emergency department.</li></ul>
      <p>For helplines in different countries, visit <a href="https://findahelpline.com/" target="_blank" rel="noopener noreferrer">Find A Helpline</a>.</p>`
  }
};

document.querySelectorAll("[data-modal]").forEach((button) => {
  button.addEventListener("click", () => {
    const article = articles[button.dataset.modal];
    if (!article) return;
    modalTitle.textContent = article.title;
    modalBody.innerHTML = article.body;
    modal.showModal();
  });
});

document.getElementById("modalClose").addEventListener("click", () => modal.close());
document.getElementById("modalDone").addEventListener("click", () => modal.close());
modal.addEventListener("click", (event) => {
  if (event.target === modal) modal.close();
});

const groundingModal = document.getElementById("groundingModal");
document.getElementById("groundingOpen").addEventListener("click", () => groundingModal.showModal());
document.getElementById("groundingClose").addEventListener("click", () => groundingModal.close());
document.getElementById("groundingDone").addEventListener("click", () => groundingModal.close());
groundingModal.addEventListener("click", (event) => {
  if (event.target === groundingModal) groundingModal.close();
});
