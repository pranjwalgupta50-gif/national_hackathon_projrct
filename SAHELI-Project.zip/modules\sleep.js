﻿// SAHELI Sleep & Energy Assessment Module
function renderSleep() {
  const container = document.getElementById('moduleContainer');
  const sleepData = STATE.get('sleepData') || [];
  const last = sleepData[0];
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">🌙 Sleep & Energy</div>
        <h1>Sleep & Energy Assessment</h1>
        <p>Understanding your sleep helps SAHELI give you better guidance. All data is self-reported and stored privately on your device.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-info mt-16">ℹ️ Sleep needs vary by age, health, and individual factors. General guidance for adults is 7–9 hours per night. This tool uses your self-reported data — it does not measure sleep medically.</div>

        <!-- Sleep Log Form -->
        <div class="card mt-24">
          <div class="card-label">Log Tonight's Sleep</div>
          <div class="card-grid-2 mt-16">
            <div class="form-group">
              <label class="form-label">Bedtime (approximate)</label>
              <input type="time" class="form-input" id="sleepBedtime" value="22:30" />
            </div>
            <div class="form-group">
              <label class="form-label">Wake-up time</label>
              <input type="time" class="form-input" id="sleepWakeup" value="06:30" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Sleep quality</label>
            <select class="form-select" id="sleepQuality">
              <option value="good">Good — slept through, feel rested</option>
              <option value="fair">Fair — woke once or twice, manageable</option>
              <option value="poor">Poor — woke often, hard to return to sleep</option>
              <option value="very_poor">Very poor — barely slept, feel exhausted</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Daytime energy level: <span id="energyVal" style="color:var(--purple-700);font-weight:700">5/10</span></label>
            <input type="range" id="energyLevel" min="1" max="10" value="5" />
            <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-400);margin-top:4px">
              <span>Completely drained</span><span>Fully energised</span>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">What most affected your sleep? (optional)</label>
            <select class="form-select" id="sleepAffector">
              <option value="">Not sure / nothing specific</option>
              <option value="stress">Worry or stressful thoughts</option>
              <option value="noise">Noise or environment</option>
              <option value="pain">Physical discomfort or pain</option>
              <option value="schedule">Irregular schedule</option>
              <option value="screens">Screens before bed</option>
              <option value="caffeine">Caffeine or alcohol</option>
              <option value="childcare">Childcare / feeding</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Any additional notes (optional)</label>
            <textarea class="form-textarea" id="sleepNotes" placeholder="Anything else you noticed about your sleep..." rows="2"></textarea>
          </div>
          <button class="btn btn-primary" id="saveSleepBtn">Save Sleep Log →</button>
        </div>

        <!-- Sleep Result -->
        <div id="sleepResultArea" class="mt-16"></div>

        <!-- Sleep History -->
        ${sleepData.length > 0 ? renderSleepHistory(sleepData.slice(0,7)) : ''}

        <!-- Sleep Education -->
        <div class="card mt-24">
          <div class="card-label">General Sleep Guidance</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:12px">
            ${[
              ['Adults (18–64)', '7–9 hours', 'Most adults need 7–9 hours for optimal functioning.'],
              ['Older adults (65+)', '7–8 hours', 'Slightly less may be normal, but quality still matters greatly.'],
              ['Pregnant women', '8–10 hours', 'Extra sleep supports physical recovery and fetal development.'],
              ['Postpartum mothers', 'Variable', 'Sleep is fragmented — rest whenever possible and ask for help.']
            ].map(([group, hours, note]) => `
              <div style="display:flex;gap:12px;align-items:flex-start;padding:10px 0;border-bottom:1px solid var(--border-light)">
                <span style="color:var(--purple-700);font-weight:700;font-size:13px;white-space:nowrap">${hours}</span>
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--text-800)">${group}</div>
                  <div style="font-size:12px;color:var(--text-500)">${note}</div>
                </div>
              </div>
            `).join('')}
          </div>
          <div class="alert alert-warning mt-12">⚠️ These are general guidelines from health organizations. Individual needs vary. If you experience persistent sleep problems, consult a doctor — sleep disorders are treatable.</div>
        </div>

      </div>
    </div>
  `;

  const energySlider = document.getElementById('energyLevel');
  energySlider.addEventListener('input', () => {
    document.getElementById('energyVal').textContent = energySlider.value + '/10';
  });

  document.getElementById('saveSleepBtn').addEventListener('click', () => {
    const bedtime = document.getElementById('sleepBedtime').value;
    const wakeup = document.getElementById('sleepWakeup').value;
    const quality = document.getElementById('sleepQuality').value;
    const energy = parseInt(document.getElementById('energyLevel').value);
    const affector = document.getElementById('sleepAffector').value;
    const notes = document.getElementById('sleepNotes').value;

    // Calculate duration
    const [bh, bm] = bedtime.split(':').map(Number);
    const [wh, wm] = wakeup.split(':').map(Number);
    let bedMinutes = bh * 60 + bm;
    let wakeMinutes = wh * 60 + wm;
    if (wakeMinutes <= bedMinutes) wakeMinutes += 24 * 60;
    const durationMinutes = wakeMinutes - bedMinutes;
    const duration = (durationMinutes / 60).toFixed(1);

    const entry = STATE.recordSleep({ bedtime, wakeup, duration: parseFloat(duration), quality, energy, affector, notes });
    showToast('Sleep log saved 🌙', 'success');
    showSleepResult(entry);
  });
}

function showSleepResult(entry) {
  const area = document.getElementById('sleepResultArea');
  const dur = entry.duration;
  const recommended = 8;
  const diff = (dur - recommended).toFixed(1);
  const qualityLabels = { good: 'Good', fair: 'Fair', poor: 'Poor', very_poor: 'Very Poor' };
  const qualityColors = { good: 'var(--success)', fair: 'var(--warning)', poor: 'var(--danger)', very_poor: 'var(--danger)' };

  let sleepAdvice = '';
  if (dur < 6) {
    sleepAdvice = `You reported ${dur} hours of sleep, which is below the recommended 7–9 hours for most adults. Chronic short sleep affects mood, concentration, immunity, and overall health. Prioritising even one extra hour can make a noticeable difference. If you're regularly sleeping under 6 hours, please speak with a doctor.`;
  } else if (dur < 7) {
    sleepAdvice = `You reported ${dur} hours. This is slightly below the general recommendation of 7–9 hours. Even a small sleep deficit accumulates over time. Try moving your bedtime 30 minutes earlier for a week and see if it makes a difference.`;
  } else if (dur <= 9) {
    sleepAdvice = `You reported ${dur} hours — within the recommended range of 7–9 hours for most adults. The quality of your sleep also matters. See below for quality-based suggestions.`;
  } else {
    sleepAdvice = `You reported ${dur} hours. Sleeping more than 9–10 hours regularly can sometimes be a sign of depression, low energy, or a physical health concern. It's worth mentioning to your doctor if this is a regular pattern.`;
  }

  let qualityAdvice = '';
  if (entry.quality === 'poor' || entry.quality === 'very_poor') {
    qualityAdvice = '<p style="margin-top:8px">Poor sleep quality often responds well to: consistent sleep/wake times, a wind-down routine, reducing screens 60 minutes before bed, and limiting caffeine after 2pm. If poor quality persists beyond 3-4 weeks, please speak with a doctor — insomnia is a treatable condition.</p>';
  }

  const affectorTips = {
    stress: 'For stress-related insomnia: try a "worry dump" journal 30 minutes before bed — write all worries, then close the book. This can prevent racing thoughts at bedtime.',
    screens: 'Blue light from screens suppresses melatonin. Try the 60-minute screen-free wind-down rule, or use night mode/blue-light glasses.',
    caffeine: 'Caffeine has a half-life of about 5–6 hours. A 4pm coffee may still affect sleep at 10pm. Consider cutting caffeine after 2pm.',
    pain: 'Physical discomfort affecting sleep deserves medical attention. Please speak with your doctor about pain management.',
    childcare: 'Sleep disruption from childcare is very real and exhausting. Prioritise sleep when your child sleeps, and ask for support from a partner or family member where possible.'
  };

  area.innerHTML = `
    <div class="card card-sage">
      <div class="card-label">Your Sleep Analysis — ${new Date().toLocaleDateString('en-IN', {day:'numeric',month:'short'})}</div>
      <div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;margin-top:12px">
        <div style="text-align:center">
          <div style="font-size:40px;font-weight:700;color:var(--purple-700)">${dur}h</div>
          <div style="font-size:11px;color:var(--text-400)">Reported duration</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:24px;font-weight:700;color:${qualityColors[entry.quality] || 'var(--text-700)'}">${qualityLabels[entry.quality]}</div>
          <div style="font-size:11px;color:var(--text-400)">Sleep quality</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:24px;font-weight:700;color:var(--purple-600)">${entry.energy}/10</div>
          <div style="font-size:11px;color:var(--text-400)">Daytime energy</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:18px;font-weight:700;color:${parseFloat(diff) >= 0 ? 'var(--success)' : 'var(--warning)'}">${parseFloat(diff) >= 0 ? '+' : ''}${diff}h</div>
          <div style="font-size:11px;color:var(--text-400)">vs. 8h guideline</div>
        </div>
      </div>
      <div class="alert alert-info mt-16">${sleepAdvice}${qualityAdvice}</div>
      ${entry.affector && affectorTips[entry.affector] ? `<div class="alert alert-warning mt-8"><strong>Tip for "${entry.affector}":</strong> ${affectorTips[entry.affector]}</div>` : ''}
      <p style="font-size:11px;color:var(--text-400);margin-top:8px">This analysis is based solely on your self-reported data. It is not a medical assessment or diagnosis of a sleep disorder.</p>
    </div>
  `;
}

function renderSleepHistory(data) {
  return `
    <div class="card mt-24">
      <div class="card-label">Recent Sleep History</div>
      <div style="margin-top:12px">
        ${data.map(entry => `
          <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-light)">
            <span style="font-size:20px">🌙</span>
            <div style="flex:1">
              <div style="font-size:13px;font-weight:600;color:var(--text-800)">${entry.duration}h · ${entry.quality?.replace('_',' ') || 'recorded'}</div>
              <div style="font-size:11px;color:var(--text-400)">${entry.bedtime} → ${entry.wakeup} · Energy: ${entry.energy}/10</div>
            </div>
            <span style="font-size:11px;color:var(--text-300)">${new Date(entry.date).toLocaleDateString('en-IN', {day:'numeric',month:'short'})}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

window.SLEEP_MODULE = { render: renderSleep };
