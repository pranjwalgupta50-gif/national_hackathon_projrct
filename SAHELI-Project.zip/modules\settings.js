﻿// SAHELI Settings Panel Module
function renderSettings() {
  const panel = document.getElementById('settingsPanel');
  if (!panel) return;
  const apiKey = STATE.get('openaiKey') || '';
  const userName = STATE.get('userName') || '';
  const lang = STATE.get('language') || 'en';
  const model = STATE.get('aiModel') || 'gpt-4o-mini';
  const rate = STATE.get('speechRate') || 1.0;
  const notifs = STATE.get('notifications') || {};

  panel.innerHTML = `
    <div class="settings-overlay" onclick="closeSettings()"></div>
    <div class="settings-drawer">
      <div class="settings-header">
        <h2>⚙️ Settings</h2>
        <button class="settings-close" onclick="closeSettings()" aria-label="Close settings">✕</button>
      </div>
      <div class="settings-body">

        <!-- Profile -->
        <div class="settings-section">
          <h3>Your Profile</h3>
          <div class="settings-field">
            <label for="settingsName">Your name (optional)</label>
            <input type="text" id="settingsName" value="${userName}" placeholder="How should SAHELI address you?" maxlength="40" />
            <div class="settings-hint">Used only within the app to personalize greetings.</div>
          </div>
        </div>

        <!-- Language -->
        <div class="settings-section">
          <h3>Language</h3>
          <div class="settings-field">
            <label for="settingsLang">App Language</label>
            <select id="settingsLang">
              <option value="en" ${lang==='en'?'selected':''}>English</option>
              <option value="hi" ${lang==='hi'?'selected':''}>हिंदी (Hindi)</option>
              <option value="bn" ${lang==='bn'?'selected':''}>বাংলা (Bengali)</option>
              <option value="ta" ${lang==='ta'?'selected':''}>தமிழ் (Tamil)</option>
              <option value="te" ${lang==='te'?'selected':''}>తెలుగు (Telugu)</option>
              <option value="mr" ${lang==='mr'?'selected':''}>मराठी (Marathi)</option>
              <option value="gu" ${lang==='gu'?'selected':''}>ગુજરાતી (Gujarati)</option>
              <option value="kn" ${lang==='kn'?'selected':''}>ಕನ್ನಡ (Kannada)</option>
              <option value="ml" ${lang==='ml'?'selected':''}>മലയാളം (Malayalam)</option>
              <option value="pa" ${lang==='pa'?'selected':''}>ਪੰਜਾਬੀ (Punjabi)</option>
            </select>
            <div class="settings-hint">SAHELI AI will respond in your selected language when possible.</div>
          </div>
        </div>

        <!-- OpenAI -->
        <div class="settings-section">
          <h3>🤖 AI Settings</h3>
          <div class="settings-field">
            <label for="settingsApiKey">OpenAI API Key</label>
            <div class="api-key-input-wrap">
              <input type="password" id="settingsApiKey" value="${apiKey}" placeholder="sk-..." autocomplete="off" />
              <button class="btn-toggle-key" onclick="toggleKeyVisibility()" aria-label="Toggle key visibility">👁</button>
            </div>
            <div class="settings-hint">
              Your API key is stored only on this device. Never shared.<br>
              <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener" style="color:var(--purple-600)">Get a free OpenAI API key →</a>
            </div>
            <div class="settings-status" id="apiKeyStatus">${apiKey ? '✅ API key is set' : ''}</div>
          </div>
          <div class="settings-field">
            <label for="settingsModel">AI Model</label>
            <select id="settingsModel">
              <option value="gpt-4o-mini" ${model==='gpt-4o-mini'?'selected':''}>GPT-4o Mini (Recommended — fast & affordable)</option>
              <option value="gpt-4o" ${model==='gpt-4o'?'selected':''}>GPT-4o (More capable, higher cost)</option>
              <option value="gpt-3.5-turbo" ${model==='gpt-3.5-turbo'?'selected':''}>GPT-3.5 Turbo (Fastest, lowest cost)</option>
            </select>
          </div>
        </div>

        <!-- Voice -->
        <div class="settings-section">
          <h3>🎤 Voice Settings</h3>
          <div class="settings-field">
            <label for="settingsVoice">Text-to-speech voice</label>
            <select id="settingsVoice">
              <option value="-1">Auto-select (recommended female voice)</option>
            </select>
            <div class="settings-hint">Browser voices. Quality varies by device and browser.</div>
          </div>
          <div class="settings-field">
            <label for="settingsSpeechRate">Speech rate: <span id="speechRateVal">${rate}</span>x</label>
            <input type="range" id="settingsSpeechRate" min="0.5" max="2" step="0.1" value="${rate}" />
            <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-400)"><span>Slower (0.5x)</span><span>Faster (2x)</span></div>
          </div>
          <button class="btn btn-secondary btn-sm" onclick="testVoice()">▶ Test Voice</button>
        </div>

        <!-- Notifications -->
        <div class="settings-section">
          <h3>🔔 Reminders</h3>
          <div class="toggle-row">
            <span>Daily mood check-in reminder</span>
            <label class="toggle-switch"><input type="checkbox" id="notifMood" ${notifs.mood ? 'checked' : ''} /><span class="toggle-slider"></span></label>
          </div>
          <div class="toggle-row">
            <span>Recovery activity reminders</span>
            <label class="toggle-switch"><input type="checkbox" id="notifRecovery" ${notifs.recovery ? 'checked' : ''} /><span class="toggle-slider"></span></label>
          </div>
          <div class="toggle-row">
            <span>Journal prompts</span>
            <label class="toggle-switch"><input type="checkbox" id="notifJournal" ${notifs.journal ? 'checked' : ''} /><span class="toggle-slider"></span></label>
          </div>
          <div class="settings-hint">Browser notifications — you may be asked to grant permission.</div>
        </div>

        <!-- Save -->
        <button class="btn btn-primary btn-full" id="saveSettingsBtn">Save Settings</button>
        <div class="settings-status mt-8" id="settingsSaveStatus"></div>

        <!-- Danger Zone -->
        <div class="settings-section settings-danger mt-24">
          <h3>⚠️ Danger Zone</h3>
          <p class="settings-hint">Clearing all data permanently removes everything stored on this device. This cannot be undone.</p>
          <button class="btn btn-danger btn-full mt-12" onclick="confirmClearAll()">Clear All My Data</button>
        </div>

      </div>
    </div>
  `;

  // Populate voice selector
  VOICE.populateVoiceSelector();

  // Speech rate slider
  const rateSlider = document.getElementById('settingsSpeechRate');
  rateSlider.addEventListener('input', () => {
    document.getElementById('speechRateVal').textContent = rateSlider.value;
  });

  // Save
  document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);

  panel.classList.remove('hidden');
}

function saveSettings() {
  const name = document.getElementById('settingsName').value.trim();
  const lang = document.getElementById('settingsLang').value;
  const apiKey = document.getElementById('settingsApiKey').value.trim();
  const model = document.getElementById('settingsModel').value;
  const voiceIdx = parseInt(document.getElementById('settingsVoice').value);
  const rate = parseFloat(document.getElementById('settingsSpeechRate').value);
  const notifMood = document.getElementById('notifMood').checked;
  const notifRecovery = document.getElementById('notifRecovery').checked;
  const notifJournal = document.getElementById('notifJournal').checked;

  STATE.set('userName', name);
  STATE.set('language', lang);
  STATE.set('aiModel', model);
  STATE.set('voiceIndex', voiceIdx);
  STATE.set('speechRate', rate);
  STATE.set('notifications', { mood: notifMood, recovery: notifRecovery, journal: notifJournal });

  if (apiKey) {
    STATE.set('openaiKey', apiKey);
    localStorage.setItem('saheli_api_key', apiKey);
  }

  // Update voice
  VOICE.rate = rate;
  VOICE.selectBestVoice();

  // Update language selector in header
  const langSel = document.getElementById('languageSelector');
  if (langSel) langSel.value = lang;

  document.getElementById('settingsSaveStatus').textContent = '✅ Settings saved';
  document.getElementById('apiKeyStatus').textContent = apiKey ? '✅ API key is set' : '';

  // Request notification permission
  if ((notifMood || notifRecovery || notifJournal) && Notification.permission === 'default') {
    Notification.requestPermission();
  }

  showToast('Settings saved 💜', 'success');
}

function toggleKeyVisibility() {
  const input = document.getElementById('settingsApiKey');
  input.type = input.type === 'password' ? 'text' : 'password';
}

function testVoice() {
  const voiceIdx = parseInt(document.getElementById('settingsVoice').value);
  const rate = parseFloat(document.getElementById('settingsSpeechRate').value);
  if (voiceIdx >= 0 && VOICE.voices[voiceIdx]) VOICE.preferredVoice = VOICE.voices[voiceIdx];
  VOICE.rate = rate;
  VOICE.speak('Namaste! I am SAHELI, your wellness companion. How can I support you today?');
}

function closeSettings() {
  const panel = document.getElementById('settingsPanel');
  if (panel) panel.classList.add('hidden');
}

function confirmClearAll() {
  if (!confirm('Delete ALL SAHELI data on this device? This cannot be undone.')) return;
  if (!confirm('Are you completely sure? Every journal entry, mood log, and setting will be permanently deleted.')) return;
  STATE.clearAll();
  showToast('All data cleared', 'success');
  setTimeout(() => location.reload(), 1500);
}

window.SETTINGS_MODULE = { render: renderSettings, close: closeSettings, save: saveSettings };
window.closeSettings = closeSettings;
window.toggleKeyVisibility = toggleKeyVisibility;
window.testVoice = testVoice;
window.confirmClearAll = confirmClearAll;
