﻿// SAHELI State Management Module
const DEFAULT_STATE = {
  language: 'en',
  userName: '',
  openaiKey: '',
  aiModel: 'gpt-4o-mini',
  voiceIndex: -1,
  speechRate: 1.0,
  notifications: { mood: true, journal: false, recovery: true },
  moods: [],
  journalEntries: [],
  sleepData: [],
  periodData: { lastPeriod: null, cycleLength: 28, periodDuration: 5, symptoms: [] },
  recoveryPlan: { concern: null, startDate: null, days: [], currentDay: 0, activities: [] },
  assessments: {},
  checklist: {},
  healingProgress: {},
  currentModule: 'home',
  safetyState: 'safe',
  notifPermission: 'default'
};

class SAHELIState {
  constructor() {
    this.data = this.load();
    this.listeners = {};
  }

  load() {
    try {
      const saved = localStorage.getItem('saheli_state');
      if (saved) return { ...DEFAULT_STATE, ...JSON.parse(saved) };
    } catch(e) { console.warn('State load error:', e); }
    return { ...DEFAULT_STATE };
  }

  save() {
    try {
      // Never save the OpenAI key in plain state - it's saved separately
      const toSave = { ...this.data };
      localStorage.setItem('saheli_state', JSON.stringify(toSave));
    } catch(e) { console.warn('State save error:', e); }
  }

  get(key) { return this.data[key]; }

  set(key, value) {
    this.data[key] = value;
    this.save();
    this.emit(key, value);
  }

  update(key, updater) {
    const current = this.data[key];
    this.data[key] = typeof updater === 'function' ? updater(current) : { ...current, ...updater };
    this.save();
    this.emit(key, this.data[key]);
  }

  on(key, fn) {
    if (!this.listeners[key]) this.listeners[key] = [];
    this.listeners[key].push(fn);
  }

  emit(key, value) {
    (this.listeners[key] || []).forEach(fn => fn(value));
  }

  // Mood recording
  recordMood(mood, intensity, note) {
    const entry = { date: new Date().toISOString(), mood, intensity: intensity || 5, note: note || '', id: Date.now() };
    this.update('moods', (prev = []) => [entry, ...prev.slice(0, 89)]);
    return entry;
  }

  todaysMood() {
    const today = new Date().toDateString();
    return (this.data.moods || []).find(m => new Date(m.date).toDateString() === today);
  }

  // Journal
  addJournalEntry(entry) {
    const e = { ...entry, id: Date.now(), date: new Date().toISOString() };
    this.update('journalEntries', (prev = []) => [e, ...prev.slice(0, 199)]);
    return e;
  }

  updateJournalEntry(id, updates) {
    this.update('journalEntries', (prev = []) => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  }

  deleteJournalEntry(id) {
    this.update('journalEntries', (prev = []) => prev.filter(e => e.id !== id));
  }

  // Sleep
  recordSleep(data) {
    const entry = { ...data, date: new Date().toISOString(), id: Date.now() };
    this.update('sleepData', (prev = []) => [entry, ...prev.slice(0, 29)]);
    return entry;
  }

  // Recovery
  startRecovery(concern) {
    const plan = {
      concern,
      startDate: new Date().toISOString(),
      currentDay: 1,
      days: [],
      activities: {},
      notes: []
    };
    this.set('recoveryPlan', plan);
    return plan;
  }

  markActivity(activityId, status) {
    this.update('recoveryPlan', (plan = {}) => {
      const acts = { ...(plan.activities || {}) };
      acts[activityId] = { status, date: new Date().toISOString() };
      return { ...plan, activities: acts };
    });
  }

  // Checklist
  toggleChecklistItem(listId, itemId, checked) {
    this.update('checklist', (prev = {}) => {
      const list = { ...(prev[listId] || {}) };
      list[itemId] = checked;
      return { ...prev, [listId]: list };
    });
  }

  getChecklistState(listId) {
    return this.data.checklist?.[listId] || {};
  }

  // Assessment
  saveAssessment(concern, answers, result) {
    this.update('assessments', (prev = {}) => ({
      ...prev,
      [concern]: { answers, result, date: new Date().toISOString() }
    }));
  }

  clearAll() {
    this.data = { ...DEFAULT_STATE };
    localStorage.clear();
  }
}

const STATE = new SAHELIState();

// Load API key from separate secure storage
const savedKey = localStorage.getItem('saheli_api_key');
if (savedKey) STATE.data.openaiKey = savedKey;

window.SAHELI_STATE = STATE;
window.STATE = STATE;

// Greeting helper
function getGreeting() {
  const h = new Date().getHours();
  const lang = STATE.get('language');
  if (h < 12) return t('goodMorning');
  if (h < 17) return t('goodAfternoon');
  return t('goodEvening');
}
window.getGreeting = getGreeting;

// Toast helper
function showToast(message, type = '', duration = 3500) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type ? 'toast-' + type : ''}`;
  toast.innerHTML = `<span>${type === 'success' ? '✓' : type === 'danger' ? '✕' : 'ℹ'}</span> <span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateY(16px)'; setTimeout(() => toast.remove(), 300); }, duration);
}
window.showToast = showToast;

// Navigate to module
function navigateTo(moduleId) {
  STATE.set('currentModule', moduleId);
  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.module === moduleId);
  });
  window.SAHELI_ROUTER && window.SAHELI_ROUTER.render(moduleId);
}
window.navigateTo = navigateTo;
