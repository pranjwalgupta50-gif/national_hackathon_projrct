﻿// SAHELI Concerns Module - Personalized Assessment Engine
const CONCERNS = [
  { id: 'loneliness', icon: '💔', title: 'Loneliness & Isolation', desc: 'Feeling disconnected, alone, or unseen' },
  { id: 'depression', icon: '🌧️', title: 'Low Mood & Depression', desc: 'Persistent sadness, loss of interest, or hopelessness' },
  { id: 'anxiety', icon: '🌀', title: 'Anxiety & Stress', desc: 'Worry, overthinking, panic, or feeling overwhelmed' },
  { id: 'sleep', icon: '😴', title: 'Sleep Problems', desc: 'Insomnia, oversleeping, or poor sleep quality' },
  { id: 'trauma', icon: '🛡️', title: 'Trauma & Past Hurt', desc: 'Difficult past experiences affecting you now' },
  { id: 'relationships', icon: '💞', title: 'Relationships & Family', desc: 'Conflict, boundaries, or emotional pain in relationships' },
  { id: 'grief', icon: '🕊️', title: 'Grief & Loss', desc: 'Processing loss of a person, relationship, or life stage' },
  { id: 'selfesteem', icon: '💫', title: 'Self-Esteem & Confidence', desc: 'Negative self-image, self-criticism, or feeling not enough' },
  { id: 'anger', icon: '🔥', title: 'Anger & Frustration', desc: 'Difficulty managing anger or intense emotions' },
  { id: 'postpartum', icon: '👶', title: 'Postpartum Emotions', desc: 'Feelings after childbirth — sadness, anxiety, or disconnection' },
  { id: 'menopause', icon: '🌸', title: 'Menopause & Hormonal Changes', desc: 'Emotional effects of hormonal transitions' },
  { id: 'financial', icon: '💰', title: 'Financial Stress', desc: 'Worry about money, debt, or financial security' },
  { id: 'workstress', icon: '💼', title: 'Work & Career Stress', desc: 'Burnout, workplace pressure, or career uncertainty' },
  { id: 'bodyimage', icon: '🪞', title: 'Body Image & Eating', desc: 'Difficult feelings about your body or food' },
  { id: 'general', icon: '🌿', title: 'Something Else', desc: 'A concern I want to explore with SAHELI' }
];

const ASSESSMENT_QUESTIONS = {
  loneliness: [
    { id: 'q1', q: 'How often do you feel lonely or isolated?', options: ['Rarely', 'Sometimes (a few times a week)', 'Often (most days)', 'Almost always'] },
    { id: 'q2', q: 'Do you have at least one person you trust and can talk to?', options: ['Yes, several people', 'Yes, one person', 'Not really', 'No, I feel completely alone'] },
    { id: 'q3', q: 'How has loneliness been affecting your daily life?', options: ['Minimal impact', 'Affecting my mood', 'Affecting my mood and activities', 'Significantly affecting everything'] },
    { id: 'q4', q: 'When did these feelings of loneliness begin?', options: ['Recently (past few weeks)', 'A few months ago', 'Over a year ago', 'Most of my life'] },
    { id: 'q5', q: 'What type of support feels most useful to you right now?', options: ['Information and coping tips', 'Activities to connect with others', 'Professional support', 'Just someone to listen (AI chat)'] }
  ],
  depression: [
    { id: 'q1', q: 'Over the past two weeks, how often have you felt down, depressed, or hopeless?', options: ['Not at all', 'Several days', 'More than half the days', 'Nearly every day'] },
    { id: 'q2', q: 'Have you lost interest or pleasure in things you used to enjoy?', options: ['Not at all', 'A little', 'Quite a bit', 'Almost completely'] },
    { id: 'q3', q: 'How has your sleep been?', options: ['Normal for me', 'Sleeping more than usual', 'Sleeping less than usual', 'Very disrupted — both too much and too little'] },
    { id: 'q4', q: 'How is your energy level?', options: ['Normal', 'A little low', 'Very low — I struggle to do basic tasks', 'Extremely low — I can barely get up'] },
    { id: 'q5', q: 'Are you having any thoughts of hurting yourself or that life isn\'t worth living?', options: ['No, not at all', 'Occasional passive thoughts (I don\'t want to be here)', 'More frequent thoughts I find distressing', 'Yes, I am having thoughts of harming myself — I need support now'] }
  ],
  anxiety: [
    { id: 'q1', q: 'How often do you feel anxious, worried, or on edge?', options: ['Occasionally', 'Several times a week', 'Most days', 'Almost constantly'] },
    { id: 'q2', q: 'Does anxiety or worry interfere with your daily activities?', options: ['Not much', 'Sometimes', 'Often', 'Yes, it\'s hard to function'] },
    { id: 'q3', q: 'Do you experience physical symptoms of anxiety (racing heart, shortness of breath, tense muscles)?', options: ['Rarely', 'Sometimes', 'Often', 'Very frequently — it\'s distressing'] },
    { id: 'q4', q: 'What triggers your anxiety most? (Choose the closest)', options: ['Social situations or judgment', 'The future or uncertainty', 'Specific situations or places', 'I\'m not sure — it seems to come without warning'] },
    { id: 'q5', q: 'Have you tried any coping strategies for anxiety before?', options: ['Yes, and they help', 'Yes, but they don\'t help much', 'No, I\'m not sure what to try', 'I\'d like guidance on what might work'] }
  ],
  sleep: [
    { id: 'q1', q: 'On average, how many hours of sleep do you get per night?', options: ['Less than 5 hours', '5–6 hours', '7–8 hours', 'More than 9 hours'] },
    { id: 'q2', q: 'How would you describe your sleep quality?', options: ['Good — I sleep through the night', 'Fair — I wake occasionally but manage', 'Poor — I wake often and struggle to return to sleep', 'Very poor — I barely sleep'] },
    { id: 'q3', q: 'How long have you been experiencing sleep difficulties?', options: ['Less than 2 weeks', '2–4 weeks', '1–3 months', 'More than 3 months'] },
    { id: 'q4', q: 'How does poor sleep affect your daytime functioning?', options: ['Mild tiredness', 'Noticeable fatigue and low mood', 'Significant difficulty concentrating or functioning', 'I can barely manage daily tasks'] },
    { id: 'q5', q: 'What do you think is most affecting your sleep?', options: ['Stress or worrying thoughts', 'Irregular schedule or habits', 'Physical discomfort or pain', 'I\'m not sure'] }
  ],
  general: [
    { id: 'q1', q: 'In your own words, what are you most concerned about right now?', type: 'text', placeholder: 'Tell SAHELI what\'s on your mind...' },
    { id: 'q2', q: 'How long have you been experiencing this?', options: ['Just started (days)', 'A few weeks', 'Several months', 'More than a year'] },
    { id: 'q3', q: 'How much is this affecting your daily life?', options: ['A little — I can manage', 'Moderately — it\'s noticeable', 'Significantly — it\'s hard', 'Severely — I\'m struggling to function'] },
    { id: 'q4', q: 'Do you feel safe in your current situation?', options: ['Yes, I am safe', 'Mostly safe', 'I have some concerns about my safety', 'I do not feel safe — I need help'] },
    { id: 'q5', q: 'What kind of support would be most helpful right now?', options: ['Information and self-help strategies', 'A guided recovery plan', 'Professional mental health support', 'Emergency or safety support'] }
  ]
};

// Default questions for concerns without custom questions
const DEFAULT_QUESTIONS = [
  { id: 'q1', q: 'How long have you been experiencing this concern?', options: ['Just started', 'A few weeks', 'Several months', 'More than a year'] },
  { id: 'q2', q: 'How much is it affecting your daily life?', options: ['Minimally', 'Somewhat', 'Significantly', 'Severely'] },
  { id: 'q3', q: 'How is your sleep at the moment?', options: ['Normal', 'Somewhat disrupted', 'Very disrupted', 'I can\'t sleep at all'] },
  { id: 'q4', q: 'Do you have people around you for support?', options: ['Yes, good support', 'Limited support', 'Very little support', 'No support at all'] },
  { id: 'q5', q: 'Do you feel safe right now?', options: ['Yes, completely', 'Mostly yes', 'Some concerns', 'I need immediate safety support'] }
];

let currentConcern = null;
let currentAnswers = {};
let currentStep = 0;
let assessmentQuestions = [];

function renderConcerns() {
  const container = document.getElementById('moduleContainer');
  container.innerHTML = `
    <div class="module-view">
      <div class="module-header">
        <div class="module-header-badge">🔍 Personalized Assessment</div>
        <h1>Explore Your Concerns</h1>
        <p>Choose what resonates with you today. I'll ask a few gentle questions and create a personalized plan just for you.</p>
      </div>
      <div class="module-content">
        <div class="alert alert-info">ℹ️ This is a wellness assessment, not a medical diagnosis. Your answers help SAHELI understand how to support you best.</div>
        <div class="section-header mt-16">
          <div class="section-title">What would you like to explore?</div>
        </div>
        <div class="concern-grid" id="concernGrid"></div>
        <div id="assessmentArea" class="mt-24"></div>
      </div>
    </div>
  `;

  const grid = document.getElementById('concernGrid');
  CONCERNS.forEach(c => {
    const card = document.createElement('div');
    card.className = 'concern-card';
    card.dataset.concern = c.id;
    card.innerHTML = `<div class="concern-icon">${c.icon}</div><div class="concern-title">${c.title}</div><div class="concern-desc">${c.desc}</div>`;
    card.addEventListener('click', () => selectConcern(c));
    grid.appendChild(card);
  });
}

function selectConcern(concern) {
  currentConcern = concern;
  currentAnswers = {};
  currentStep = 0;
  assessmentQuestions = ASSESSMENT_QUESTIONS[concern.id] || DEFAULT_QUESTIONS;

  document.querySelectorAll('.concern-card').forEach(c => {
    c.classList.toggle('selected', c.dataset.concern === concern.id);
  });

  renderAssessmentStep();
}

function renderAssessmentStep() {
  const area = document.getElementById('assessmentArea');
  if (!area) return;

  if (currentStep >= assessmentQuestions.length) {
    showAssessmentResult();
    return;
  }

  const q = assessmentQuestions[currentStep];
  const totalSteps = assessmentQuestions.length;
  const progressDots = Array.from({length: totalSteps}, (_, i) =>
    `<div class="assessment-step-dot ${i < currentStep ? 'done' : i === currentStep ? 'active' : ''}"></div>`
  ).join('');

  let optionsHtml = '';
  if (q.type === 'text') {
    optionsHtml = `
      <textarea class="form-textarea" id="freeTextAnswer" placeholder="${q.placeholder || 'Share what\'s on your mind...'}" rows="4"></textarea>
    `;
  } else {
    optionsHtml = `<div class="assessment-options">` +
      (q.options || []).map((opt, i) => `
        <div class="assessment-option ${currentAnswers[q.id] === opt ? 'selected' : ''}" data-option="${opt}" data-qi="${i}">
          <div class="assessment-option-dot"></div>
          <span>${opt}</span>
        </div>
      `).join('') + `</div>`;
  }

  area.innerHTML = `
    <div class="assessment-step">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <span class="tag tag-purple">Question ${currentStep+1} of ${totalSteps}</span>
        <span class="tag tag-coral">${currentConcern.icon} ${currentConcern.title}</span>
      </div>
      <div class="assessment-progress-bar">${progressDots}</div>
      <div class="assessment-question">${q.q}</div>
      ${optionsHtml}
      <div style="display:flex;gap:12px;margin-top:20px">
        ${currentStep > 0 ? `<button class="btn btn-outline" id="prevBtn">← Back</button>` : ''}
        <button class="btn btn-primary" id="nextBtn" ${!currentAnswers[q.id] && q.type !== 'text' ? 'disabled' : ''}>
          ${currentStep < totalSteps - 1 ? 'Next →' : 'See My Results'}
        </button>
        ${currentStep === 0 ? `<button class="btn btn-outline btn-sm" onclick="document.getElementById('assessmentArea').innerHTML='';document.querySelectorAll('.concern-card').forEach(c=>c.classList.remove('selected'))">Cancel</button>` : ''}
      </div>
    </div>
  `;

  // Wire option clicks
  area.querySelectorAll('.assessment-option').forEach(opt => {
    opt.addEventListener('click', () => {
      const val = opt.dataset.option;
      currentAnswers[q.id] = val;
      area.querySelectorAll('.assessment-option').forEach(o => o.classList.toggle('selected', o.dataset.option === val));
      area.querySelector('#nextBtn').removeAttribute('disabled');

      // Safety check on critical answers
      if (q.id === 'q5' && (val.includes('harming myself') || val.includes('I need immediate safety support') || val.includes('I do not feel safe'))) {
        SAFETY.showImmediate('You mentioned needing immediate safety support. Please reach out right now.');
      }
    });
  });

  const nextBtn = area.querySelector('#nextBtn');
  const prevBtn = area.querySelector('#prevBtn');

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (q.type === 'text') {
        currentAnswers[q.id] = document.getElementById('freeTextAnswer')?.value || '';
      }
      if (!currentAnswers[q.id] && q.type !== 'text') return;
      currentStep++;
      renderAssessmentStep();
    });
  }

  if (prevBtn) prevBtn.addEventListener('click', () => { currentStep--; renderAssessmentStep(); });
}

function showAssessmentResult() {
  const area = document.getElementById('assessmentArea');
  const concern = currentConcern;
  const answers = currentAnswers;

  // Generate severity level
  const severityAnswers = Object.values(answers);
  const severeCount = severityAnswers.filter(a =>
    a && (a.includes('severely') || a.includes('every day') || a.includes('completely') || a.includes('can barely') || a.includes('Almost always') || a.includes('Nearly every day'))
  ).length;
  const moderateCount = severityAnswers.filter(a =>
    a && (a.includes('Often') || a.includes('frequently') || a.includes('Most days') || a.includes('Significantly') || a.includes('More than half'))
  ).length;

  let severity, severityColor, severityLabel;
  if (severeCount >= 2) { severity = 'high'; severityColor = 'var(--danger)'; severityLabel = 'Needs Attention'; }
  else if (moderateCount >= 2) { severity = 'moderate'; severityColor = 'var(--warning)'; severityLabel = 'Moderate'; }
  else { severity = 'mild'; severityColor = 'var(--success)'; severityLabel = 'Mild'; }

  const plan = generateRecoveryPlan(concern.id, answers, severity);

  // Save to state
  STATE.saveAssessment(concern.id, answers, { severity, plan });

  area.innerHTML = `
    <div class="assessment-step">
      <div style="text-align:center;margin-bottom:24px">
        <div style="font-size:48px;margin-bottom:12px">${concern.icon}</div>
        <div style="font-size:24px;font-weight:700;color:var(--text-800);font-family:var(--font-serif)">${concern.title}</div>
        <div style="margin-top:8px"><span class="tag" style="background:${severityColor}20;color:${severityColor}">Concern Level: ${severityLabel}</span></div>
        <p style="font-size:12px;color:var(--text-400);margin-top:8px">This indicator is based on your self-reported answers. It is not a medical diagnosis.</p>
      </div>

      <!-- Summary of Answers -->
      <div class="card mb-16">
        <div class="card-label">What you shared</div>
        <div style="margin-top:12px">
          ${assessmentQuestions.map((q, i) => answers[q.id] ? `
            <div style="padding:8px 0;border-bottom:1px solid var(--border-light);font-size:13px">
              <span style="color:var(--text-500)">${q.q}</span><br>
              <span style="font-weight:600;color:var(--text-800)">${answers[q.id]}</span>
            </div>
          ` : '').join('')}
        </div>
      </div>

      <!-- Personalized Plan -->
      <div class="card card-purple mb-16">
        <div class="card-label">Your Personalized Next Steps</div>
        <div style="margin-top:12px">
          ${plan.steps.map((step, i) => `
            <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--purple-200)">
              <div style="width:24px;height:24px;border-radius:50%;background:var(--purple-600);color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${i+1}</div>
              <div>
                <div style="font-size:13px;font-weight:600;color:var(--text-800)">${step.title}</div>
                <div style="font-size:12px;color:var(--text-500);margin-top:2px">${step.desc}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Recovery Activities -->
      <div class="card mb-16">
        <div class="card-label">Recommended Activities for You</div>
        <div class="card-grid-2 mt-12">
          ${plan.activities.map(act => `
            <div class="activity-card">
              <div class="activity-card-header">
                <span class="activity-icon">${act.icon}</span>
                <div>
                  <div class="activity-title">${act.title}</div>
                  <div class="activity-duration">${act.duration}</div>
                </div>
              </div>
              <div class="activity-desc">${act.desc}</div>
            </div>
          `).join('')}
        </div>
      </div>

      ${severity === 'high' ? `
      <div class="alert alert-danger">
        <strong>💙 Professional Support Recommended</strong><br>
        Based on what you've shared, speaking with a qualified mental health professional could be very helpful. You don't need to wait until things get worse.
        <br><br>
        <button class="btn btn-primary btn-sm" onclick="navigateTo('professionals')">Find Support Near You →</button>
      </div>` : ''}

      ${SAFETY.getResourceHtml()}

      <div style="display:flex;gap:12px;margin-top:20px;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="startRecoveryJourney('${concern.id}')">Start My Recovery Journey 🌱</button>
        <button class="btn btn-secondary" onclick="selectConcern(currentConcern)">Retake Assessment</button>
        <button class="btn btn-outline" onclick="navigateTo('ai-chat')">Talk to SAHELI AI 💬</button>
      </div>
    </div>
  `;
}

function startRecoveryJourney(concernId) {
  STATE.startRecovery(concernId);
  navigateTo('recovery');
}

function generateRecoveryPlan(concernId, answers, severity) {
  const plans = {
    loneliness: {
      steps: [
        { title: 'Acknowledge your feelings without judgment', desc: 'Loneliness is painful and real. Recognizing it without self-blame is the first step.' },
        { title: 'Reach out to one person today', desc: 'Even a brief text message can be a meaningful connection. Start small.' },
        { title: 'Explore one new activity or community', desc: 'A hobby group, online community, or volunteer opportunity can open new connections.' },
        { title: 'Practice self-compassion', desc: 'Talk to yourself as you would to a good friend — gently and with kindness.' },
        { title: 'Consider professional support if loneliness persists', desc: 'A counsellor can help you explore connection patterns and build confidence.' }
      ],
      activities: [
        { icon: '📝', title: 'Gratitude & Connection Journal', duration: '10 min daily', desc: 'Write one thing you\'re grateful for and one connection you\'d like to nurture.' },
        { icon: '🚶', title: 'Community Walk', duration: '20-30 min', desc: 'Walk in a public space — a park, market, or neighbourhood. Notice people around you.' },
        { icon: '📞', title: 'One Connection Call', duration: '10-15 min', desc: 'Text or call someone you haven\'t spoken to in a while.' },
        { icon: '🌿', title: 'Self-Compassion Practice', duration: '5 min', desc: 'Place your hand on your heart and say: "I\'m not alone in feeling this way. May I be kind to myself."' }
      ]
    },
    depression: {
      steps: [
        { title: 'Safety first — your wellbeing matters', desc: 'If you\'re having thoughts of self-harm, please reach out to 14416 or a trusted person immediately.' },
        { title: 'Create a manageable daily routine', desc: 'Just getting up, dressing, and eating at consistent times can help stabilise mood.' },
        { title: 'Do one small enjoyable activity today', desc: 'Even if motivation is low, doing something small can shift momentum.' },
        { title: 'Connect with someone you trust', desc: 'Share how you\'re feeling with at least one person.' },
        { title: 'Speak with a professional', desc: 'A doctor or mental health professional can assess your symptoms and discuss appropriate support.' }
      ],
      activities: [
        { icon: '🌅', title: 'Morning Light & Movement', duration: '10-15 min', desc: 'Sit near a window or step outside in the morning. Even brief sunlight exposure can help mood.' },
        { icon: '📔', title: 'Mood & Thought Journal', duration: '10 min', desc: 'Note your mood, any automatic negative thoughts, and one thing that went okay today.' },
        { icon: '💆', title: 'Body Scan & Rest', duration: '15 min', desc: 'Lie comfortably and slowly notice each part of your body, releasing tension where you find it.' },
        { icon: '👩‍⚕️', title: 'Professional Consultation', duration: 'As needed', desc: 'Schedule an appointment with your doctor or a mental health professional.' }
      ]
    },
    anxiety: {
      steps: [
        { title: 'Ground yourself right now', desc: 'Name 5 things you see, 4 you feel, 3 you hear, 2 you smell, 1 you taste.' },
        { title: 'Identify your anxiety triggers', desc: 'Keep a brief log: what was happening when anxiety peaked? Patterns often emerge.' },
        { title: 'Try paced breathing', desc: 'Inhale for 4 counts, hold for 2, exhale for 6. Repeat 5-10 times.' },
        { title: 'Challenge anxious thoughts gently', desc: 'Ask: "Is this thought definitely true? What would I tell a friend who had this thought?"' },
        { title: 'Seek support if anxiety significantly affects daily life', desc: 'A psychologist or counsellor can offer personalised CBT or other evidence-based approaches.' }
      ],
      activities: [
        { icon: '🌬️', title: '4-2-6 Breathing', duration: '5 min', desc: 'Inhale 4 counts, hold 2, exhale 6. The extended exhale activates the calming nervous system.' },
        { icon: '🖐️', title: '5-4-3-2-1 Grounding', duration: '5 min', desc: '5 see, 4 feel, 3 hear, 2 smell, 1 taste. Brings attention to the present moment.' },
        { icon: '📓', title: 'Worry Time Journal', duration: '15 min', desc: 'Set a specific 15-minute daily "worry time." Write worries then, and outside this time, remind yourself to save them for later.' },
        { icon: '🧘', title: 'Progressive Muscle Relaxation', duration: '15-20 min', desc: 'Tense and release each muscle group from feet to head. Reduces physical tension.' }
      ]
    },
    sleep: {
      steps: [
        { title: 'Assess your current sleep habits', desc: 'Note your bedtime, wake time, screen use, caffeine intake, and bedroom environment.' },
        { title: 'Set a consistent sleep schedule', desc: 'Go to bed and wake at the same time every day — even weekends. This regulates your body clock.' },
        { title: 'Create a calming pre-sleep routine', desc: '30-60 minutes before bed: dim lights, reduce screens, read, or do gentle stretching.' },
        { title: 'Address what\'s keeping you awake', desc: 'If worry or stress is the main culprit, working on anxiety management often helps sleep too.' },
        { title: 'Consult a doctor if sleep problems persist beyond 4 weeks', desc: 'Persistent insomnia is treatable — you don\'t have to accept it.' }
      ],
      activities: [
        { icon: '🌙', title: 'Sleep Diary', duration: '5 min nightly', desc: 'Log bedtime, wake time, how you slept, and anything that might have affected sleep.' },
        { icon: '🛁', title: 'Wind-Down Routine', duration: '30-60 min', desc: 'Dim lights, warm bath or shower, gentle stretching, or calming reading before bed.' },
        { icon: '🌬️', title: '4-7-8 Breathing', duration: '5 min', desc: 'Inhale 4 counts, hold 7, exhale 8. A relaxation technique for sleeplessness.' },
        { icon: '📵', title: 'Screen-Free Hour', duration: '60 min before bed', desc: 'Put away phone and screens 60 minutes before bed. Read a physical book or listen to calm music instead.' }
      ]
    }
  };

  // Default plan for concerns without specific plans
  const defaultPlan = {
    steps: [
      { title: 'Acknowledge what you\'re experiencing', desc: 'Your feelings are valid. Recognizing them clearly is the first step forward.' },
      { title: 'Track your patterns', desc: 'Note when you feel this concern most strongly and what seems to trigger it.' },
      { title: 'Take one small practical step today', desc: 'Even tiny action creates momentum. What is one thing you can do in the next hour?' },
      { title: 'Reach out for support', desc: 'Share what you\'re going through with a trusted person or SAHELI AI.' },
      { title: 'Consider professional guidance', desc: 'A counsellor or doctor can offer personalised support that goes beyond what an app can provide.' }
    ],
    activities: [
      { icon: '📝', title: 'Reflection Journal', duration: '10 min', desc: 'Write about what you\'re experiencing, without judgment. Just let the words flow.' },
      { icon: '🌬️', title: 'Calming Breathing', duration: '5 min', desc: 'Slow your breathing: in for 4, out for 6. Repeat 10 times.' },
      { icon: '🚶', title: 'Gentle Movement', duration: '15 min', desc: 'A short walk, gentle stretching, or any movement that feels good to your body.' },
      { icon: '💬', title: 'Talk It Through', duration: 'As needed', desc: 'Speak with SAHELI AI or a trusted person about what you\'re experiencing.' }
    ]
  };

  return plans[concernId] || defaultPlan;
}

window.CONCERNS_MODULE = { render: renderConcerns };
window.startRecoveryJourney = startRecoveryJourney;
window.currentConcern = null;
